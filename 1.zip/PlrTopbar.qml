/*
 * Copyright (C) 2020-2021 BlueStack Systems, Inc.
 * All Rights Reserved
 *
 * THIS IS UNPUBLISHED PROPRIETARY SOURCE CODE OF BLUESTACK SYSTEMS, INC.
 * The copyright notice above does not evidence any actual or intended
 * publication of such source code.
 */

import QtQuick 2.15
import QtQuick.Controls 2.15
import QtQuick.Layouts 1.15
import QtQuick.Window 2.15
import QtGraphicalEffects 1.15
import UiToolTipControl 1.0
import UiShortcutToolTip 1.0
import QtQuick.Shapes 1.12
import DialogButtonModel 1.0
import DialogButtonModelList 1.0
import UiDialogWindow 1.0
import PlrScreenRecord 1.0

Rectangle {
    id: iRoot
    objectName: "topbar"

    signal sidebarBtnClicked()
    signal sidebarHideClicked()
    signal hamburgerSettingClicked()

    property bool pCompLoaded: false
    property int pIconSize: 32
    property bool pCurrentTopmostState: false
    property bool pFixedWindowSizeState: false
    property real pFixedElementsWidth: (10 + iProductLogo.width) + (pIsMacroRunning ? iMacroTopbarControl.item.pCompFixedWidth : 0) +
                                       iMinimizeBtn.width + (iFixedResizeBtn.visible ? iFixedResizeBtn.width : 0) +
                                       iCloseBtn.width + (iSidebarShowBtn.visible ? iSidebarShowBtn.width : 0) +
                                       (iDisablePinToTopBtn.visible ? iDisablePinToTopBtn.width : 0) + (pIconSize/2) +
                                       (pIsScreenRecording ? iScreenRecordingTopbarControl.item.pCompFixedWidth : 0)

    property var pMacroRecordingStartTime: -1
    property var pMacroRecordingPausedTime: -1
    property var pScreenRecordingStartTime: -1
    property bool pEnableTimer: false
    property bool pMacroRecordingInProcess: false
    property bool pMacroTimerRunning: false
    property string pMacroIterationText: ""
    property string pCurrentRunningMacroName: ""
    property string pCurrentRunningDependentMacroName: ""
    property string pScreenRecordingTimerText: ""
    property bool pIsScreenRecording: false

    property bool pSyncControlVisible: false
    property bool pSyncSource: true

    property string pTopActivityAppLabel: ""
    property string pTopActivityAppPackage: ""
    property bool pShowFeedbackPopup: false
    property bool pShowRewardsText: true
    property bool pShowQuestText: true
    property bool pIsQuestEnabled : false
    property bool pShowRewardsCenterRedDot: false

    property UiWindowedPopup hamburgerWin: null
    property UiWindowedPopup helpWin: null

    component PlrTopbarElement: QtObject {
        property bool pVisible: true
        property int pWidth: 0

        signal changeVisibility(var visibility)
    }

    property list<QtObject> pNonFixedTopbarItems: [
        PlrTopbarElement {
            pVisible: true
            pWidth: (12 + Math.max(iVersionImgLayout.width, iBstTxt.implicitWidth))
            onChangeVisibility: {
                iVersionImgLayout.visible = visibility
                if((pIsMacroRunning || pIsMacroPause) && iMacroTopbarControl.sourceComponent != undefined)
                    iMacroTopbarControl.visible = true
                else
                    iMacroTopbarControl.visible = false

                if(!visibility) {
                    var pAvailablewidth = iTopbarRow.width  - pFixedElementsWidth
                    if(pIsScreenRecording) {
                        iBstTxt.pPreferredWidth = pAvailablewidth - (24 + (iScreenRecordingTopbarControl.item.pRecordingDetailRowVisible ? iScreenRecordingTopbarControl.item.pRecordingDetailWidth + 8 : 0))
                        if(pIsMacroPause || pIsMacroRunning) {
                            if(pAvailablewidth < 0) {
                                if(iMacroTopbarControl.sourceComponent != undefined)
                                    iMacroTopbarControl.visible = false
                            }
                            else {
                                iBstTxt.pPreferredWidth -= (iMacroTopbarControl.item.pIsMacroDetailVisible ? iMacroTopbarControl.item.pMacroDetailWidth + 8 : 0)
                                        + (iSyncTopbarControl.visible ? iSyncTopbarControl.width + 8 : 0)
                            }
                        }
                    }
                    else if(pIsMacroRunning || pIsMacroPause) {
                        if(iMacroTopbarControl.sourceComponent != undefined)
                            iMacroTopbarControl.visible = true
                        iBstTxt.pPreferredWidth = pAvailablewidth - (24 + (iMacroTopbarControl.item.pIsMacroDetailVisible ? iMacroTopbarControl.item.pMacroDetailWidth + 8 : 0) + (iSyncTopbarControl.visible ? iSyncTopbarControl.width + 8 : 0))
                    }
                    else
                        iBstTxt.pPreferredWidth = pAvailablewidth - 24

                    iBstTxt.visible = iBstTxt.pPreferredWidth > 4 ? true: false
                }
                else {
                    iBstTxt.visible = visibility
                    iBstTxt.pPreferredWidth = iBstTxt.implicitWidth
                }
            }
        },
        PlrTopbarElement {
            pVisible: pIsScreenRecording
            pWidth: iScreenRecordingTopbarControl.sourceComponent != undefined ? iScreenRecordingTopbarControl.item.pCompVariableWidth : 0
            onChangeVisibility: {
                if (iScreenRecordingTopbarControl.sourceComponent != undefined)
                    iScreenRecordingTopbarControl.item.pRecordingDetailRowVisible = visibility
            }
        },
        PlrTopbarElement {
            pVisible: pSyncControlVisible
            pWidth: iSyncTopbarControl.width
            onChangeVisibility: {
                iSyncTopbarControl.visible = visibility
            }
        },
        PlrTopbarElement {
            pVisible: pIsMacroRunning
            pWidth: iMacroTopbarControl.sourceComponent != undefined ? iMacroTopbarControl.item.pCompVariableWidth : 0
            onChangeVisibility: {
                if (iMacroTopbarControl.sourceComponent != undefined)
                    iMacroTopbarControl.item.pIsMacroDetailVisible = visibility
            }
        },
        PlrTopbarElement {
            pVisible: true
            pWidth: (12 + iBackBtn.width)
            onChangeVisibility: {
                iBackBtn.visible = visibility
            }
        },
        PlrTopbarElement {
            pVisible: true
            pWidth: iHomeBtn.width
            onChangeVisibility: {
                iHomeBtn.visible = visibility
            }
        },
        PlrTopbarElement {
            pVisible: true
            pWidth: iCfgBtn.width
            onChangeVisibility: {
                iCfgBtn.visible = visibility
            }
        },
        PlrTopbarElement {
            pVisible: true
            pWidth: iHelpBtn.width
            onChangeVisibility: {
                iHelpBtn.visible = visibility
            }
        },
        PlrTopbarElement {
            pVisible: true
            pWidth: iRecentBtn.width
            onChangeVisibility: {
                iRecentBtn.visible = visibility
            }
        },
        PlrTopbarElement {
            pVisible: iAppwin.pIsRawMode
            pWidth: iRawModeWarningBtn.width
            onChangeVisibility: {
                iRawModeWarningBtn.visible = visibility
            }
        },
        PlrTopbarElement {
            pVisible: pIsQuestEnabled
            pWidth: 32
            onChangeVisibility: {
                iRewardsCenterBtn.visible = visibility
            }
        },
        PlrTopbarElement {
            pVisible: pIsQuestEnabled
            pWidth: 32
            onChangeVisibility: {
                iQuestBtn.visible = visibility
            }
        },
        PlrTopbarElement {
            pVisible: pIsQuestEnabled
            onChangeVisibility: {
                pShowQuestText = visibility
            }
            Component.onCompleted: {
                pWidth = (iQuestBtn.width - 36)
            }
        },
        PlrTopbarElement {
            pVisible: pIsQuestEnabled
            onChangeVisibility: {
                pShowRewardsText = visibility
            }
            Component.onCompleted: {
                pWidth = (iRewardsCenterBtn.width - 36)
            }
        }
    ]

    MouseArea {
        anchors.fill: parent
        property var startingPosition
        property bool isPressed: false

        onPressed: {
            isPressed = true
            startingPosition  = Qt.point(mouse.x, mouse.y)
        }
        onReleased: {
            isPressed = false
            if ( iAppwin.y < Screen.virtualY) {
                iAppwin.y = Screen.virtualY
            }
        }

        onPositionChanged: {
            if (isPressed && iAppwin.visibility !== ApplicationWindow.Maximized) {
                var delta = Qt.point(mouse.x - startingPosition.x, mouse.y - startingPosition.y)
                iAppwin.x += delta.x
                iAppwin.y += delta.y
            }
        }

        onDoubleClicked: {
            iAppwin.visibility === ApplicationWindow.Windowed ?
                        plrBackend.onMaximizeClicked() :
                        plrBackend.onRestoreClicked()
        }
    }

    Component.onCompleted: {
        if (!pCompLoaded) {
            pCurrentTopmostState = uiBackend.confGetInstanceBool("pin_to_top")

            if (true === pCurrentTopmostState)
                iAppwin.flags = iAppwin.flags | Qt.WindowStaysOnTopHint
            pCompLoaded = true
        }
    }

    onWidthChanged: {
        if (pCompLoaded) {
            fReloadTopbarElements()
        }
    }

    UiRowLayout {
        id: iTopbarRow
        anchors.fill: parent
        spacing: 0

        UiImage {
            id: iProductLogo
            asset: "BlueStacksLogo"
            Layout.leftMargin: 10
            pImageWidth: 20
            pImageHeight: 20
        }

        UiColumnLayout{
            id: iTitleLayout
            Layout.leftMargin: 12
            Text {
                property int pPreferredWidth : iBstTxt.implicitWidth
                id: iBstTxt
                text: plrBackend.title
                Layout.fillHeight: true
                color: UiTheme.colors.primary10
                font: UiTheme.fonts.bodySmall
                fontSizeMode: Text.Fit
                horizontalAlignment: Text.AlignLeft
                verticalAlignment: Text.AlignVCenter
                elide: Text.ElideRight
                Layout.preferredWidth: pPreferredWidth + 12
            }
            UiRowLayout{
                id: iVersionImgLayout
                Text {
                    id: iVersionTxt
                    text: plrBackend.version
                    Layout.fillHeight: true
                    color: uiBackend.oem === "msi5" ? UiTheme.colors.overLayTint : UiTheme.colors.primary30
                    font: UiTheme.fonts.bodyTiny
                    fontSizeMode: Text.Fit
                    opacity: 0.7
                    horizontalAlignment: Text.AlignLeft
                    verticalAlignment: Text.AlignVCenter
                }

                Text {
                    id: iImageTxt
                    text: "N32"
                    Layout.fillHeight: true
                    color: uiBackend.oem === "msi5" ? UiTheme.colors.overLayTint : UiTheme.colors.primary30
                    font: UiTheme.fonts.bodyTiny
                    fontSizeMode: Text.Fit
                    Layout.leftMargin: 4
                    opacity: 0.7
                    horizontalAlignment: Text.AlignLeft
                    verticalAlignment: Text.AlignVCenter
                }
            }
        }

        UiImageButton {
            id: iBackBtn
            asset: "SidebarBack"
            Layout.leftMargin: 12
            enabled: iAppwin.pIsBootComplete
            pImageWidth: pIconSize
            pImageHeight: pIconSize
            pUseShortcutTooltip: true
            UiShortcutToolTip.text: qsTranslate("QObject", "Back")
            UiShortcutToolTip.shortcutMap: [{ value: "go_back" }]
            onClicked: {
                plrBackend.logUIAction("Topbar", "Back")
                plrBackend.onBackClicked()
            }
        }

        UiImageButton {
            id: iHomeBtn
            asset: "SidebarHome"
            enabled: iAppwin.pIsBootComplete
            pImageWidth: pIconSize
            pImageHeight: pIconSize
            pUseShortcutTooltip: true
            UiShortcutToolTip.text: qsTranslate("QObject", "Home")
            UiShortcutToolTip.shortcutMap: [{ value: "go_home" }]
            onClicked: {
                plrBackend.logUIAction("Topbar", "Home")
                plrBackend.onHomeClicked()
            }
        }

        UiImageButton {
            id: iRecentBtn
            asset: "SidebarRecents"
            enabled: iAppwin.pIsBootComplete
            pImageWidth: pIconSize
            pImageHeight: pIconSize
            pUseShortcutTooltip: true
            UiShortcutToolTip.text: qsTranslate("QObject", "Recent apps")
            UiShortcutToolTip.shortcutMap: [{ value: "open_recent_apps" }]
            onClicked: {
                plrBackend.logUIAction("Topbar", "RecentApps")
                plrBackend.onRecentAppsClicked()
            }
        }

        Item {
            Layout.fillWidth: true
        }

        Loader {
            id: iMacroTopbarControl
            Layout.leftMargin: 8
            visible: sourceComponent != undefined
            sourceComponent: pIsMacroRunning ? iMacroTopbarComponent : undefined
        }

        Loader {
            id: iSyncTopbarControl
            visible: sourceComponent != undefined
            sourceComponent: pSyncControlVisible ? iSyncTopbarComponent : undefined
        }

        Loader {
            id: iScreenRecordingTopbarControl
            visible: sourceComponent != undefined
            sourceComponent: pIsScreenRecording ? iScreenRecordingTopbarComponent : undefined
        }

        UiImageButton {
            id: iRawModeWarningBtn
            visible: false
            asset: "TitlebarError"
            pImageWidth: pIconSize
            pImageHeight: pIconSize
            onClicked: {
                plrBackend.logUIAction("Topbar", "RawModeWarning")
                iAppwin.fShowRawModeWarning(false)
            }
        }

        UiImageLabel {
            id: iRewardsCenterBtn
            Layout.preferredHeight: pIconSize
            visible: pIsQuestEnabled
            pText: ((iAppwin.width > iAppwin.height) && pShowRewardsText) ? qsTranslate("QObject", "Reward Center") : ""
            pImageAsset: "RewardsCenter"
            padding: 8
            spacing: 4
            pBackgroundColor: pHovered ? UiTheme.colors.primary50 : UiTheme.colors.primary70
            pBorderColor: UiTheme.colors.primary80
            pBorderWidth: 1
            font: UiTheme.fonts.bodySmall
            pTextColor: UiTheme.colors.primary10
            pShowRedDot: pShowRewardsCenterRedDot
            UiToolTip.text: qsTranslate("QObject", "Reward Center")
            UiToolTip.visible: ((iAppwin.width < iAppwin.height)|| !pShowRewardsText) && pHovered
            onClicked: {
                plrBackend.logUIAction("Topbar", "Reward Center")
                plrBackend.onQuestIconClick("rewards_center", "{\"QUERY_STRING\"  : \"source=rewards_topbar&section=reward_center&quest_tab=\"}")
                pShowRewardsCenterRedDot = false
            }
        }

        UiImageLabel {
            id: iQuestBtn
            Layout.preferredHeight: pIconSize
            visible: pIsQuestEnabled
            pText: ((iAppwin.width > iAppwin.height) && pShowQuestText) ? qsTranslate("QObject", "Play & Win") : ""
            pImageAsset: "PlayAndWin"
            padding: 8
            spacing: 4
            pBackgroundColor: pHovered ? UiTheme.colors.primary50 : UiTheme.colors.primary70
            pBorderColor: UiTheme.colors.primary80
            pBorderWidth: 1
            font: UiTheme.fonts.bodySmall
            pTextColor: UiTheme.colors.primary10
            UiToolTip.text: qsTranslate("QObject", "Play & Win")
            UiToolTip.visible: ((iAppwin.width < iAppwin.height)||!pShowQuestText) && pHovered
            onClicked: {
                plrBackend.logUIAction("Topbar", "Play & Win")
                plrBackend.onQuestIconClick("play_and_win", "")
            }
        }

        UiImageButton {
            id: iDisablePinToTopBtn
            asset: "TitlebarDisablePinTop"
            pImageWidth: pIconSize
            pImageHeight: pIconSize
            visible: pCurrentTopmostState
            UiToolTip.text: qsTranslate("QObject", "Disable Pin to Top")
            onPressed: {
                plrBackend.logUIAction("Topbar", "DisablePinToTop")
                iCfgBtn.visible = true
                pCurrentTopmostState = false
                fHandlePinToTop()
                plrBackend.sendMiniModeStats(true)
            }
        }

        UiImageButton {
            id: iHelpBtn
            asset: "TitlebarHelp"
            pImageWidth: pIconSize
            pImageHeight: pIconSize
            UiToolTip.text: qsTranslate("QObject", "Help and support")
            onPressed: {
                plrBackend.logUIAction("Topbar", "HelpAndSupport")
                fOpenHelpPopup()
            }
        }

        Item {
            id: iCfgBtn
            Layout.preferredWidth: pIconSize
            Layout.preferredHeight: pIconSize
            UiImageButton {
                asset: "TitlebarMenu"
                pImageWidth: pIconSize
                pImageHeight: pIconSize
                UiToolTip.text: qsTranslate("QObject", "Menu")
                onPressed: {
                    plrBackend.logUIAction("Topbar", "HamburgerMenu")
                    fOpenHamburgerPopup()
                }
            }
            Loader {
                visible: sourceComponent != undefined
                sourceComponent: plrBackend.pDiskOptimizationOnboarding ? iRedDotComponent : undefined
                anchors.top: iCfgBtn.top
                anchors.right: iCfgBtn.right
                anchors.topMargin: 2
                anchors.rightMargin: 4
            }
        }

        UiImageButton {
            id: iMinimizeBtn
            asset: "TitlebarMinimize"
            pImageWidth: pIconSize
            pImageHeight: pIconSize
            UiToolTip.text: qsTranslate("QObject", "Minimize")
            onClicked: {
                plrBackend.logUIAction("Topbar", "Minimize")
                iAppwin.showMinimized()
            }
        }

        UiImageButton {
            id: iFixedResizeBtn
            asset: iAppwin.visibility === ApplicationWindow.Windowed ? "TitlebarMaximize" : "TitlebarRestore"
            pImageWidth: pIconSize
            pImageHeight: pIconSize
            UiToolTip.text: iAppwin.visibility === ApplicationWindow.Windowed ? qsTranslate("QObject", "Maximize") : qsTranslate("QObject", "Restore")
            onClicked: {
                if (iAppwin.visibility === ApplicationWindow.Windowed) {
                    plrBackend.logUIAction("Topbar", "Maximize")
                    plrBackend.onMaximizeClicked()
                }
                else {
                    plrBackend.logUIAction("Topbar", "Restore")
                    plrBackend.onRestoreClicked()
                }
            }
        }

        UiImageButton {
            id:iCloseBtn
            asset: "TitlebarClose"
            pImageWidth: pIconSize
            pImageHeight: pIconSize
            UiToolTip.text: qsTranslate("QObject", "Close")
            onClicked: {
                plrBackend.logUIAction("Topbar", "Close")
                fShowClosePlrMsg()
            }
        }

        UiImageButton {
            id: iSidebarShowBtn
            asset: iSidebar.visible ? "TitlebarCollapse" : "TitlebarExpand"
            pImageHeight: iAppwin.pSidebarWidth
            pImageWidth: iAppwin.pSidebarWidth
            UiToolTip.text: iSidebar.visible ? qsTranslate("QObject", "Close sidebar") : qsTranslate("QObject", "Open sidebar")
            onClicked: {
                if (iSidebar.visible) {
                    plrBackend.logUIAction("Sidebar", "CollapseSidebar")
                    sidebarHideClicked()
                }
                else {
                    plrBackend.logUIAction("Topbar", "ExpandSidebar")
                    sidebarBtnClicked()
                }
            }
        }
    }

    Connections {
        target: iAppwin
        function onPIsMacroRunningChanged() {
            if (iAppwin.pIsMacroRunning && iAppwin.visibility !== ApplicationWindow.FullScreen)
                iMacroRecordingTooltipComponent.createObject(iAppwin).show()
            else {
                pMacroRecordingStartTime = -1
                pIsMacroPause = false
            }
        }
    }

    Component {
        id: iMacroTopbarComponent
        UiRowLayout {
            height: 26
            color: UiTheme.colors.primary90
            border.color: UiTheme.colors.primary60
            border.width: 1
            spacing: 8
            leftPadding: 8
            rightPadding: 8

            property int pCompFixedWidth: 16 + iMacroRecordingActiveImage.width + 8 + iPlayPauseBtn.width + 8 + iStopBtn.width + 8
            property int pCompVariableWidth: 16 + iMacroRecordingControlText.width + (pMacroRecordingInProcess ? 0 : (16 + iMacroRecordingControlIterationText.width))
            property int pMacroDetailWidth: iMacroDetail.width
            property bool pIsMacroDetailVisible: true

            UiImage {
                id: iMacroRecordingActiveImage
                asset: pMacroRecordingInProcess ? "MacroRecord" : "MacroPlay"
                pImageWidth: 12
                pImageHeight: 12
            }
            UiRowLayout {
                id: iMacroDetail
                spacing: 8
                visible: pIsMacroDetailVisible
                Text {
                    id: iMacroRecordingControlText
                    text: pMacroRecordingInProcess ? pMacroIterationText : pCurrentRunningMacroName
                    Layout.preferredWidth: 55
                    color: UiTheme.colors.primary10
                    font: UiTheme.fonts.bodySmall
                    UiToolTip.text: pMacroRecordingInProcess
                                    ? qsTranslate("QObject", "Macro recording in progress")
                                    : pCurrentRunningDependentMacroName === pCurrentRunningMacroName
                                      ? qsTranslate("QObject", "Playing %1").arg(pCurrentRunningMacroName)
                                      : qsTranslate("QObject", "%1 -> %2 in progress").arg(pCurrentRunningMacroName).arg(pCurrentRunningDependentMacroName)
                    UiToolTip.visible: iMacroTextMouseArea.containsMouse
                    elide: Text.ElideRight
                    MouseArea {
                        id: iMacroTextMouseArea
                        anchors.fill: parent
                        hoverEnabled: true
                    }
                }
                Text {
                    id: iMacroRecordingControlIterationText
                    text: pMacroIterationText
                    color: UiTheme.colors.accentNormal
                    font: UiTheme.fonts.bodyExtraSmall
                    visible: !pMacroRecordingInProcess
                }
            }
            Timer {
                interval: 500
                running: true
                repeat: true
                onTriggered: {
                    if(!pMacroRecordingInProcess)
                    {
                        if(!pIsMacroPause)
                            iMacroRecordingActiveImage.asset = iMacroRecordingActiveImage.asset != "MacroPlay" ? "MacroPlay" : "MacroBase"
                        else
                            iMacroRecordingActiveImage.asset = "MacroPause"
                    }
                    else
                        iMacroRecordingActiveImage.asset = (iMacroRecordingActiveImage.asset != "MacroBase" && pMacroTimerRunning ? "MacroBase" : "MacroRecord")
                }
            }
            Timer {
                triggeredOnStart: true
                interval: 200
                running: pMacroTimerRunning
                repeat: true
                onTriggered: {
                    if(pMacroRecordingStartTime == -1)
                        pMacroRecordingStartTime = Date.now()


                    var seconds = parseInt( (Date.now() - pMacroRecordingStartTime) / 1000 );
                    var minutes = parseInt( seconds / 60 );
                    seconds = seconds % 60;
                    var hours = parseInt( minutes / 60 );
                    minutes = minutes % 60;

                    var time = (hours < 10 ? "0" + hours : hours) + ":" + (minutes < 10 ? "0" + minutes : minutes) + ":" + (seconds < 10 ? "0" + seconds : seconds)
                    pMacroIterationText = time
                }
            }
            UiImageButton {
                id: iPlayPauseBtn
                asset: pIsMacroPause ? "PlaySmall" : "PauseSmall"
                pImageWidth: 12
                pImageHeight: 12
                visible: pIsMacroRunning
                pUseShortcutTooltip: true
                UiShortcutToolTip.text: (asset == "PauseSmall")
                                        ? (!pMacroRecordingInProcess
                                           ? qsTranslate("QObject", "Pause running macro")
                                           : qsTranslate("QObject", "Pause macro recording"))
                                        : (!pMacroRecordingInProcess
                                           ? qsTranslate("QObject", "Play macro")
                                           : qsTranslate("QObject", "Resume macro recording"))
                UiShortcutToolTip.shortcutMap: !pMacroRecordingInProcess
                                               ? [{ value: "pause_play_macros" }]
                                               : [{ value: "" }]
                onClicked: {
                    fToggleMacroPause(false)
                }
            }
            UiImageButton {
                id:iStopBtn
                asset: "StopSmall"
                pImageWidth: 12
                pImageHeight: 12
                UiToolTip.text: pMacroRecordingInProcess
                                ? qsTranslate("QObject", "Stop recording macro")
                                : qsTranslate("QObject", "Stop playing macro")
                onClicked: {
                    fStopMacro()
                }
            }
        }
    }

    Component {
        id: iSyncTopbarComponent
        UiRowLayout {
            id: iSyncTopbarLayout
            height: 26
            color: UiTheme.colors.primary90
            border.color: UiTheme.colors.primary60
            border.width: 1
            leftPadding: 8
            rightPadding: 8
            topPadding: 1
            bottomPadding: 1
            spacing: 8
            UiToolTip.text: pSyncSource ? qsTranslate("QObject", "Syncing operations to other instance(s)") : qsTranslate("QObject", "Syncing operations from another instance.")
            UiToolTip.visible: pMouseArea.containsMouse
            pMouseArea {
                enabled: true
                anchors.fill: iSyncTopbarLayout
                hoverEnabled: true
            }

            property string pSyncPauseBtnAsset: "PauseSmall"

            UiImage {
                asset: pSyncSource ? "SyncPlay_hover_2" : "SyncPlay_hover"
                pImageWidth: 12
                pImageHeight: 12
            }

            UiImageButton {
                id: iSyncPauseBtn
                asset: pSyncPauseBtnAsset
                pImageWidth: 12
                pImageHeight: 12
                visible: pSyncSource
                pUseShortcutTooltip: true
                UiShortcutToolTip.text: qsTranslate("QObject", "Play/pause sync operations")
                UiShortcutToolTip.shortcutMap: [{ value: "play_pause_sync_operations" }]
                onClicked: {
                    plrBackend.logUIAction("Topbar", "PlayPauseMacro")
                    mnsBackend.onSyncPaused()
                }
            }

            UiImageButton {
                asset: "StopSmall"
                pImageHeight: 12
                pImageWidth: 12
                visible: pSyncSource
                UiToolTip.text: qsTranslate("QObject", "Stop sync operations")
                onClicked: {
                    plrBackend.logUIAction("Topbar", "StopMacro")
                    pSyncPauseBtnAsset = "PauseSmall"
                    fStopSyncOperations()
                }
            }
        }
    }

    Component {
        id: iClosePlrPrompt
        UiMessageDialog {
            title: qsTranslate("QObject", "Close %1").arg(uiBackend.confGetInstanceString("display_name", "BlueStacks"))
            pDescription: qsTranslate("QObject", "Would you like to exit %1?").arg(uiBackend.confGetInstanceString("display_name", "BlueStacks"))
            pDialogType: UiDialogWindow.SimpleNarrow
            pButtonsList: DialogButtonModelList {
                pButtons: [
                    DialogButtonModel {
                        pColor: UiTheme.buttons.colors.danger
                        pText: qsTranslate("QObject", "Close")
                        onClicked: {
                            close()
                            plrBackend.onCloseCalled()
                        }
                    },
                    DialogButtonModel {
                        pColor: UiTheme.buttons.colors.secondary
                        pText: qsTranslate("QObject", "Cancel")
                        onClicked: {
                            close()
                        }
                    }
                ]
            }
        }
    }

    Component {
        id: iFeedbackPopupComponent
        UiMessageDialog {
            property string feedbackAppLabel: ""
            property string feedbackAppPackage: ""
            title: feedbackAppLabel != ""
                   ? qsTranslate("QObject", "Enjoyed playing %1 on %2?").arg(feedbackAppLabel).arg(uiBackend.productName)
                   : qsTranslate("QObject", "Enjoyed playing on %1?").arg(uiBackend.productName)
            pDescription: qsTranslate("QObject", "Tell us about your experience. We're listening!")
            pDialogType: UiDialogWindow.Tall
            pDialogImageSource: "Feedback"
            pButtonsList: DialogButtonModelList {
                pButtons: [
                    DialogButtonModel {
                        pColor: UiTheme.buttons.colors.accent
                        pText: qsTranslate("QObject", "Share feedback")
                        onClicked: {
                            close()
                            plrBackend.openAppSurvey(feedbackAppPackage)
                            plrBackend.onCloseCalled()
                        }
                    },
                    DialogButtonModel {
                        pColor: UiTheme.buttons.colors.secondary
                        pText: qsTranslate("QObject", "Close %1").arg(uiBackend.productName)
                        onClicked: {
                            close()
                            plrBackend.onCloseCalled()
                        }
                    }
                ]
            }
        }
    }

    Component {
        id: iHelpMenuComponent
        UiWindowedPopup {
            id: iHelpMenu
            contentWidth: iHelpMenuLayout.implicitWidth
            contentHeight: iHelpMenuLayout.implicitHeight
            visible: false

            UiColumnLayout {
                id: iHelpMenuLayout
                anchors.left: parent.left
                anchors.right: parent.right
                topPadding: 2
                bottomPadding: 2
                color: UiTheme.colors.primary80
                border.width: 1
                border.color: UiTheme.colors.primary60
                UiImageLabel {
                    Layout.fillWidth: true
                    Layout.preferredHeight: 32
                    pText : qsTranslate("QObject", "Help Center")
                    pImageAsset: "FAQ"
                    leftPadding: 12
                    rightPadding: 12
                    pBackgroundColor: pHovered ? UiTheme.colors.primary60 : "transparent"
                    onClicked:{
                        plrBackend.logUIAction("Topbar", "SupportFAQs")
                        iHelpMenu.close()
                        uiBackend.openHelpArticle("BS5_help")
                    }
                }
                UiImageLabel {
                    Layout.fillWidth: true
                    Layout.preferredHeight: 32
                    pText : qsTranslate("QObject", "Report a problem")
                    pImageAsset: "Error"
                    leftPadding: 12
                    rightPadding: 12
                    pBackgroundColor: pHovered ? UiTheme.colors.primary60 : "transparent"
                    onClicked:{
                        plrBackend.logUIAction("Topbar", "ReportAProblem")
                        iHelpMenu.close()
                        uiBackend.runLogCollector("-instance="+plrBackend.getVmName())
                    }
                }
            }
        }
    }

    Component {
        id: iMacroRecordingTooltipComponent
        UiHelpPopup {
            id: iMacroRecordingPopup
            closeOnPressOutside: false
            contentWidth: 120
            x: iAppwin.x + iMacroTopbarControl.x + (iMacroTopbarControl.width - width) / 2 + adsBackend.pExtendedBannerAdWidth
            y: iAppwin.y + iMacroTopbarControl.y + iMacroTopbarControl.height + 4
            flags: Qt.Tool | Qt.FramelessWindowHint | Qt.WindowDoesNotAcceptFocus

            onVisibleChanged: {
                if (visible)
                    iMacroRecordingPopupTimer.start()
            }

            Connections {
                target: iMacroTopbarControl
                function onVisibleChanged() {
                    if (!iMacroTopbarControl.visible)
                        iMacroRecordingPopup.destroy()
                }
            }

            arrowPosition: UiHelpPopup.ArrowPosition.TopCenter
            pInnerLayout {
                border.width: 1
                border.color: UiTheme.colors.primary60
                color: UiTheme.colors.primary80
                padding: 8
            }

            Text {
                Layout.fillWidth: true
                text: pMacroRecordingInProcess ? qsTranslate("QObject", "Recording macros, click here to pause or stop")
                                               : qsTranslate("QObject", "Executing macro, click here to stop")
                wrapMode: Text.Wrap
                color: UiTheme.colors.primary10
                font: UiTheme.fonts.bodyExtraSmall
            }

            Timer {
                id: iMacroRecordingPopupTimer
                repeat: false
                interval: 5000
                running: false
                onTriggered: {
                    iMacroRecordingPopup.destroy()
                }
            }

            onClosePopup: {
                iMacroRecordingPopupTimer.stop()
            }
        }
    }

    Component {
        id: iHamburgerMenuComponent
        UiWindowedPopup {
            id: iHamburgerMenu
            contentWidth: iHamburgerMenuLayout.implicitWidth
            contentHeight: iHamburgerMenuLayout.implicitHeight
            visible: false

            UiColumnLayout {
                id: iHamburgerMenuLayout
                anchors.left: parent.left
                anchors.right: parent.right
                topPadding: 2
                bottomPadding: 2
                color: UiTheme.colors.primary80
                border.width: 1
                border.color: UiTheme.colors.primary60
                UiRowLayout {
                    id: iHamburgerSettingsLayout
                    Layout.fillWidth: true
                    color: pMouseArea.containsMouse ? UiTheme.colors.primary60 : "transparent"
                    pMouseArea {
                        enabled: true
                        anchors.fill : iHamburgerSettingsLayout
                        hoverEnabled: true
                        onClicked: {
                            plrBackend.pSettingWindowInitializing = true
                            plrBackend.logUIAction("Topbar", "HamburgerSettings")
                            iHamburgerMenu.close()
                            hamburgerSettingClicked()
                        }
                    }
                    UiImageLabel {
                        Layout.preferredHeight: 32
                        pText : qsTranslate("QObject", "Settings")
                        pImageAsset: "MenuSettings"
                        leftPadding: 12
                        rightPadding: 12
                        pHovered: iHamburgerSettingsLayout.pMouseArea.containsMouse
                        hoverEnabled: false
                        onClicked: {
                            plrBackend.pSettingWindowInitializing = true
                            plrBackend.logUIAction("Topbar", "HamburgerSettings")
                            iHamburgerMenu.close()
                            hamburgerSettingClicked()
                        }
                    }
                    Rectangle {
                        visible: plrBackend.pDiskOptimizationOnboarding
                        Layout.preferredWidth: 6
                        Layout.preferredHeight: 6
                        radius: 3
                        color: UiTheme.colors.dangerNormal
                        Layout.alignment: Qt.AlignVCenter
                    }
                    Item {
                        Layout.fillWidth: true
                    }
                }
                UiImageLabel {
                    Layout.fillWidth: true
                    Layout.preferredHeight: 32
                    pText : qsTranslate("QObject", "Mini Mode")
                    pImageAsset: "MenuMiniMode"
                    leftPadding: 12
                    rightPadding: 12
                    pBackgroundColor: pHovered ? UiTheme.colors.primary60 : "transparent"
                    onClicked:{
                        fHandleMiniModeClicked()
                        iHamburgerMenu.close()
                    }
                }
                UiImageLabel {
                    Layout.fillWidth: true
                    Layout.preferredHeight: 32
                    pText: qsTranslate("QObject", "Pin to top")
                    pImageAsset: "MenuPin"
                    leftPadding: 12
                    rightPadding: 12
                    pBackgroundColor: pHovered ? UiTheme.colors.primary60 : "transparent"
                    UiImage {
                        Layout.alignment: Qt.AlignRight
                        Layout.leftMargin: 8
                        pImageWidth: 24
                        pImageHeight: 12
                        asset: pCurrentTopmostState ? "SmallToggleOn" : "SmallToggleOff"
                    }
                    onClicked:{
                        pCurrentTopmostState = !pCurrentTopmostState
                        fHandlePinToTop()
                        iHamburgerMenu.flags = iHamburgerMenu.flags & ~Qt.WindowStaysOnTopHint
                        iHamburgerMenu.flags = iHamburgerMenu.flags | Qt.WindowStaysOnTopHint
                    }
                }

                UiImageLabel {
                    Layout.fillWidth: true
                    Layout.preferredHeight: 32
                    pText : qsTranslate("QObject", "Quick Launch")
                    pImageAsset: visible ? "MenuQuickLaunch" : ""
                    visible: plrBackend.getQuickLaunchEnabled()
                    leftPadding: 12
                    rightPadding: 12
                    pBackgroundColor: pHovered ? UiTheme.colors.primary60 : "transparent"
                    onClicked:{
                        plrBackend.launchAndArrangeAllInstances()
                        iHamburgerMenu.close()
                    }
                }

                UiImageLabel {
                    Layout.fillWidth: true
                    Layout.preferredHeight: 32
                    pText: qsTranslate("QObject", "Fix window size")
                    pImageAsset: "MenuWindow"
                    leftPadding: 12
                    rightPadding: 12
                    pBackgroundColor: pHovered ? UiTheme.colors.primary60 : "transparent"
                    UiImage {
                        Layout.alignment: Qt.AlignRight
                        Layout.leftMargin: 8
                        pImageWidth: 24
                        pImageHeight: 12
                        asset: pFixedWindowSizeState ? "SmallToggleOn" : "SmallToggleOff"
                    }
                    onClicked: {
                        pFixedWindowSizeState = !pFixedWindowSizeState

                        uiBackend.confSetBool("bst.fixed_window_size", pFixedWindowSizeState)
                        uiBackend.confCommit()
                        uiBackend.sendSettingStats("hamburger_menu", "fixed_window_size", pFixedWindowSizeState ? "toggle_on" : "toggle_off")
                        plrBackend.reloadConfInAllInstances()
                    }
                }
            }
        }
    }

    Component {
        id: iScreenRecordingTopbarComponent
        UiRowLayout {
            height: 26
            color: UiTheme.colors.primary100
            border.color: UiTheme.colors.primary70
            border.width: 1
            spacing: 8
            leftPadding: 8
            rightPadding: 8

            property int pCompFixedWidth: 16 + iScreenRecordingImage.width + 8 + iStopBtn.width + 8
            property int pCompVariableWidth: 16 + iScreenRecordingTimerText.width + iRecordingNameText.width
            property bool pRecordingDetailRowVisible: true
            property int pRecordingDetailWidth: iRecordingDetailRow.width

            UiImage {
                id: iScreenRecordingImage
                asset: "StopRecordingBright"
                pImageWidth: 16
                pImageHeight: 16
            }

            UiRowLayout {
                id: iRecordingDetailRow
                spacing: 8
                visible: pRecordingDetailRowVisible

                Text {
                    id: iRecordingNameText
                    text: qsTranslate("QObject", "Video recording")
                    color: UiTheme.colors.primary20
                    font: UiTheme.fonts.bodySmall
                    elide: Text.ElideRight
                }

                Text {
                    id: iScreenRecordingTimerText
                    text: pScreenRecordingTimerText
                    color: UiTheme.colors.accentNormal
                    font: UiTheme.fonts.bodyExtraSmall
                }
            }
            Timer {
                triggeredOnStart: true
                interval: 200
                running: pIsScreenRecording
                repeat: true
                onTriggered: {
                    if(pScreenRecordingStartTime == -1)
                        pScreenRecordingStartTime = Date.now()


                    var seconds = parseInt( (Date.now() - pScreenRecordingStartTime) / 1000 );
                    var minutes = parseInt( seconds / 60 );
                    seconds = seconds % 60;
                    var hours = parseInt( minutes / 60 );
                    minutes = minutes % 60;

                    var time = (hours < 10 ? "0" + hours : hours) + ":" + (minutes < 10 ? "0" + minutes : minutes) + ":" + (seconds < 10 ? "0" + seconds : seconds)
                    pScreenRecordingTimerText = time
                }
            }
            UiImageButton {
                id:iStopBtn
                asset: "StopSmall"
                pImageWidth: 12
                pImageHeight: 12
                UiToolTip.text: qsTranslate("QObject", "Stop screen recording")
                onClicked: {
                    plrBackend.startRecording(false)
                }
            }
        }
    }

    function fReloadTopbarElements() {
        var availableWidth = iTopbarRow.width - pFixedElementsWidth
        var showElements = true

        for(var i = 0; i < pNonFixedTopbarItems.length; i++) {
            if(showElements && pNonFixedTopbarItems[i].pVisible) {
                if(availableWidth > pNonFixedTopbarItems[i].pWidth) {
                    pNonFixedTopbarItems[i].changeVisibility(true)
                    availableWidth = availableWidth - pNonFixedTopbarItems[i].pWidth
                }
                else {
                    pNonFixedTopbarItems[i].changeVisibility(false)
                    showElements = false
                }
            } else {
                pNonFixedTopbarItems[i].changeVisibility(false)
            }
        }
    }

    function fOpenHelpPopup() {
        if (helpWin != null)
        {
            if (helpWin.visible)
                helpWin.close()
            return
        }

        helpWin = iHelpMenuComponent.createObject(iAppwin)
        var point = iHelpBtn.mapToGlobal(0, 0)
        helpWin.x = point.x - helpWin.width + iHelpBtn.width + helpWin.shadowThickness
        helpWin.y = point.y + iHelpBtn.height - helpWin.shadowThickness
        helpWin.show()
    }

    function fOpenHamburgerPopup() {
        if (hamburgerWin != null)
        {
            if (hamburgerWin.visible)
                hamburgerWin.close()
            return
        }

        pFixedWindowSizeState = uiBackend.confGetBool("bst.fixed_window_size")
        hamburgerWin = iHamburgerMenuComponent.createObject(iAppwin)
        var point = iCfgBtn.mapToGlobal(0, 0)
        hamburgerWin.x = point.x - hamburgerWin.width + iCfgBtn.width + hamburgerWin.shadowThickness
        hamburgerWin.y = point.y + iCfgBtn.height - hamburgerWin.shadowThickness
        hamburgerWin.show()
    }

    function fStopMacro() {
        pMacroTimerRunning = false
        pMacroRecordingInProcess = false
        pIsMacroRunning = false
        fReloadTopbarElements()
        mnsBackend.onMacroStopped()
    }

    function fToggleMacroPause(isShortcutUsed) {
        if(pIsMacroPause == false) {
            if(pEnableTimer)
            {
                pMacroTimerRunning = false
                pMacroRecordingPausedTime = Date.now()
            }
            pIsMacroPause = true
        }
        else {
            if(pEnableTimer)
            {
                pMacroTimerRunning = true
                pMacroRecordingStartTime += Date.now() - iTopbar.pMacroRecordingPausedTime
            }
            pIsMacroPause = false
        }

        if (isShortcutUsed === undefined)
            isShortcutUsed = false

        mnsBackend.onMacroPaused(isShortcutUsed)
    }

    function fPauseResumeSync() {
        if (iSyncTopbarControl.sourceComponent != undefined) {
            iSyncTopbarControl.item.pSyncPauseBtnAsset = (iSyncTopbarControl.item.pSyncPauseBtnAsset === "PauseSmall") ? "PlaySmall" : "PauseSmall"
        }
    }

    function fUpdateSyncState(isSyncing) {
        pSyncControlVisible = isSyncing
        if (iSyncTopbarControl.sourceComponent != undefined) {
            iSyncTopbarControl.item.pSyncPauseBtnAsset = isSyncing ? "PauseSmall" : "PlaySmall"
        }
    }

    function fSetImageName(imageName) {
        iImageTxt.text = imageName;
        fReloadTopbarElements();
    }

    function fShowClosePlrMsg() {
        if (pShowFeedbackPopup && !plrBackend.checkInFeedbackPopupIgnoredList(pTopActivityAppPackage))
        {
            plrBackend.addToFeedbackPopupIgnoredList(pTopActivityAppPackage)
            var iFeedbackPopupObject = iFeedbackPopupComponent.createObject(iAppwin)
            iFeedbackPopupObject.feedbackAppLabel = pTopActivityAppLabel
            iFeedbackPopupObject.feedbackAppPackage = pTopActivityAppPackage
            iFeedbackPopupObject.show()
        }
        else {
            if (plrBackend.pExitPromotionViewModel.pReady) {
                var component = Qt.createComponent("PlrExitPromotionsWindow.qml");
                if (component.status === Component.Ready) {
                    component.createObject(iAppwin).show()
                }
            }
            else
                iClosePlrPrompt.createObject(iAppwin).show()
        }
    }

    function fShowFeedbackPopup(appPackage, appLabel, showFeedbackPopup) {
        pTopActivityAppPackage = appPackage
        pTopActivityAppLabel = appLabel
        pShowFeedbackPopup = showFeedbackPopup
    }

    function fToggleQuestIcon(isQuestVisible) {
        pIsQuestEnabled = isQuestVisible
        fReloadTopbarElements()
    }

    function fHandleMiniModeClicked() {
        if (iAppwin.visibility === ApplicationWindow.Maximized)
            plrBackend.onRestoreClicked()

        sidebarHideClicked()
        pCurrentTopmostState = true
        fHandlePinToTop()

        plrBackend.resizeToMiniPlayer()

        iCfgBtn.visible = false
        fReloadTopbarElements()
    }

    function fHandlePinToTop() {
        if (true === pCurrentTopmostState)
            iAppwin.flags = iAppwin.flags | Qt.WindowStaysOnTopHint
        else
            iAppwin.flags = iAppwin.flags & ~Qt.WindowStaysOnTopHint
        plrBackend.setPinToTop(pCurrentTopmostState)

        uiBackend.confSetInstanceBool("pin_to_top", pCurrentTopmostState)
        uiBackend.confCommit()
    }

    function fHandleScreenRecordingStateChanged() {
        pIsScreenRecording = (plrBackend.pRecordMode === RecordMode.NORMAL)
        pScreenRecordingStartTime = -1
        fReloadTopbarElements()
    }
}
