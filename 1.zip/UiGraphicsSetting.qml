/*
 * Copyright (C) 2020-2021 BlueStack Systems, Inc.
 * All Rights Reserved
 *
 * THIS IS UNPUBLISHED PROPRIETARY SOURCE CODE OF BLUESTACK SYSTEMS, INC.
 * The copyright notice above does not evidence any actual or intended
 * publication of such source code.
 */

import QtQuick 2.15
import QtQuick.Controls 2.15
import QtQuick.Layouts 1.15
import QtQuick.Window 2.15
import UiToolTipControl 1.0
import DialogButtonModel 1.0
import DialogButtonModelList 1.0
import UiDialogWindow 1.0

Item {
    property bool pCompLoaded: false
    property bool pEnableSave: false
    property bool pIsVulkanSupported: false
    property bool pIsInstanceNougat: false

    property string pParentWindow: ""
    property string pVmName: ""
    property UiRadioButton pDefautEngineBtn: iPgaBtn
    property UiRadioButton pDefautRendererBtn: iOpenglBtn
    property bool pIsHwAstcSupported: false

    property ListModel pAstcConfigModel : ListModel {}

    property list<QtObject> pQtRendererModel: [
        QtObject {
            property string text: qsTranslate("QObject", "Auto")
            property string value: "Auto"
            property bool visible: true
        },
        QtObject {
            property string text: qsTranslate("QObject", "Software")
            property string value: "Software"
            property bool visible: true
        },
        QtObject {
            property string text: qsTranslate("QObject", "OpenGL")
            property string value: "OpenGLRhi"
            property bool visible: true
        },
        QtObject {
            property string text: qsTranslate("QObject", "DirectX")
            property string value: "Direct3D11Rhi"
            property bool visible: uiBackend.isDirect3D11RhiSupported()
        }
    ]

    function fOnQmlLoaded() {
        if (!pCompLoaded) {
            fInitUi()
        }
        pCompLoaded = true
    }

    ButtonGroup {
        id: iGraphicsEngineBtnGrp
        onCheckedButtonChanged: {
            if (pCompLoaded) {
                uiBackend.confSetInstanceString("graphics_engine", (checkedButton == iAgaBtn) ? "aga" : "pga")
                fMonitorChange()
            }
        }
    }

    ButtonGroup {
        id: iGraphicsRendereBtnGrp
        onCheckedButtonChanged: {
            if (pCompLoaded) {
                uiBackend.confSetInstanceString("graphics_renderer", (checkedButton == iOpenglBtn) ? "gl"
                                                                                                   : (checkedButton == iDirectxBtn) ? "dx" : "vlcn")
                fMonitorChange()
            }
        }
    }

    Component {
        id: iSaveChangesPrompt
        UiMessageDialog {
            title:qsTranslate("QObject", "Restart %1").arg(uiBackend.productName)
            pDescription: qsTranslate("QObject", "Some of the changes need %1 to restart. Do you want to restart now?").arg(uiBackend.productName)
            pDialogType: UiDialogWindow.Simple
            pButtonsList: DialogButtonModelList {
                pButtons: [
                    DialogButtonModel {
                        pColor: UiTheme.buttons.colors.accent
                        pText: qsTranslate("QObject", "Restart Now")
                        onClicked: {
                            if (uiBackend.confIsPropModified("bst.prefer_dedicated_gpu")) {
                                if (uiBackend.confGetBool("bst.prefer_dedicated_gpu"))
                                    uiBackend.runForceGpu("1")
                                else
                                    uiBackend.runForceGpu("0")
                            }

                            var notify = false
                            if (uiBackend.confIsInstancePropModified("graphics_engine") ||
                                    uiBackend.confIsInstancePropModified("graphics_renderer")) {
                                notify = true
                            }

                            iSettingsWindow.hide()
                            iSettingsWindow.showRestartLoader()
                            uiBackend.confCommit()
                            if (notify) plrBackend.instanceConfigChanged()
                            plrBackend.restartPlayer()
                            close()
                        }
                    },
                    DialogButtonModel {
                        pColor: UiTheme.buttons.colors.secondary
                        pText: qsTranslate("QObject", "Discard Changes")
                        onClicked: {
                            fDiscardChanges()
                            close()
                        }
                    }
                ]
            }
        }
    }

    UiColumnLayout {
        anchors.fill: parent
        spacing: 24
        UiScrollView {
            id: iScrollView
            Layout.fillHeight: true
            Layout.preferredWidth: parent.width
            clip: true
            contentWidth: iContentLayout.width
            contentHeight: iContentLayout.height + 20

            UiColumnLayout {
                id: iContentLayout
                width: 520
                Layout.alignment: Qt.AlignTop
                spacing: 16
                UiColumnLayout {
                    spacing: 12
                    Layout.fillWidth: true
                    visible: uiBackend.isGraphicsEngineSupported(pVmName, "pga")
                    Text {
                        text: qsTranslate("QObject", "Graphics engine mode")
                        font: UiTheme.fonts.bodyLarge
                        color: UiTheme.colors.primary10
                    }
                    UiRowLayout {
                        Layout.fillWidth: true
                        spacing: 40
                        UiColumnLayout {
                            Layout.alignment: Qt.AlignTop
                            Layout.preferredWidth: (parent.width - parent.spacing) / 2
                            UiRadioButton {
                                id: iAgaBtn
                                text: qsTranslate("QObject", "Compatibility")
                                ButtonGroup.group: iGraphicsEngineBtnGrp
                                Layout.fillWidth: true
                            }
                        }
                        UiColumnLayout {
                            Layout.alignment: Qt.AlignTop
                            Layout.preferredWidth: (parent.width - parent.spacing) / 2
                            UiRadioButton {
                                id: iPgaBtn
                                text: qsTranslate("QObject", "Performance")
                                checked: true
                                Layout.fillWidth: true
                                ButtonGroup.group: iGraphicsEngineBtnGrp
                            }
                        }
                    }
                }
                Rectangle {
                    height: 1
                    color: UiTheme.colors.seperator
                    Layout.fillWidth: true
                    visible: uiBackend.isGraphicsEngineSupported(pVmName, "pga")
                }
                UiColumnLayout {
                    spacing: 12
                    Layout.fillWidth: true
                    UiRowLayout {
                        spacing: 8
                        Text {
                            text: qsTranslate("QObject", "Graphics renderer")
                            font: UiTheme.fonts.bodyLarge
                            color: UiTheme.colors.primary10
                        }
                        UiImageButton {
                            asset: "MenuHelp"
                            pImageWidth: 16
                            pImageHeight: 16
                            UiToolTip.text: qsTranslate("QObject", "Help")
                            onClicked: uiBackend.openHelpArticle("GraphicsRenderer_Help")
                            pMouseCursor: hovered ? Qt.PointingHandCursor : Qt.ArrowCursor
                        }
                    }
                    UiRowLayout {
                        Layout.fillWidth: true
                        spacing: 40
                        UiRadioButton {
                            id: iOpenglBtn
                            Layout.preferredWidth: 160
                            Layout.alignment: Qt.AlignTop
                            text: qsTranslate("QObject", "OpenGL")
                            checked: true
                            ButtonGroup.group: iGraphicsRendereBtnGrp
                        }
                        UiRadioButton {
                            id: iDirectxBtn
                            Layout.preferredWidth: 160
                            Layout.alignment: Qt.AlignTop
                            text: qsTranslate("QObject", "DirectX")
                            ButtonGroup.group: iGraphicsRendereBtnGrp
                        }
                        UiRadioButton {
                            id: iVulkanBtn
                            visible: !pIsInstanceNougat
                            enabled: pIsVulkanSupported
                            Layout.preferredWidth: 160
                            Layout.alignment: Qt.AlignTop
                            text: qsTranslate("QObject", "Vulkan")
                            ButtonGroup.group: iGraphicsRendereBtnGrp
                        }
                    }
                }
                Rectangle {
                    height: 1
                    color: UiTheme.colors.seperator
                    Layout.fillWidth: true
                }
                UiColumnLayout {
                    spacing: 12
                    Layout.fillWidth: true
                    UiRowLayout {
                        spacing: 8
                        Text {
                            text: qsTranslate("QObject", "Interface renderer")
                            font: UiTheme.fonts.bodyLarge
                            color: UiTheme.colors.primary10
                        }
                        UiImageButton {
                            asset: "MenuHelp"
                            pImageWidth: 16
                            pImageHeight: 16
                            UiToolTip.text: qsTranslate("QObject", "Help")
                            onClicked: uiBackend.openHelpArticle("QtRenderer_Help")
                            pMouseCursor: hovered ? Qt.PointingHandCursor : Qt.ArrowCursor
                        }
                    }
                    UiComboBox {
                        id: iQtRendererCombobox
                        pSize: UiTheme.comboBoxes.sizes.medium
                        model: pQtRendererModel
                        textRole: "text"
                        valueRole: "value"
                        pVisibilityRole: "visible"
                        Layout.preferredWidth: 200
                        onActivated: {
                            if (pCompLoaded) {
                                uiBackend.confSetString("bst.qt_renderer", currentValue)
                                fMonitorChange()
                            }
                        }
                    }
                }
                Rectangle {
                    height: 1
                    color: UiTheme.colors.seperator
                    Layout.fillWidth: true
                    visible: pParentWindow === "plr"
                }
                UiColumnLayout {
                    spacing: 12
                    visible: pParentWindow === "plr"
                    UiRowLayout {
                        spacing: 8
                        Text {
                            text: qsTranslate("QObject", "ASTC Textures (Beta)")
                            font: UiTheme.fonts.bodyLarge
                            color: UiTheme.colors.primary10
                        }
                        UiImageButton {
                            asset: "MenuHelp"
                            pImageWidth: 16
                            pImageHeight: 16
                            UiToolTip.text: qsTranslate("QObject", "Help")
                            onClicked: uiBackend.openHelpArticle("ASTC_Help")
                            pMouseCursor: hovered ? Qt.PointingHandCursor : Qt.ArrowCursor
                        }
                    }
                    UiComboBox {
                        id: iAstcCombobox
                        pSize: UiTheme.comboBoxes.sizes.medium
                        model: pAstcConfigModel
                        textRole: "display_name"
                        Layout.preferredWidth: 200
                        onActivated: {
                            if (pCompLoaded) {
                                uiBackend.confSetInstanceString("astc_decoding_mode", pAstcConfigModel.get(currentIndex).name)
                                iHwAstcNotSuppportedWarningTxt.visible = (!pIsHwAstcSupported && currentIndex === 2)
                                fMonitorChange()
                            }
                        }
                    }

                    Text {
                        id: iHwAstcNotSuppportedWarningTxt
                        Layout.fillWidth: true
                        text: qsTranslate("QObject", "Hardware decoding is not available, instead Software decoding will be used")
                        font: UiTheme.fonts.bodySmall
                        color: UiTheme.colors.warning
                        wrapMode: Text.Wrap
                        horizontalAlignment: Text.AlignLeft
                    }
                }
                Rectangle {
                    height: 1
                    color: UiTheme.colors.seperator
                    Layout.fillWidth: true
                    visible: pParentWindow === "plr"
                }
                UiColumnLayout {
                    spacing: 12
                    Layout.fillWidth: true
                    visible: pParentWindow === "plr"
                    UiColumnLayout {
                        spacing: 4
                        UiRowLayout {
                            spacing: 8
                            Text {
                                text: qsTranslate("QObject", "GPU in use")
                                font: UiTheme.fonts.bodyLarge
                                color: UiTheme.colors.primary10
                                horizontalAlignment: Text.AlignLeft
                            }
                            UiImageButton {
                                asset: "MenuHelp"
                                pImageWidth: 16
                                pImageHeight: 16
                                UiToolTip.text: qsTranslate("QObject", "Help")
                                onClicked: uiBackend.openHelpArticle("GPU_Setting_Help")
                                pMouseCursor: hovered ? Qt.PointingHandCursor : Qt.ArrowCursor
                            }
                        }
                        Text {
                            id: iAvailableGpuTxt
                            text: "NVIDIA GeForce RTX 2080Ti"
                            font: UiTheme.fonts.bodySmall
                            color: UiTheme.colors.primary30
                            horizontalAlignment: Text.AlignLeft
                            Layout.fillWidth: true
                        }
                    }
                    UiRowLayout {
                        Layout.fillWidth: true
                        spacing: 8
                        Text {
                            text: qsTranslate("QObject", "Prefer dedicated GPU")
                            font: UiTheme.fonts.bodyMedium
                            color: UiTheme.colors.primary20
                            horizontalAlignment: Text.AlignLeft
                            Layout.fillWidth: true
                            elide: Text.ElideRight
                        }
                        UiToggleButton {
                            id: iToggleDedicatedGraphics
                            onCheckedChanged: {
                                uiBackend.confSetBool("bst.prefer_dedicated_gpu", checked)
                                fMonitorChange()
                            }
                        }
                    }
                }
            }
        }

        UiRowLayout {
            spacing: 4
            Layout.fillWidth: true
            Layout.preferredHeight: 36

            UiImage {
                asset: "MenuInfo"
                pImageWidth: 12
                pImageHeight: 12
            }

            Text {
                text: qsTranslate("QObject", "Changes will apply on next launch")
                font : UiTheme.fonts.bodySmall
                color: UiTheme.colors.primary20
                horizontalAlignment: Text.AlignLeft
                Layout.fillWidth: true
                elide: Text.ElideRight
            }

            UiButton{
                pSize: UiTheme.buttons.sizes.medium
                pColor: UiTheme.buttons.colors.accent
                text: qsTranslate("QObject", "Save changes")
                opacity: pEnableSave ? 1 : 0.4
                enabled: pEnableSave
                onClicked: {
                    if(pParentWindow === "plr"){
                        if (uiBackend.confIsInstancePropModified("graphics_engine") ||
                                uiBackend.confIsInstancePropModified("graphics_renderer") ||
                                uiBackend.confIsPropModified("bst.prefer_dedicated_gpu") ||
                                uiBackend.confIsPropModified("bst.qt_renderer")) {
                            iSaveChangesPrompt.createObject(iSettingsWindow).show()
                        } else {
                            fHandleConfChange()
                            fInitUi()
                            iSettingsWindow.fShowToast(qsTranslate("QObject", "Changes saved"))
                        }
                    }
                    else {
                        var notify = false
                        if (uiBackend.confIsInstancePropModified("graphics_engine") ||
                                uiBackend.confIsInstancePropModified("graphics_renderer")) {
                            notify = true
                        }
                        uiBackend.confCommit()
                        if (notify) uiBackend.instanceConfigChanged()
                        close()
                    }
                }
            }
        }
    }

    function checkNougatInstance() {
        if (pVmName.indexOf("Nougat",0) !== -1)
            return true;
        return false;
    }

    function fInitUi() {
        var engine = uiBackend.confGetInstanceString("graphics_engine")
        var renderer = uiBackend.confGetInstanceString("graphics_renderer")
        iToggleDedicatedGraphics.checked = uiBackend.confGetBool("bst.prefer_dedicated_gpu")
        pIsInstanceNougat = checkNougatInstance()
        pIsVulkanSupported = pParentWindow  === "plr" ? !pIsInstanceNougat && plrBackend.getIsVulkanSupported() :
                                                        !pIsInstanceNougat && uiBackend.confGetInstanceBool("vulkan_supported")
        if (engine === "pga")
            pDefautEngineBtn = iPgaBtn
        else
            pDefautEngineBtn = iAgaBtn

        if (renderer === "gl")
            pDefautRendererBtn = iOpenglBtn
        else if(renderer === "vlcn")
            pDefautRendererBtn = iVulkanBtn
        else
            pDefautRendererBtn = iDirectxBtn

        pDefautEngineBtn.checked = true
        pDefautRendererBtn.checked = true

        iQtRendererCombobox.currentIndex = -1
        for(var i = 0; i < pQtRendererModel.length; ++i) {
            if (pQtRendererModel[i].value === uiBackend.confGetString("bst.qt_renderer"))
                iQtRendererCombobox.currentIndex = i
        }

        pAstcConfigModel.clear()
        pAstcConfigModel.append({ display_name: qsTranslate("QObject", "Disabled"), name: "disabled" })
        pAstcConfigModel.append({ display_name: qsTranslate("QObject", "Software Decoding"), name: "software"})
        pAstcConfigModel.append({ display_name: qsTranslate("QObject", "Hardware Decoding"), name: "hardware"})

        if(pParentWindow === "plr")
        {
            pIsHwAstcSupported = plrBackend.getPgaIsHwAstcSupported() === 1
            iAvailableGpuTxt.text = plrBackend.getGraphicsRendererName()
            var astcConfig = uiBackend.confGetInstanceString("astc_decoding_mode")
            iAstcCombobox.currentIndex = find(pAstcConfigModel,
                                              function(item) { return item.name === astcConfig });
            iHwAstcNotSuppportedWarningTxt.visible = (!pIsHwAstcSupported && pAstcConfigModel.get(iAstcCombobox.currentIndex).name === "hardware")
        }
        pEnableSave = false
    }

    function fSetPreviousState() {
        fInitUi()
    }

    function fMonitorChange() {
        if (uiBackend.confIsModified()) {
            pEnableSave = true
        } else {
            pEnableSave = false
        }
    }

    function fDiscardChanges() {
        uiBackend.confDiscard()
        fInitUi()
        iSettingsWindow.fSwitchSettingPanel()
    }

    function fHandleConfChange() {
        if(pParentWindow === "plr"){
            if (uiBackend.confIsInstancePropModified("astc_decoding_mode"))
                plrBackend.setPgaAstcConfig(uiBackend.confGetInstanceString("astc_decoding_mode"))
            uiBackend.confCommit();
        }
    }

    function find(model, criteria) {
        for(var i = 0; i < model.count; ++i)
            if (criteria(model.get(i)))
                return i
        return -1
    }
}
