/*
 * Copyright (C) 2020-2021 BlueStack Systems, Inc.
 * All Rights Reserved
 *
 * THIS IS UNPUBLISHED PROPRIETARY SOURCE CODE OF BLUESTACK SYSTEMS, INC.
 * The copyright notice above does not evidence any actual or intended
 * publication of such source code.
 */

import QtQuick 2.15
import QtQuick.Layouts 1.15
import QtQuick.Window 2.15

import QtQuick.Controls 1.4
import QtQuick.Controls.Styles 1.4

import QtWebEngine 1.10

Window {
    id: iBrowserWindow

    property Item pCurrentWebView: iTabs.currentIndex < iTabs.count ? iTabs.getTab(iTabs.currentIndex).item : null
    property int pPreviousWindowState: 2
    property int pWindowStateBeforeMinimized: -1
    property int pLeftCornerWidth: pShowTabsOnTopBar ? 216 : 0
    property int pRightCornerWidth: pShowTabsOnTopBar ? 104 : 0

    property bool pCreateTabBtnVisible: true
    property bool pShowTabsOnTopBar: false

    flags: Qt.Window | Qt.FramelessWindowHint | Qt.WindowMinMaxButtonsHint
    title: pCurrentWebView && pCurrentWebView.title
    color: "transparent"
    visible: true

    onClosing: {
        while(iTabs.count > 0)
            iTabs.removeTab(0)

        iBrowserWindow.destroy()
    }

    onVisibilityChanged: {
        if (visibility === Window.Hidden)
            return

        //setting variables required to set the correct windowState when restored from minimized windowState
        if (visibility === Window.Minimized)
            pWindowStateBeforeMinimized = pPreviousWindowState
        else
            pPreviousWindowState = visibility

        //handling to set the correct windowState when restored from minimized state
        if (pWindowStateBeforeMinimized === Window.Maximized && visibility === Window.Windowed) {
            pWindowStateBeforeMinimized = -1
            iBrowserWindow.showMaximized()
        }
    }

    MouseArea {
        anchors.fill: parent
        hoverEnabled: true
        acceptedButtons: Qt.LeftButton

        property int edges: 0
        property int edgeOffest: iBrowserWindow.visibility === Window.Maximized ? 0 : 3

        function setEdges(x, y) {
            edges = 0
            if(x < edgeOffest) edges |= Qt.LeftEdge
            if(x > (width - edgeOffest))  edges |= Qt.RightEdge
            if(y < edgeOffest) edges |= Qt.TopEdge
            if(y > (height - edgeOffest)) edges |= Qt.BottomEdge
        }

        cursorShape: {
            return !containsMouse ? Qt.ArrowCursor : edges == 3 || edges == 12
                                    ? Qt.SizeFDiagCursor : edges == 5 || edges == 10
                                      ? Qt.SizeBDiagCursor : edges & 9
                                        ? Qt.SizeVerCursor : edges & 6
                                          ? Qt.SizeHorCursor : Qt.ArrowCursor
        }

        onPositionChanged: setEdges(mouseX, mouseY)
        onPressed: {
            setEdges(mouseX, mouseY)
            if(edges && containsMouse) {
                startSystemResize(edges)
            }
        }
    }

    Component {
        id: iLeftCornerComp
        UiRowLayout {
            width: 232
            height: 32
            leftPadding: 10
            rightPadding: 8
            spacing: 8
            UiImage {
                asset: "BlueStacksLogo"
                pImageWidth: 20
                pImageHeight: 20
            }
            UiColumnLayout {
                topPadding: 2
                bottomPadding: 2
                Text {
                    text: "BlueStacks Browser"
                    Layout.maximumWidth: 120
                    wrapMode: Text.NoWrap
                    elide: Text.ElideRight
                    color: UiTheme.colors.primary10
                    font: UiTheme.fonts.bodySmall
                }
                Text {
                    text: "powered by OGSA"
                    wrapMode: Text.NoWrap
                    elide: Text.ElideRight
                    color: UiTheme.colors.primary30
                    font: UiTheme.fonts.bodyTiny
                }
            }
            Rectangle {
                Layout.preferredWidth: 1
                Layout.preferredHeight: 32
                color: UiTheme.colors.primary50
            }
            UiImageButton {
                asset: "Backward"
                pImageWidth: 16
                pImageHeight: 16
                onClicked: pCurrentWebView.goBack()
                enabled: pCurrentWebView && pCurrentWebView.canGoBack
                activeFocusOnTab: true
            }
            Rectangle {
                Layout.preferredWidth: 1
                Layout.preferredHeight: 32
                color: UiTheme.colors.primary50
            }
            UiImageButton {
                asset:  pCurrentWebView && pCurrentWebView.pIsLoading ? "CloseIcon" : "Refresh"
                pImageWidth: 16
                pImageHeight: 16
                onClicked: pCurrentWebView && pCurrentWebView.pIsLoading ? pCurrentWebView.stop() : pCurrentWebView.reload()
            }
        }
    }

    Component {
        id: iRightCornerComp
        UiRowLayout {
            color: UiTheme.colors.primary90
            width: 104
            height: 32
            leftPadding: 8
            visible: pShowTabsOnTopBar
            UiImageButton {
                asset: "TitlebarMinimize"
                pImageWidth: 32
                pImageHeight: 32
                onClicked: {
                    iBrowserWindow.showMinimized()
                }
            }

            UiImageButton {
                asset: "TitlebarMaximize"
                pImageWidth: 32
                pImageHeight: 32
                visible: iBrowserWindow.visibility === Window.Windowed
                onClicked: {
                    iBrowserWindow.showMaximized()
                }
            }

            UiImageButton {
                asset: "TitlebarRestore"
                pImageWidth: 32
                pImageHeight: 32
                visible: iBrowserWindow.visibility === Window.Maximized
                onClicked: {
                    iBrowserWindow.showNormal()
                }
            }

            UiImageButton {
                asset: "TitlebarClose"
                pImageWidth: 32
                pImageHeight: 32
                onClicked: {
                    iBrowserWindow.close()
                }
            }
        }
    }

    Rectangle {
        anchors.fill: parent
        anchors.margins: iBrowserWindow.visibility === Window.Maximized ? 0 : 2
        color: UiTheme.colors.primary60
        Item {
            anchors.fill: parent
            anchors.margins: 1

            TabView {
                id: iTabs
                anchors.fill: parent
                anchors.topMargin: pShowTabsOnTopBar ? 0 : 32

                function createEmptyTab() {
                    var tab = iTabs.addTab("", iTabComponent)
                    tab.active = true
                    tab.title = Qt.binding(function() { return tab.item.title ? tab.item.title : 'New Tab' })
                    return tab
                }

                function indexOfView(view) {
                    for (let i = 0; i < iTabs.count; ++i)
                        if (iTabs.getTab(i).item === view)
                            return i
                    return -1
                }

                function removeView(index) {
                    if (iTabs.count > 1)
                        iTabs.removeTab(index)
                    else
                        iBrowserWindow.close()
                }

                Component.onCompleted: iTabs.createEmptyTab()

                style: TabViewStyle {
                    frameOverlap: 0
                    frame: Rectangle {
                        color: UiTheme.colors.primary100
                    }
                    tabBar: Rectangle {
                        color: UiTheme.colors.primary90
                        MouseArea {
                            enabled: pShowTabsOnTopBar
                            anchors.fill: parent
                            property var startingPosition
                            property bool isPressed: false

                            onPressed: {
                                isPressed = true
                                startingPosition  = Qt.point(mouse.x, mouse.y)
                            }
                            onReleased: {
                                isPressed = false
                                if (iBrowserWindow.y < Screen.virtualY) {
                                    iBrowserWindow.y = Screen.virtualY
                                }
                            }

                            onPositionChanged: {
                                if (isPressed) {
                                    var delta = Qt.point(mouse.x - startingPosition.x, mouse.y - startingPosition.y)
                                    iBrowserWindow.x += delta.x
                                    iBrowserWindow.y += delta.y
                                }
                            }

                            onDoubleClicked: {
                                iBrowserWindow.visibility === Window.Windowed ?
                                            iBrowserWindow.showMaximized() :
                                            iBrowserWindow.showNormal()
                            }
                        }
                    }

                    leftCorner: pShowTabsOnTopBar ? iLeftCornerComp : null
                    rightCorner: pShowTabsOnTopBar ? iRightCornerComp : null

                    tab: UiRowLayout {
                        implicitWidth: Math.min((iBrowserWindow.width - pLeftCornerWidth - pRightCornerWidth - 36) / iTabs.count, (iBrowserWindow.width - pLeftCornerWidth - pRightCornerWidth - 36) / 4) + (iCreateNewTab.visible ? iCreateNewTab.width : 0)
                        implicitHeight: pShowTabsOnTopBar ? 32 : 64

                        property Item currentTabWebview: iTabs.getTab(styleData.index) ? iTabs.getTab(styleData.index).item : null

                        UiRowLayout {
                            color: styleData.selected ? UiTheme.colors.primary70 : UiTheme.colors.primary90
                            Layout.fillWidth: true
                            Layout.preferredHeight: 32
                            Layout.alignment: Qt.AlignTop | Qt.AlignRight
                            leftPadding: 8
                            spacing: 8
                            clip: true
                            UiImage {
                                source: currentTabWebview == null || currentTabWebview.pIsLoading
                                        ? "qrcAssets/SiteLoader.svg"
                                        : currentTabWebview.icon && currentTabWebview.icon != ""
                                          ? currentTabWebview.icon
                                          : "qrcAssets/DefaultFavicon.svg"
                                pImageWidth: 16
                                pImageHeight: 16
                                rotation: currentTabWebview && currentTabWebview.pIsLoading ? 0 : 0
                                RotationAnimation on rotation {
                                    loops: Animation.Infinite
                                    duration: 2000
                                    from: 0
                                    to: 360
                                    direction: RotationAnimation.Clockwise
                                    running: currentTabWebview && currentTabWebview.pIsLoading
                                }
                            }
                            Text {
                                id: iTitletext
                                Layout.fillWidth: true
                                text: styleData.title
                                elide: Text.ElideRight
                                color: styleData.selected ? UiTheme.colors.white : UiTheme.colors.primary20
                            }
                            UiImageButton {
                                asset: "CloseIcon"
                                pImageWidth: 12
                                pImageHeight: 12
                                onClicked: iTabs.removeView(styleData.index)
                                activeFocusOnTab: true
                            }
                            UiRowLayout {
                                Rectangle {
                                    Layout.preferredHeight: 20
                                    Layout.preferredWidth: styleData.selected ? 0 : 1
                                    color: UiTheme.colors.primary60
                                }
                                Rectangle {
                                    id: iCreateNewTab
                                    Layout.preferredWidth: 32
                                    Layout.preferredHeight: 32
                                    color: UiTheme.colors.primary90
                                    visible: styleData.index === iTabs.count - 1 && pCreateTabBtnVisible
                                    UiImageButton {
                                        asset: "AddSmall"
                                        pImageWidth: 12
                                        pImageHeight: 12
                                        anchors.centerIn: parent
                                        onClicked: {
                                            iTabs.createEmptyTab()
                                            iTabs.currentIndex = iTabs.count - 1
                                        }
                                        activeFocusOnTab: true
                                    }
                                }
                            }
                        }
                    }
                }

                Component {
                    id: iTabComponent

                    WebEngineView {
                        id: iWebEngineView
                        focus: true

                        settings.javascriptCanAccessClipboard: true
                        settings.javascriptCanOpenWindows: true
                        settings.javascriptEnabled: true
                        settings.javascriptCanPaste: true
                        settings.pluginsEnabled: true
                        profile.httpAcceptLanguage: uiBackend.getPreferredLocaleWeighted()

                        property bool pIsLoading: false

                        onLoadProgressChanged: {
                            if (iWebEngineView.loadProgress > 0 && iWebEngineView.loadProgress <= 99)
                                iWebEngineView.pIsLoading = true
                            else
                                iWebEngineView.pIsLoading = false
                        }

                        onNewViewRequested: function(request) {
                            if (!request.userInitiated) {
                                console.info("Warning: Blocked a popup window.")
                            }
                            else if (request.destination === WebEngineView.NewViewInTab) {
                                var tab = iTabs.createEmptyTab()
                                iTabs.currentIndex = iTabs.count - 1
                                request.openIn(tab.item)
                            }
                            else if (request.destination === WebEngineView.NewViewInBackgroundTab) {
                                var backgroundTab = iTabs.createEmptyTab()
                                request.openIn(backgroundTab.item)
                            }
                            else {
                                var iBrowserComponent = Qt.createComponent("UiBrowserWindow.qml")
                                if (iBrowserComponent.status === Component.Ready) {
                                    var win = iBrowserComponent.createObject(null, {
                                                                                 "x": 300,
                                                                                 "y": 50,
                                                                                 "width": 1000,
                                                                                 "height": 800,
                                                                                 "pShowTabsOnTopBar": pShowTabsOnTopBar,
                                                                                 "pCreateTabBtnVisible": pCreateTabBtnVisible
                                                                             })
                                    request.openIn(win.pCurrentWebView)
                                }
                            }
                        }

                        onRegisterProtocolHandlerRequested: function(request) {
                            console.info("accepting registerProtocolHandler request for " + request.scheme + " from " + request.origin)
                            request.accept()
                        }

                        onRenderProcessTerminated: function(terminationStatus, exitCode) {
                            var status = "";
                            switch (terminationStatus) {
                            case WebEngineView.NormalTerminationStatus:
                                status = "(normal exit)"
                                break
                            case WebEngineView.AbnormalTerminationStatus:
                                status = "(abnormal exit)"
                                break
                            case WebEngineView.CrashedTerminationStatus:
                                status = "(crashed)"
                                break
                            case WebEngineView.KilledTerminationStatus:
                                status = "(killed)"
                                break
                            }

                            console.info("Render process exited with code " + exitCode + " " + status)
                            reloadTimer.running = true
                        }

                        onWindowCloseRequested: {
                            iTabs.removeView(iTabs.indexOfView(iWebEngineView))
                        }

                        Timer {
                            id: reloadTimer
                            interval: 0
                            running: false
                            repeat: false
                            onTriggered: iWebEngineView.reload()
                        }
                    }
                }
            }

            UiRowLayout {
                id: iTopBar
                anchors.left: parent.left
                anchors.right: parent.right
                anchors.top: parent.top
                color: UiTheme.colors.primary90
                visible: !pShowTabsOnTopBar

                pMouseArea {
                    enabled: true
                    anchors.fill: iTopBar
                    property var startingPosition
                    property bool isPressed: false

                    onPressed: {
                        isPressed = true
                        startingPosition  = Qt.point(mouse.x, mouse.y)
                    }
                    onReleased: {
                        isPressed = false
                        if (iBrowserWindow.y < Screen.virtualY) {
                            iBrowserWindow.y = Screen.virtualY
                        }
                    }

                    onPositionChanged: {
                        if (isPressed) {
                            var delta = Qt.point(mouse.x - startingPosition.x, mouse.y - startingPosition.y)
                            iBrowserWindow.x += delta.x
                            iBrowserWindow.y += delta.y
                        }
                    }

                    onDoubleClicked: {
                        iBrowserWindow.visibility === Window.Windowed ?
                                    iBrowserWindow.showMaximized() :
                                    iBrowserWindow.showNormal()
                    }
                }

                UiRowLayout {
                    Layout.fillWidth: true
                    leftPadding: 10
                    spacing: 8
                    UiImage {
                        asset: "BlueStacksLogo"
                        pImageWidth: 20
                        pImageHeight: 20
                    }
                    Text {
                        Layout.fillWidth: true
                        text: qsTranslate("QObject", "%1 Browser").arg(uiBackend.productName)
                        color: UiTheme.colors.primary10
                        font: UiTheme.fonts.bodySmall
                    }
                }

                UiImageButton {
                    asset: "TitlebarMinimize"
                    pImageWidth: 32
                    pImageHeight: 32
                    onClicked: {
                        iBrowserWindow.showMinimized()
                    }
                }

                UiImageButton {
                    asset: "TitlebarMaximize"
                    pImageWidth: 32
                    pImageHeight: 32
                    visible: iBrowserWindow.visibility === Window.Windowed
                    onClicked: {
                        iBrowserWindow.showMaximized()
                    }
                }

                UiImageButton {
                    asset: "TitlebarRestore"
                    pImageWidth: 32
                    pImageHeight: 32
                    visible: iBrowserWindow.visibility === Window.Maximized
                    onClicked: {
                        iBrowserWindow.showNormal()
                    }
                }

                UiImageButton {
                    asset: "TitlebarClose"
                    pImageWidth: 32
                    pImageHeight: 32
                    onClicked: {
                        iBrowserWindow.close()
                    }
                }
            }

            UiRowLayout {
                anchors.left: parent.left
                anchors.right: parent.right
                anchors.top: parent.top
                anchors.topMargin: 64
                color: UiTheme.colors.primary70
                leftPadding: 8
                rightPadding: 8
                topPadding: 4
                bottomPadding: 4
                spacing: 8
                visible: !pShowTabsOnTopBar
                UiImageButton {
                    asset: "Backward"
                    pImageWidth: 16
                    pImageHeight: 16
                    onClicked: pCurrentWebView.goBack()
                    enabled: pCurrentWebView && pCurrentWebView.canGoBack
                    activeFocusOnTab: true
                }
                UiImageButton {
                    asset: "Forward"
                    pImageWidth: 16
                    pImageHeight: 16
                    onClicked: pCurrentWebView.goForward()
                    enabled: pCurrentWebView && pCurrentWebView.canGoForward
                    activeFocusOnTab: true
                }
                UiImageButton {
                    asset: pCurrentWebView && pCurrentWebView.pIsLoading ? "CloseIcon" : "Reload"
                    pImageWidth: 16
                    pImageHeight: 16
                    onClicked: pCurrentWebView && pCurrentWebView.pIsLoading ? pCurrentWebView.stop() : pCurrentWebView.reload()
                    activeFocusOnTab: true
                }
                UiTextField {
                    Layout.fillWidth: true
                    pSize: UiTheme.textFields.sizes.small
                    text: pCurrentWebView && pCurrentWebView.url
                    onAccepted: pCurrentWebView.url = uiBackend.fromUserInputInBrowser(text)
                }
            }
        }
    }

    function createNewTab(request = null) {
        var tab = iTabs.createEmptyTab()
        iTabs.currentIndex = iTabs.count - 1
        if (request)
            request.openIn(tab.item)
    }
}
