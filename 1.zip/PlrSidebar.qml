import QtQuick 2.15
import QtQuick.Controls 2.15
import QtQuick.Layouts 1.15
import QtQuick.Window 2.15
import Qt.labs.platform 1.1
import QtQuick.Shapes 1.12

import PlrScreenRecord 1.0

import UiToolTipControl 1.0
import UiShortcutToolTip 1.0
import DialogButtonModel 1.0
import DialogButtonModelList 1.0
import UiDialogWindow 1.0
import UiFolderDialog 1.0

Rectangle {
    id: iSidebar
    objectName: "sidebar"
    property int pSidebarElementSize: 32
    width: 0
    visible: false
    property int pVisibleSidebarElementsCount: 0

    property KmmEditorWindow pKmmEditorWindow: null
    property bool pGameControlsEnabled: true
    property bool pIsGameControlsOverlayEnabled: true
    property bool pGameControlsSensitivityEnabled: false
    property bool pGameControlsPopupLoaded: false

    property bool pGamepadControlsPresent: false
    property bool pGameControlsGamepadSelected: true

    property bool pMouseCursorLocked: false

    property bool pIsMuted: false
    property int pCurrentVolumeLevel: 7
    property int pMaxVolumeLevel: 15
    property Timer pVolumePopupTimer: null

    component PlrSidebarElement: QtObject {
        property string pElementId:""
        property string pAsset:""
        property string pTooltipText:""
        property var pConfShortcutProperty: [{}]
        property bool pIsFeatureEnable: true
        property bool pIsEnable: true
        property bool pShowViaRepeaterOnly: true
        property bool pShowOnKebabMenu: true
        property bool pRunImageAnimation: false
        property int pAcceptedMouseButtons: Qt.LeftButton

        property string pLoaderAsset: ""
        property bool pLoaderRunning: false

        signal clicked(var mouseButton, var mouseModifier)
        signal mouseReleased(var mouseButton, var mouseModifier)
        signal positionChanged()
    }

    PlrSidebarProperties{id:iSidebarProperties}

    readonly property string pFullscreen    : "fullscreen"
    readonly property string pVolume        : "volume"
    readonly property string pGameControl   : "gameControl"
    readonly property string pInstallApk    : "installApk"
    readonly property string pSettings      : "settings"
    readonly property string pBack          : "back"
    readonly property string pHome          : "home"
    readonly property string pRecent        : "recent"

    signal sidebarSettingClicked

    property UiWindowedPopup pKebabMenuWin: null
    property UiWindowedPopup pVolumeWin: null
    property UiWindowedPopup pGameControlsWin: null
    property UiWindowedPopup pFullScreenBlurbWin: null

    property list<QtObject> pAllSidebarItems: [
        PlrSidebarElement {
            pElementId: pFullscreen
            pAsset: "SidebarFullScreen"
            pTooltipText: qsTranslate("QObject", "Toggle fullscreen")
            pConfShortcutProperty: [{ value: "toggle_fullscreen"}]
            pIsFeatureEnable: iSidebarProperties.pIsFullScreenEnabled
            pIsEnable: iAppwin.pIsBootComplete
            onClicked: {
                plrBackend.logUIAction("Sidebar", "ToggleFullscreen")
                plrBackend.onFullscreenClicked(true)
            }
        },
        PlrSidebarElement {
            pElementId: pVolume
            pAsset: pIsMuted ? "SidebarMute": "SidebarSound"
            pIsFeatureEnable: iSidebarProperties.pIsVolumeEnabled
            pConfShortcutProperty: [
                { text:  qsTranslate("QObject", "Increase volume"), value: "increase_volume" },
                { text:  qsTranslate("QObject", "Decrease volume"), value: "decrease_volume" }
            ]

            pIsEnable: iAppwin.pIsBootComplete
            onClicked: {
                plrBackend.logUIAction("Sidebar", "Volume")
                fOpenVolumePopup(false)
            }
        },
        PlrSidebarElement {
            pElementId: pGameControl
            pAsset: "SidebarControls"
            pIsFeatureEnable: iSidebarProperties.pIsGameControlEnabled
            pTooltipText: qsTranslate("QObject", "Game controls")
            pIsEnable: iAppwin.pIsBootComplete
            pAcceptedMouseButtons: Qt.LeftButton | Qt.RightButton
            onMouseReleased: {
                plrBackend.logUIAction("Sidebar", "GameControls")
                if(mouseButton === Qt.LeftButton)
                    fOpenGameControlsPopup()
                else {
                    if (mouseButton === Qt.RightButton) {
                        if((mouseModifier & Qt.ControlModifier) && (mouseModifier & Qt.AltModifier)) {
                            fOpenControlsEditorWindow(true)
                        }
                        else
                            fOpenControlsEditorWindow(false)
                    }
                }
            }
        },
        PlrSidebarElement {
            pElementId: pInstallApk
            pAsset: "SidebarInstallApk"
            pTooltipText: qsTranslate("QObject", "Install APK")
            pConfShortcutProperty: [{ value: "install_apk"}]
            pIsEnable: iAppwin.pIsBootComplete
            pIsFeatureEnable: iSidebarProperties.pIsInstallApkEnabled
            onClicked: {
                plrBackend.logUIAction("Sidebar", "InstallApk")
                fHandleInstallApkBtnClicked()
            }
        },
        PlrSidebarElement {
            pElementId: pSettings
            pAsset: "SidebarSettings"
            pTooltipText: qsTranslate("QObject", "Settings")
            pConfShortcutProperty: [{ value: "open_settings"}]
            pShowViaRepeaterOnly: false
            pShowOnKebabMenu: !iSettingsBtn.visible
            onClicked: {
                plrBackend.logUIAction("Sidebar", "Settings")
                sidebarSettingClicked()
            }
        },
        PlrSidebarElement {
            pElementId: pBack
            pAsset: "SidebarBack"
            pTooltipText: qsTranslate("QObject", "Back")
            pConfShortcutProperty: [{ value: "go_back"}]
            pIsEnable: iAppwin.pIsBootComplete
            pShowViaRepeaterOnly: false
            pShowOnKebabMenu: !iBackBtn.visible
            onClicked: {
                plrBackend.logUIAction("Sidebar", "Back")
                plrBackend.onBackClicked()
            }
        },
        PlrSidebarElement {
            pElementId: pHome
            pAsset: "SidebarHome"
            pTooltipText: qsTranslate("QObject", "Home")
            pConfShortcutProperty: [{ value: "go_home"}]
            pIsEnable: iAppwin.pIsBootComplete
            pShowViaRepeaterOnly: false
            pShowOnKebabMenu: !iHomeBtn.visible
            onClicked: {
                plrBackend.logUIAction("Sidebar", "Home")
                plrBackend.onHomeClicked()
            }
        },
        PlrSidebarElement {
            pElementId: pRecent
            pAsset: "SidebarRecents"
            pTooltipText: qsTranslate("QObject", "Recent apps")
            pConfShortcutProperty: [{ value: "open_recent_apps"}]
            pIsEnable: iAppwin.pIsBootComplete
            pShowViaRepeaterOnly: false
            pShowOnKebabMenu: !iRecentBtn.visible
            onClicked: {
                plrBackend.logUIAction("Sidebar", "RecentApps")
                plrBackend.onRecentAppsClicked()
            }
        }
    ]

    property list<QtObject> pSidebarItems
    Component.onCompleted: {
        pIsGameControlsOverlayEnabled = uiBackend.confGetBool("bst.key_controls_overlay_enabled")
        pGameControlsEnabled = uiBackend.confGetInstanceBool("game_controls_enabled")
    }

    onHeightChanged: {
        fResetSidebar()
    }

    function fResetSidebar() {
        var availableHeight = iSidebar.height

        // accomodate for iKebabMenuBtn when sidebar items are hidden
        if(iSidebar.height < 32 * 6)
            availableHeight = availableHeight - iKebabMenuBtn.height

        if(availableHeight >= iRecentBtn.height) {
            iRecentBtn.visible = true
            availableHeight = availableHeight - iRecentBtn.height
        } else { iRecentBtn.visible = false }

        if(availableHeight >= iHomeBtn.height) {
            iHomeBtn.visible = true
            availableHeight = availableHeight - iHomeBtn.height
        } else { iHomeBtn.visible = false }

        if(availableHeight >= iBackBtn.height) {
            iBackBtn.visible = true
            availableHeight = availableHeight - iBackBtn.height
        } else { iBackBtn.visible = false }

        if(availableHeight >= iSettingsBtn.height) {
            iSettingsBtn.visible = true
            availableHeight = availableHeight - iSettingsBtn.height
        } else { iSettingsBtn.visible = false }

        pSidebarItems = []
        if(availableHeight > 0) {
            var repeaterElements = 0
            for (var i = 0; i < pAllSidebarItems.length; i++)
                if(pAllSidebarItems[i].pShowViaRepeaterOnly && pAllSidebarItems[i].pIsFeatureEnable)
                {
                    pSidebarItems.push(pAllSidebarItems[i]);
                    repeaterElements++
                }
            var count = Math.floor(availableHeight / pSidebarElementSize)
            if(count >= repeaterElements)
            {
                iKebabMenuBtn.visible = false
                pVisibleSidebarElementsCount = repeaterElements

            } else {
                iKebabMenuBtn.visible = true
                pVisibleSidebarElementsCount = count-1
            }
        }
    }

    Component {
        id: iFileDialogComponent
        FileDialog {
            id: iFileDialog
            title: qsTranslate("QObject", "Please choose a file")
            nameFilters: ["Android Files (*.apk *.xapk)"]
            fileMode: FileDialog.OpenFiles
            visible: false
            onAccepted: {
                iFileDialog.close()
                iFileDialog.destroy()
                for (var i = 0; i < iFileDialog.files.length; ++i) {
                    var path = iFileDialog.files[i].toString()
                    path = path.replace(/^(file:\/{3})|(qrc:\/{2})|(http:\/{2})/, "")
                    plrBackend.onInstallApkClicked(path)
                }
            }
        }
    }

    Component {
        id: iVolumePopupTimerComponent
        Timer {
            repeat: false
            interval: 2000
            running: false
            onTriggered: {
                fCloseVolumePopup()
            }
        }
    }

    function fStartVolumePopupTimer() {
        if (pVolumePopupTimer == null)
            pVolumePopupTimer = iVolumePopupTimerComponent.createObject()

        pVolumePopupTimer.restart()
    }

    function fCloseVolumePopup() {
        if (pVolumeWin != null && pVolumeWin.visible)
            pVolumeWin.close()

        if (pVolumePopupTimer != null)
            pVolumePopupTimer.destroy()
    }

    Component {
        id: iVolumePopupComponent
        UiWindowedPopup {
            contentWidth: 180
            contentHeight: iVolumePopupLayout.implicitHeight
            visible: false

            UiColumnLayout {
                id: iVolumePopupLayout
                spacing: 8
                color: UiTheme.colors.primary70
                padding: 8
                border.width: 1
                border.color: UiTheme.colors.primary60
                anchors.fill: parent
                Layout.margins: 8

                MouseArea {
                    Layout.preferredHeight: iVolumeSliderLayout.implicitHeight
                    hoverEnabled: true
                    onEntered: {
                        if (pVolumePopupTimer != null)
                            pVolumePopupTimer.stop()
                    }
                    onExited: {
                        fStartVolumePopupTimer()
                    }
                    UiRowLayout {
                        id: iVolumeSliderLayout
                        spacing: 4
                        color: UiTheme.colors.primary70

                        UiImageButton {
                            asset: pIsMuted ? "VolumeMute" : "Volume"
                            pImageHeight: 16
                            pImageWidth: 16
                            pUseShortcutTooltip: true
                            UiShortcutToolTip.text: qsTranslate("QObject", "Mute/Unmute")
                            UiShortcutToolTip.shortcutMap: [{ value: "mute_unmute" }]
                            onClicked: {
                                fRequestMuteUnmute()
                            }
                        }

                        UiSlider {
                            pSize: UiTheme.sliders.sizes.small
                            from: 0
                            to: pMaxVolumeLevel
                            stepSize: 1
                            live: false
                            value: pCurrentVolumeLevel
                            Layout.preferredWidth: 144
                            onValueChanged: {
                                if (pCurrentVolumeLevel !== parseInt(value))
                                    fVolumeSliderChanged(parseInt(value))
                            }
                        }
                    }
                }

                Rectangle {
                    height: 1
                    color: UiTheme.colors.primary60
                    Layout.fillWidth: true
                }

                UiButton {
                    id: iMuteAllInstancesTxt
                    Layout.maximumWidth: parent.width
                    text: qsTranslate("QObject", "Mute all instances")
                    pSize: UiTheme.buttons.sizes.small
                    pColor: UiTheme.buttons.colors.outline
                    Layout.alignment: Qt.AlignLeft
                    onClicked: {
                        plrBackend.enableMuteModeForRunningInstances(true)
                    }
                }
            }
        }
    }

    Component {
        id: iGameControlsPopupComponent
        UiWindowedPopup {
            id: iGameControlsPopup
            contentWidth: iContentRect.width
            contentHeight: iContentRect.height
            visible: false
            property alias schemeModel: iSchemeCombobox.model
            property alias schemeIdx: iSchemeCombobox.currentIndex

            onSchemeModelChanged: { if (schemeModel.length < 1) iSchemeColumn.visible = false }
            onWidthChanged: {
                iGameControlsPopup.x = iSidebar.mapToGlobal(0, 0).x - iGameControlsPopup.width + iGameControlsPopup.shadowThickness
            }
            function updateSenstivity() {
                iMouseSensitivityXSpinBox.realValue =  kmmBackend.mouseSensitivityX
                iMouseSensitivityYSpinBox.realValue =  kmmBackend.mouseSensitivityY
            }

            Rectangle {
                id: iContentRect
                width: iContentLayout.width + iContentLayout.anchors.leftMargin + iContentLayout.anchors.rightMargin
                height: iContentLayout.height + iContentLayout.anchors.topMargin + iContentLayout.anchors.bottomMargin
                color: UiTheme.colors.primary70
                border.width: 1
                border.color: UiTheme.colors.primary60
                ColumnLayout {
                    id: iContentLayout
                    width: Math.max(164, childrenRect.width)
                    anchors.centerIn: parent
                    anchors.margins: 8
                    spacing: 8
                    RowLayout {
                        spacing: 4
                        Layout.fillWidth: true
                        Layout.preferredHeight: childrenRect.height
                        Text {
                            text: qsTranslate("QObject", "Game controls")
                            font: UiTheme.fonts.titleExtraSmall
                            color: UiTheme.colors.primary10
                            horizontalAlignment: Text.AlignLeft
                        }
                        Item {
                            Layout.fillWidth: true
                        }
                        RowLayout {
                            Layout.preferredWidth: childrenRect.width
                            Layout.preferredHeight: childrenRect.height
                            spacing: 4
                            UiImageButton {
                                asset: "MenuHelp"
                                pImageHeight: 16
                                pImageWidth: 16
                                UiToolTip.text: qsTranslate("QObject", "Help")
                                onClicked: uiBackend.openHelpArticle("game_controls_help")
                                pMouseCursor: hovered ? Qt.PointingHandCursor : Qt.ArrowCursor
                            }
                            UiToggleButton {
                                id: iGameControlsToggleBtn
                                checked: pGameControlsEnabled
                                pSize: UiTheme.toggleButtons.sizes.small
                                pUseShortcutTooltip: true
                                UiShortcutToolTip.text: qsTranslate( "QObject", "Toggle game controls")
                                UiShortcutToolTip.shortcutMap: [{ value: "enable_disable_game_controls" }]
                                onCheckedChanged: {
                                    if (pGameControlsPopupLoaded) {
                                        kmmBackend.setKeyMappingState(checked)
                                        kmmBackend.toggleOverlayVisibility(checked ? iOverlayToggleBtn.checked : checked, false)
                                    }
                                }
                            }
                        }
                    }

                    Rectangle {
                        Layout.fillWidth: true
                        Layout.preferredHeight: 1
                        color: UiTheme.colors.primary60
                    }

                    RowLayout {
                        id: iOverlayRow
                        Layout.fillWidth: true
                        Layout.preferredHeight: childrenRect.height
                        spacing: 4
                        enabled: iGameControlsToggleBtn.checked
                        opacity: enabled ? 1 : 0.5
                        Text {
                            text: qsTranslate("QObject", "On-screen controls")
                            font: UiTheme.fonts.bodySmall
                            color: UiTheme.colors.primary20
                            horizontalAlignment: Text.AlignLeft
                        }
                        Item {
                            Layout.fillWidth: true
                        }
                        UiToggleButton {
                            id: iOverlayToggleBtn
                            pSize: UiTheme.toggleButtons.sizes.small
                            checked: pIsGameControlsOverlayEnabled
                            pUseShortcutTooltip: true
                            UiShortcutToolTip.text: qsTranslate("QObject", "Show/Hide on-screen controls")
                            UiShortcutToolTip.shortcutMap: [{ value: "show_hide_on_screen_controls" }]
                            onCheckedChanged: {
                                pIsGameControlsOverlayEnabled = checked
                                kmmBackend.toggleOverlayVisibility(pIsGameControlsOverlayEnabled, true)
                            }
                        }
                    }

                    RowLayout {
                        Layout.fillWidth: true
                        Layout.preferredHeight: childrenRect.height
                        spacing: 4
                        enabled: iOverlayRow.enabled && iOverlayToggleBtn.checked
                        Text {
                            text: qsTranslate("QObject", "Opacity")
                            font: UiTheme.fonts.bodySmall
                            color: UiTheme.colors.primary20
                            horizontalAlignment: Text.AlignLeft
                            opacity: enabled ? 1 : 0.5
                        }
                        Item {
                            Layout.fillWidth: true
                        }
                        UiSlider {
                            pSize: UiTheme.sliders.sizes.small
                            from: 0
                            to: 100
                            stepSize: 1
                            value: uiBackend.confGetI32("bst.key_controls_overlay_opacity")
                            Layout.preferredWidth: 80
                            onValueChanged: kmmBackend.setOverlayTransparency( parseInt(value) )
                            onPressedChanged: kmmBackend.saveOverlayOpacityInConf( parseInt(value) )
                        }
                    }

                    RowLayout {
                        Layout.fillWidth: true
                        Layout.preferredHeight: childrenRect.height
                        spacing: 8
                        enabled: iOverlayRow.enabled && iOverlayToggleBtn.checked
                        Text {
                            text: qsTranslate("QObject", "Controls for")
                            font: UiTheme.fonts.bodySmall
                            color: UiTheme.colors.primary20
                            horizontalAlignment: Text.AlignLeft
                            opacity: enabled ? 1 : 0.5
                        }
                        Item {
                            Layout.fillWidth: true
                        }
                        UiImageButton {
                            asset: pGameControlsGamepadSelected ? "Keyboard" : "Keyboard_click"
                            pDisableClickAndHoveredState: !pGameControlsGamepadSelected
                            pImageHeight: 16
                            pImageWidth: 16
                            UiToolTip.text: qsTranslate("QObject", "Keyboard and mouse")
                            onClicked: {
                                pGameControlsGamepadSelected = false
                                kmmBackend.gamepadControlsSelected = false
                            }
                        }
                        UiImageButton {
                            asset: (enabled && pGameControlsGamepadSelected) ? "Gamepad_click" : "Gamepad"
                            pDisableClickAndHoveredState: enabled && pGameControlsGamepadSelected
                            pImageHeight: 16
                            pImageWidth: 16
                            UiToolTip.text: qsTranslate("QObject", "Gamepad")
                            enabled: pGamepadControlsPresent
                            onClicked: {
                                pGameControlsGamepadSelected = true
                                kmmBackend.gamepadControlsSelected = true
                            }
                        }
                    }

                    Rectangle {
                        Layout.fillWidth: true
                        Layout.preferredHeight: 1
                        color: UiTheme.colors.primary60
                        visible: iSchemeColumn.visible
                    }
                    ColumnLayout {
                        id: iSchemeColumn
                        Layout.fillWidth: true
                        Layout.preferredHeight: childrenRect.height
                        spacing: 4
                        enabled: iOverlayRow.enabled
                        opacity: enabled ? 1 : 0.5
                        Text {
                            text: qsTranslate("QObject", "Scheme")
                            font: UiTheme.fonts.bodySmall
                            color: UiTheme.colors.primary10
                        }
                        UiComboBox {
                            id: iSchemeCombobox
                            pSize: UiTheme.comboBoxes.sizes.small
                            Layout.preferredHeight: 24
                            Layout.fillWidth: true
                            onActivated: {
                                if (pGameControlsPopupLoaded) {
                                    kmmBackend.setActiveScheme(model[currentIndex])
                                    pGameControlsSensitivityEnabled = kmmBackend.hasPanControl()
                                    pGamepadControlsPresent = kmmBackend.hasGamepadControls
                                    if(pGameControlsSensitivityEnabled)
                                        updateSenstivity()
                                }
                            }
                        }
                    }
                    ColumnLayout {
                        Layout.fillWidth: true
                        Layout.preferredHeight: childrenRect.height
                        spacing: 4
                        enabled: iOverlayRow.enabled
                        visible: pGameControlsSensitivityEnabled
                        opacity: enabled ? 1 : 0.5
                        Text {
                            text: qsTranslate("QObject", "Mouse sensitivity")
                            font: UiTheme.fonts.bodySmall
                            color: UiTheme.colors.primary20
                        }
                        RowLayout {
                            spacing: 16
                            Layout.preferredWidth: childrenRect.width
                            Layout.preferredHeight: childrenRect.height
                            RowLayout {
                                Layout.preferredWidth: childrenRect.width
                                Layout.preferredHeight: childrenRect.height
                                spacing: 8
                                Text {
                                    text: "X"
                                    font: UiTheme.fonts.bodySmall
                                    color: UiTheme.colors.primary20
                                    horizontalAlignment: Text.AlignLeft
                                }
                                UiSpinBox {
                                    id: iMouseSensitivityXSpinBox
                                    Layout.preferredWidth: 58
                                    Layout.preferredHeight: 24
                                    realFrom: 0.01
                                    realTo: 10
                                    realStepSize: 0.01
                                    decimalPlaces: 2
                                    inputMethodHints: Qt.ImhFormattedNumbersOnly
                                    validator: RegExpValidator { regExp: /^(?=.*[0-9])\d{1}(?:\.\d{0,2})?$|^10$/}
                                }
                            }
                            RowLayout {
                                Layout.preferredWidth: childrenRect.width
                                Layout.preferredHeight: childrenRect.height
                                spacing: 8
                                Text {
                                    text: "Y"
                                    font: UiTheme.fonts.bodySmall
                                    color: UiTheme.colors.primary20
                                    horizontalAlignment: Text.AlignLeft
                                }
                                UiSpinBox {
                                    id: iMouseSensitivityYSpinBox
                                    Layout.preferredWidth: 58
                                    Layout.preferredHeight: 24
                                    realFrom: 0.01
                                    realTo: 10
                                    realStepSize: 0.01
                                    decimalPlaces: 2
                                    inputMethodHints: Qt.ImhFormattedNumbersOnly
                                    validator: RegExpValidator { regExp: /^(?=.*[0-9])\d{1}(?:\.\d{0,2})?$|^10$/}
                                }
                            }
                        }
                    }
                    Rectangle {
                        Layout.fillWidth: true
                        Layout.preferredHeight: 1
                        color: UiTheme.colors.primary60
                    }
                    Text {
                        id: iOpenEditorTxt
                        text: qsTranslate("QObject", "Controls editor")
                        font: UiTheme.fonts.bodySmall
                        color: UiTheme.colors.primary20
                        horizontalAlignment: Text.AlignLeft
                        enabled: iGameControlsToggleBtn.checked
                        opacity: enabled ? 1 : 0.5
                        MouseArea {
                            anchors.fill: parent
                            hoverEnabled: true
                            onEntered: {
                                cursorShape = Qt.PointingHandCursor
                                iOpenEditorTxt.color = UiTheme.colors.primary10
                            }
                            onExited: {
                                cursorShape = Qt.ArrowCursor
                                iOpenEditorTxt.color = UiTheme.colors.primary20
                            }
                            onClicked: {
                                cursorShape = Qt.ArrowCursor
                                iGameControlsPopup.destroy()
                                fOpenControlsEditorWindow(false)
                            }
                        }
                    }
                }
            }

            onClosePopup: {
                if (pGameControlsPopupLoaded && pGameControlsSensitivityEnabled) {
                    kmmBackend.setMouseSensitivity(
                                iMouseSensitivityXSpinBox.value / iMouseSensitivityXSpinBox.factor,
                                iMouseSensitivityYSpinBox.value / iMouseSensitivityYSpinBox.factor)
                }

                if (pGameControlsPopupLoaded)
                    kmmBackend.kmmPopupCommit()

                pGameControlsPopupLoaded = false
                pGameControlsEnabled = iGameControlsToggleBtn.checked
                uiBackend.confSetInstanceBool("game_controls_enabled", pGameControlsEnabled)
                uiBackend.confCommit()
            }
        }
    }

    Component {
        id: iKebabMenuPopupComponent
        UiWindowedPopup {
            id: iKebabMenuPopup
            property int pKebabMenuElementsCount: 0
            contentWidth: pSidebarElementSize * Math.ceil(pKebabMenuElementsCount / 4)
            contentHeight: Math.min(pSidebarElementSize * 4, pSidebarElementSize * pKebabMenuElementsCount)
            Rectangle {
                anchors.fill: parent
                color: UiTheme.colors.primary80
                border.width: 1
                border.color: UiTheme.colors.primary60
                Flow {
                    spacing: 0
                    anchors.fill: parent
                    flow: Flow.TopToBottom
                    Repeater {
                        model: pSidebarItems
                        delegate: UiImageButton {
                            Component.onCompleted: if(visible) pKebabMenuElementsCount++
                            asset: model.modelData.pAsset
                            pImageHeight: pSidebarElementSize
                            pImageWidth: pSidebarElementSize
                            enabled: model.modelData.pIsEnable
                            pUseShortcutTooltip: true
                            UiShortcutToolTip.text: model.modelData.pTooltipText
                            UiShortcutToolTip.shortcutMap: modelData.pConfShortcutProperty
                            pImageAnimationRunning: model.modelData.pRunImageAnimation
                            visible: (index > pVisibleSidebarElementsCount-1) && model.modelData.pIsFeatureEnable && model.modelData.pShowOnKebabMenu
                            MouseArea {
                                anchors.fill: parent
                                acceptedButtons: model.modelData.pAcceptedMouseButtons
                                onPressed: {
                                    UiShortcutToolTip.visible = false
                                    model.modelData.clicked(mouse.button, mouse.modifiers)
                                }
                                onReleased: {
                                    if(pKebabMenuWin != null)
                                        pKebabMenuWin.close()
                                    model.modelData.mouseReleased(mouse.button, mouse.modifiers)
                                }
                            }
                        }
                    }
                }
            }
        }
    }

    Component {
        id: iFullScreenBlurbPrompt
        PlrFullScreenBlurbWindow {
        }
    }

    UiColumnLayout {
        anchors.fill: parent
        Repeater {
            model: pSidebarItems
            delegate: Component {
                Rectangle {
                    id: iRootRect
                    height: pSidebarElementSize
                    width: pSidebarElementSize
                    color: "transparent"
                    visible: (index <= pVisibleSidebarElementsCount-1) && model.modelData.pIsFeatureEnable && model.modelData.pShowViaRepeaterOnly

                    onXChanged: {
                        model.modelData.positionChanged()
                    }

                    onYChanged: {
                        model.modelData.positionChanged()
                    }

                    Connections {
                        target: iAppwin
                        function onXChanged() {
                            model.modelData.positionChanged()
                        }
                        function onYChanged() {
                            model.modelData.positionChanged()
                        }
                    }

                    UiImageButton {
                        id: iBtn
                        asset: model.modelData.pAsset
                        pImageHeight: pSidebarElementSize
                        pImageWidth: pSidebarElementSize
                        enabled: model.modelData.pIsEnable
                        pUseShortcutTooltip: true
                        UiShortcutToolTip.text: model.modelData.pTooltipText
                        UiShortcutToolTip.shortcutMap: modelData.pConfShortcutProperty
                        pImageAnimationRunning: model.modelData.pRunImageAnimation
                        MouseArea {
                            anchors.fill: parent
                            acceptedButtons: model.modelData.pAcceptedMouseButtons
                            onPressed: {
                                UiShortcutToolTip.visible = false
                                model.modelData.clicked(mouse.button, mouse.modifiers)
                            }
                            onReleased: {
                                model.modelData.mouseReleased(mouse.button, mouse.modifiers)
                            }
                        }
                    }

                    UiImage {
                        id: iLoader
                        asset: model.modelData.pLoaderAsset
                        pImageWidth: 8
                        pImageHeight: 8
                        anchors.right: iRootRect.right
                        anchors.bottom: iRootRect.bottom
                        anchors.rightMargin: 9
                        anchors.bottomMargin: 9
                        visible: model.modelData.pLoaderAsset !== "" && model.modelData.pLoaderRunning

                        RotationAnimation on rotation {
                            loops: Animation.Infinite
                            duration: 1000
                            from: 0
                            to: 360
                            direction: RotationAnimation.Clockwise
                            running: model.modelData.pLoaderRunning
                        }
                    }
                }
            }
        }
        UiImageButton {
            id: iKebabMenuBtn
            Layout.alignment: Qt.AlignHCenter
            pImageHeight: pSidebarElementSize
            pImageWidth: pSidebarElementSize

            asset: pKebabMenuWin == null? "SidebarKebabClosed" : "SidebarKebabOpen"
            onPressed: {
                if (pKebabMenuWin != null)
                {
                    if (pKebabMenuWin.visible)
                        pKebabMenuWin.close()
                    return
                }
                pKebabMenuWin = iKebabMenuPopupComponent.createObject(iAppwin)
                pKebabMenuWin.x = iSidebar.mapToGlobal(0, 0).x - pKebabMenuWin.width + pKebabMenuWin.shadowThickness
                pKebabMenuWin.y = iKebabMenuBtn.mapToGlobal(0, 0).y - pKebabMenuWin.shadowThickness
                pKebabMenuWin.show()
            }
        }
        Item {
            Layout.fillHeight: true
        }
        Item {
            id: iSettingsBtn
            Layout.preferredWidth: pSidebarElementSize
            Layout.preferredHeight: pSidebarElementSize
            Layout.alignment: Qt.AlignHCenter | Qt.AlignBottom
            UiImageButton {
                pImageHeight: pSidebarElementSize
                pImageWidth: pSidebarElementSize
                asset: "SidebarSettings"
                pUseShortcutTooltip: true
                UiShortcutToolTip.text: qsTranslate("QObject", "Settings")
                UiShortcutToolTip.shortcutMap: [{ value: "open_settings" }]
                onClicked: sidebarSettingClicked()
            }
            Loader {
                visible: sourceComponent != undefined
                sourceComponent: plrBackend.pDiskOptimizationOnboarding ? iRedDotComponent : undefined
                anchors.top: iSettingsBtn.top
                anchors.right: iSettingsBtn.right
                anchors.topMargin: 2
                anchors.rightMargin: 4
            }
        }
        UiImageButton {
            id: iBackBtn
            pImageHeight: pSidebarElementSize
            pImageWidth: pSidebarElementSize
            Layout.alignment: Qt.AlignHCenter | Qt.AlignBottom
            enabled: iAppwin.pIsBootComplete

            asset: "SidebarBack"
            pUseShortcutTooltip: true
            UiShortcutToolTip.text: qsTranslate("QObject", "Back")
            UiShortcutToolTip.shortcutMap: [{ value: "go_back" }]
            onClicked: plrBackend.onBackClicked()
        }
        UiImageButton {
            id: iHomeBtn
            pImageHeight: pSidebarElementSize
            pImageWidth: pSidebarElementSize
            Layout.alignment: Qt.AlignHCenter | Qt.AlignBottom
            enabled: iAppwin.pIsBootComplete

            asset: "SidebarHome"
            pUseShortcutTooltip: true
            UiShortcutToolTip.text: qsTranslate("QObject", "Home")
            UiShortcutToolTip.shortcutMap: [{ value: "go_home" }]
            onClicked: plrBackend.onHomeClicked()
        }
        UiImageButton {
            id: iRecentBtn
            pImageHeight: pSidebarElementSize
            pImageWidth: pSidebarElementSize
            Layout.alignment: Qt.AlignHCenter | Qt.AlignBottom
            enabled: iAppwin.pIsBootComplete

            asset: "SidebarRecents"
            pUseShortcutTooltip: true
            UiShortcutToolTip.text: qsTranslate("QObject", "Recent apps")
            UiShortcutToolTip.shortcutMap: [{ value: "open_recent_apps" }]
            onClicked: plrBackend.onRecentAppsClicked()
        }
    }

    function fGetFullScreenBtbEnabled() {
        return iSidebarProperties.pIsFullScreenEnabled
    }

    function fGetVolumeBtnEnabled() {
        return iSidebarProperties.pIsVolumeEnabled
    }

    function fGetGameControlBtnEnabled() {
        return iSidebarProperties.pIsGameControlEnabled
    }

    function fGetInstallApkBtnEnabled() {
        return iSidebarProperties.pIsInstallApkEnabled
    }

    function fUpdateMouseCursorImage(mouseStateLocked) {
        pMouseCursorLocked = mouseStateLocked
    }

    function fHandleInstallApkBtnClicked() {
        iFileDialogComponent.createObject().open()
    }

    function fOpenVolumePopup(startTimer) {
        if (startTimer)
            fStartVolumePopupTimer()

        if (pVolumeWin != null)
        {
            if (pVolumeWin.visible)
                pVolumeWin.closePopup()
            return
        }
        pVolumeWin = iVolumePopupComponent.createObject(iAppwin)
        pVolumeWin.x = iSidebar.mapToGlobal(0, 0).x - pVolumeWin.width + pVolumeWin.shadowThickness
        pVolumeWin.y = fGetPopupTopPoint(pVolume) - pVolumeWin.shadowThickness
        pVolumeWin.show()
    }

    function fOpenGameControl(mouse) {
        if(mouse.button === Qt.RightButton)
            fOpenControlsEditorWindow(false)
        else
            fOpenGameControlsPopup()
    }
    function fOpenGameControlsPopup() {
        kmmBackend.kmmPopupStart()
        if (pGameControlsWin != null)
        {
            if (pGameControlsWin.visible)
                pGameControlsWin.close()
            return
        }
        pGameControlsWin = iGameControlsPopupComponent.createObject(iAppwin)

        //This is a variant list with index of the selected scheme
        //stored at 0th location and scheme list at 1st.
        var schemeInfo = kmmBackend.popupSchemes
        pGameControlsWin.schemeModel = schemeInfo[1]
        pGameControlsWin.schemeIdx = schemeInfo[0]
        pGameControlsSensitivityEnabled = kmmBackend.hasPanControl()
        pGamepadControlsPresent = kmmBackend.hasGamepadControls
        pGameControlsGamepadSelected = kmmBackend.gamepadControlsSelected
        if(pGameControlsSensitivityEnabled)
            pGameControlsWin.updateSenstivity()

        pGameControlsWin.x = iSidebar.mapToGlobal(0, 0).x - pGameControlsWin.width + pGameControlsWin.shadowThickness
        pGameControlsWin.y = fGetPopupTopPoint(pGameControl) - pGameControlsWin.shadowThickness
        pGameControlsPopupLoaded = true
        pGameControlsWin.show()
    }

    function fOpenControlsEditorWindow(isDevModeEnabled = false) {
        if (pKmmEditorWindow != null) return
        kmmBackend.devModeEnabled = isDevModeEnabled

        var component = Qt.createComponent("KmmEditorWindow.qml")
        if (component.status === Component.Ready) {
            pKmmEditorWindow = component.createObject(iAppwin)
            if (pKmmEditorWindow != null) {
                adsBackend.editorWindowVisible = true
                kmmBackend.kmmEditorStart()
                var schemeInfo = kmmBackend.editorSchemes
                pKmmEditorWindow.schemeModel = schemeInfo[1]
                pKmmEditorWindow.schemeIdx = schemeInfo[0]
                pKmmEditorWindow.pBuiltinIndex = schemeInfo[2]
                pKmmEditorWindow.width = iAppwin.width - iAppwin.pSidebarWidth + pKmmEditorWindow.pKmmEditorPanelWidth
                pKmmEditorWindow.height = iAppwin.height
                pKmmEditorWindow.x = iAppwin.x
                pKmmEditorWindow.y = iAppwin.y
                pKmmEditorWindow.show()
                if(kmmBackend.gamepadTabSelected && !uiBackend.confGetBool("bst.gamepad_editing_onboarding_done", false)) {
                    pKmmEditorWindow.fOpenGamepadInfoPopup()
                    uiBackend.confSetBool("bst.gamepad_editing_onboarding_done", true)
                    uiBackend.confCommit()
                }
            }
        }
    }

    function fToggleGameControlsState(isEnabled) {
        pGameControlsEnabled = isEnabled
        kmmBackend.toggleOverlayVisibility(isEnabled ? pIsGameControlsOverlayEnabled : isEnabled, false)
        uiBackend.confSetInstanceBool("game_controls_enabled", pGameControlsEnabled)
        uiBackend.confCommit()
    }

    function fToggleGameControlsVisibility(isVisible) {
        pIsGameControlsOverlayEnabled = isVisible
    }

    function fToggleGamepadControlsState(isSelected) {
        pGameControlsGamepadSelected = isSelected
        kmmBackend.gamepadControlsSelected = isSelected
    }

    function fGetPopupTopPoint(elementId) {
        var applicableIndex = -1
        for (var i = 0; i < pSidebarItems.length; i++) {
            applicableIndex  += 1
            if(pSidebarItems[i].pElementId === elementId && applicableIndex <= pVisibleSidebarElementsCount-1) {
                return iSidebar.mapToGlobal(0, 0).y + (applicableIndex * pSidebarElementSize)
            }
        }
        return iKebabMenuBtn.mapToGlobal(0, 0).y
    }

    function fVolumeChangedCb(isMute, vol) {
        if (isMute !== pIsMuted)
            pIsMuted = isMute

        if (vol !== pCurrentVolumeLevel)
            pCurrentVolumeLevel = vol
    }

    function fInitVolume(isMute, vol, maxVol) {
        pIsMuted = isMute
        pCurrentVolumeLevel = vol
        pMaxVolumeLevel = maxVol
    }

    function fRequestMuteUnmute() {
        pIsMuted = !pIsMuted
        plrBackend.requestSetVolume(pIsMuted, pCurrentVolumeLevel, pMaxVolumeLevel)
    }

    function fVolumeSliderChanged(vol) {
        plrBackend.requestSetVolume(false, vol, pMaxVolumeLevel)
    }

    function fCloseAllPopupsOnOrientationChange() {
        fCloseVolumePopup();
        if (pGameControlsWin != null && pGameControlsWin.visible)
            pGameControlsWin.close()
        if (pKebabMenuWin != null && pKebabMenuWin.visible)
            pKebabMenuWin.close()
        if(pFullScreenBlurbWin != null && pFullScreenBlurbWin.visible) {
            pFullScreenBlurbWin.x = iSidebar.mapToGlobal(0, 0).x - pFullScreenBlurbWin.width + pFullScreenBlurbWin.shadowThickness
            pFullScreenBlurbWin.y = fGetPopupTopPoint(pFullscreen) - pFullScreenBlurbWin.shadowThickness
        }
    }

    function fShowFullScreenBlurbPrompt() {
        var applicableIndex = -1
        var isIconFound = false
        var point = 0
        for (var i = 0; i < pSidebarItems.length; i++) {
            applicableIndex  += 1
            if(pSidebarItems[i].pElementId === pFullscreen && applicableIndex <= pVisibleSidebarElementsCount-1) {
                isIconFound = true
                point = iSidebar.mapToGlobal(0, 0).y + (applicableIndex * pSidebarElementSize)
            }
        }
        if(!isIconFound)
            return

        if (iAppwin.visibility != ApplicationWindow.Minimized || pFullScreenBlurbWin != null) {
            pFullScreenBlurbWin = iFullScreenBlurbPrompt.createObject(iAppwin)
            pFullScreenBlurbWin.x = iSidebar.mapToGlobal(0, 0).x - pFullScreenBlurbWin.width + pFullScreenBlurbWin.shadowThickness
            pFullScreenBlurbWin.y = point - pFullScreenBlurbWin.shadowThickness
            pFullScreenBlurbWin.show()
        }
    }

    function fCloseFullScreenBlurb() {
        if (pFullScreenBlurbWin != null && pFullScreenBlurbWin.visible)
            pFullScreenBlurbWin.close()
    }

    function fShowToast(strMsg) {
        var message = qsTranslate("QObject", strMsg)
        var toast = iToastComponent.createObject(iAppwin, { "pToastMessage": message,
                                                     "color": UiTheme.colors.overlayPrimary,
                                                     "pBackground.border.color" : UiTheme.colors.primary50,
                                                     "pBackground.color" : UiTheme.colors.overlayPrimary,
                                                     "pBackground.radius" : 0,
                                                     "pBackground.opacity" : 0.85,
                                                     "pBackground.leftPadding": 40,
                                                     "pBackground.rightPadding": 40,
                                                     "pBackground.topPadding": 12,
                                                     "pBackground.bottomPadding": 12,
                                                     "pToastTimer.interval": 3000})
        toast.fShowMessage()
    }
}