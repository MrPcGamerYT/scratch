/*
 * Copyright (C) 2020-2021 BlueStack Systems, Inc.
 * All Rights Reserved
*
 * THIS IS UNPUBLISHED PROPRIETARY SOURCE CODE OF BLUESTACK SYSTEMS, INC.
 * The copyright notice above does not evidence any actual or intended
 * publication of such source code.
 */

import QtQuick 2.15
import QtQuick.Controls 2.15
import QtQuick.Layouts 1.15
import QtQuick.Window 2.15
import QtQuick.Shapes 1.12
import UiToolTipControl 1.0

UiWindowedPopup {
    id: iFullScreenBlurbWindow
    modality: Qt.ApplicationModal
    contentWidth: iFullScreenBlurbLayout.implicitWidth
    contentHeight: iFullScreenBlurbLayout.implicitHeight
    closeOnPressOutside: false

    property string pMessage : qsTranslate("QObject", "Click here or press {%1} to toggle fullscreen.").arg("F11")
    property var pTips: pMessage.split("{")
    property var pInfo: pTips.length > 1 ? pTips[1].split("}") : ["", ""]

    UiColumnLayout {
        id: iFullScreenBlurbLayout
        anchors.left: parent.left
        anchors.right: parent.right
        color: UiTheme.colors.accentNormal
        UiColumnLayout {
            id: iInnerLayout
            leftPadding: 12
            rightPadding: 12
            bottomPadding: 10
            topPadding: 10
            spacing: 8
            Text {
                font: UiTheme.fonts.titleSmall
                color: UiTheme.colors.primary10
                text: qsTranslate("QObject", "Enter fullscreen")
                wrapMode: Text.Wrap
                Layout.fillWidth: true
                horizontalAlignment: Text.AlignLeft
            }

            UiColumnLayout {
                spacing: 8
                UiRowLayout {
                    spacing: 8
                    Text {
                        text: pTips[0]
                        font: UiTheme.fonts.bodyMedium
                        color: UiTheme.colors.primary10
                        Layout.alignment: Qt.AlignLeft
                        Layout.fillWidth: true
                    }

                    UiColumnLayout {
                        id: iKeyRect
                        border.color: UiTheme.colors.primary10
                        color: "transparent"
                        leftPadding: 4
                        rightPadding: 4
                        topPadding: 6
                        bottomPadding: 6
                        Text {
                            text: pInfo[0]
                            color: UiTheme.colors.primary10
                            font: UiTheme.fonts.bodyMedium
                        }
                    }
                }
                Text {
                    id: iText2
                    wrapMode: Text.WordWrap
                    text: pInfo[1]
                    font: UiTheme.fonts.bodyMedium
                    color: UiTheme.colors.primary10
                    Layout.fillWidth: true
                    Layout.alignment: Qt.AlignLeft
                }
            }

            UiButton{
                pSize: UiTheme.buttons.sizes.small
                pColor: UiTheme.buttons.colors.accentWhiteBorder
                text: qsTranslate("QObject", "Okay")
                Layout.alignment: Qt.AlignLeft
                Layout.topMargin: 12
                MouseArea {
                    anchors.fill: parent
                    hoverEnabled: true
                    onEntered:  {
                        cursorShape = Qt.PointingHandCursor
                    }
                    onExited:  {
                        cursorShape = Qt.ArrowCursor
                    }
                    onClicked: {
                        iFullScreenBlurbWindow.close()
                    }
                }
            }
        }
    }
    Shape {
        anchors.horizontalCenter: iFullScreenBlurbLayout.horizontalCenter
        anchors.top: parent.top
        anchors.topMargin: 16
        anchors.horizontalCenterOffset: iFullScreenBlurbLayout.implicitWidth / 2
        width: 12
        height: 6
        ShapePath {
            strokeColor: UiTheme.colors.accentNormal
            fillColor: UiTheme.colors.accentNormal
            startX: 0
            startY: 6
            PathLine { x: 12; y: 0 }
            PathLine { x: 0; y: -6 }
        }
    }
}
