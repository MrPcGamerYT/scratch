/*
 * Copyright (C) 2020-2024 BlueStack Systems, Inc.
 * All Rights Reserved
 *
 * THIS IS UNPUBLISHED PROPRIETARY SOURCE CODE OF BLUESTACK SYSTEMS, INC.
 * The copyright notice above does not evidence any actual or intended
 * publication of such source code.
 */

import QtQuick 2.15
import QtQuick.Window 2.15
import QtQuick.Layouts 1.15
import QtWebEngine 1.10
import QtWebChannel 1.0

import UiToolTipControl 1.0

Window {
    id: iPlayerWebBrowser
    color: UiTheme.colors.primary60
    flags: Qt.Tool | Qt.FramelessWindowHint
    title: uiBackend.productName + " Browser"
    screen: transientParent.screen

    property string pUrl: "about:blank"

    UiColumnLayout {
        spacing: 8
        anchors.fill: parent
        anchors.margins: 4

        UiRowLayout {
            Layout.fillWidth: true
            Layout.preferredHeight: 32
            color: UiTheme.colors.primary70
            spacing: 8

            UiRowLayout {
                spacing: 8
                Layout.fillWidth: true
                Layout.fillHeight: true
                Layout.alignment: Qt.AlignLeft

                UiImageButton {
                    asset: "Backward"
                    pImageWidth: 16
                    pImageHeight: 16
                    onClicked: iWebEngineView.goBack()
                    enabled: iWebEngineView && iWebEngineView.canGoBack
                    activeFocusOnTab: true
                }
                UiImageButton {
                    asset: "Forward"
                    pImageWidth: 16
                    pImageHeight: 16
                    onClicked: iWebEngineView.goForward()
                    enabled: iWebEngineView && iWebEngineView.canGoForward
                    activeFocusOnTab: true
                }
                UiImageButton {
                    asset: iWebEngineView && iWebEngineView.pIsLoading ? "CloseIcon" : "Reload"
                    pImageWidth: 16
                    pImageHeight: 16
                    onClicked: iWebEngineView && iWebEngineView.pIsLoading ? iWebEngineView.stop() : iWebEngineView.reload()
                    activeFocusOnTab: true
                }
                UiTextField {
                    Layout.fillWidth: true
                    pSize: UiTheme.textFields.sizes.small
                    text: iWebEngineView && iWebEngineView.url
                    onAccepted: iWebEngineView.url = uiBackend.fromUserInputInBrowser(text)
                }
            }

            UiImageButton {
                asset: "TitlebarClose"
                pImageWidth: 32
                pImageHeight: 32
                Layout.alignment: Qt.AlignRight
                UiToolTip.text: qsTranslate("QObject", "Close")
                onClicked: {
                    iPlayerWebBrowser.hide()
                    iWebEngineView.stop()
                }
            }
        }

        WebEngineView {
            id: iWebEngineView
            focus: true
            Layout.fillWidth: true
            Layout.fillHeight: true
            url: iPlayerWebBrowser.pUrl

            settings.javascriptEnabled: true
            settings.javascriptCanOpenWindows: true

            property bool pIsLoading: false

            onLoadProgressChanged: {
                if (iWebEngineView.loadProgress > 0 && iWebEngineView.loadProgress <= 99)
                    iWebEngineView.pIsLoading = true
                else
                    iWebEngineView.pIsLoading = false
            }

            onNewViewRequested: function(request) {
                console.info("WebView Overlay :: onNewViewRequested clicked url = " + request.requestedUrl)
                request.openIn(iWebEngineView)
            }

            onNavigationRequested: function(request) {
                if (request.navigationType === WebEngineNavigationRequest.LinkClickedNavigation) {
                    console.info("WebView Overlay :: onNavigationRequested clicked url = " + request.url.toString())
                    request.openIn(iWebEngineView)
                    request.action = WebEngineNavigationRequest.IgnoreRequest
                }
            }
        }
    }

    function fLoadUrl(url) {
        iPlayerWebBrowser.pUrl = url
        iWebEngineView.reload()
    }
}
