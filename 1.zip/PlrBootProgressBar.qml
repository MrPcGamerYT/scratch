/*
 * Copyright (C) 2020-2021 BlueStack Systems, Inc.
 * All Rights Reserved
 *
 * THIS IS UNPUBLISHED PROPRIETARY SOURCE CODE OF BLUESTACK SYSTEMS, INC.
 * The copyright notice above does not evidence any actual or intended
 * publication of such source code.
 */

import QtQuick 2.15
import QtQuick.Controls 2.15
import QtQuick.Layouts 1.15
import QtQuick.Window 2.15

Rectangle {    
    property bool pBootImageButtonVisible: false
    property bool pBootAppDataVisible: iBootAppTitle.width + 32 < iAppwin.width && iBootAppDetails.width + 32 < iAppwin.width
    property bool pBootAppInfoVisible: false
    property bool pBootRectVisible: false
    property int pCounter:0
    property int pBootDuration : plrBackend.getBootDuration()
    property var pProgressBarWidth : width - 40
    property var pBootStartTime : new Date().getTime()
    property variant pBootTipsList: [
        qsTranslate("QObject", "Zoom In/Out in-game, press CTRL+Mousewheel Up/Down."),
        qsTranslate("QObject", "Get Help and Support, click on the help icon on the top bar."),
        qsTranslate("QObject", "View your in-game FPS, enable FPS counter from Performance tab in Settings."),
        qsTranslate("QObject", "Connect your gamepad for an enhanced gaming experience."),
        qsTranslate("QObject", "Play fullscreen, press F11 and experience greater immersion."),
        qsTranslate("QObject", "Move in and out of shooting mode, press F1.")
    ]

    id:iPromotionControl
    color: uiBackend.oem === "msi5" ? UiTheme.colors.primary80 :"#000000"
    visible: true

    Image {
        id: iBootImage
        source: "qrcAssets/bootBackgroundImage" + (plrBackend.getOrientation() === 0 ?  "" : "Potrait") + ".jpg"
        height: Math.min(parent.height, plrBackend.getOrientation() === 0 ? parent.width * (9/16) : parent.width * (16/9))
        width: Math.min(parent.width, plrBackend.getOrientation() === 0 ? parent.height * (16/9) : parent.height * (9/16))
        anchors.verticalCenter: parent.verticalCenter
        anchors.horizontalCenter: parent.horizontalCenter
        visible: uiBackend.oem === "msi5" ? false : true
        onStatusChanged: {
            if (status == Image.Error){
                pBootImageButtonVisible = false
                if(uiBackend.oem === "msi5")
                {
                    iBootImage.visible = false
                    return
                }
                iBootImage.source = "qrcAssets/bootBackgroundImage" + (plrBackend.getOrientation() === 0 ?  "" : "Potrait") + ".jpg"
            }
        }
        MouseArea {
            anchors.fill: parent
            enabled: pBootImageButtonVisible && !iBootImageBtn.visible
            onClicked: fPromotionClick()
        }
    }
    Text {
        id: iBootLoadingText
        text: qsTranslate("QObject", "Loading...")
        font: UiTheme.fonts.bodyExtraLarge
        color: UiTheme.colors.primary20
        anchors.verticalCenterOffset: -50
        anchors.verticalCenter: parent.verticalCenter
        anchors.horizontalCenter: parent.horizontalCenter
    }

    Image {
        id: iBootAppImage
        visible: pBootAppInfoVisible && pBootAppDataVisible && iAppwin.height > 360
        height: 100
        width: 100
        anchors.verticalCenterOffset: -110
        anchors.verticalCenter: parent.verticalCenter
        anchors.horizontalCenter: parent.horizontalCenter
    }
    Text {
        id: iBootAppTitle
        visible: pBootAppInfoVisible && pBootAppDataVisible && iAppwin.height > 360
        font: Qt.font({
                          "family": "Rubik",
                          "pixelSize": plrBackend.getOrientation() === 0 ? 36 : 24,
                          "styleName": "Medium"
                      })

        color: UiTheme.colors.primary10
        anchors.verticalCenterOffset: -10
        anchors.verticalCenter: parent.verticalCenter
        anchors.horizontalCenter: parent.horizontalCenter
    }
    Text {
       id: iBootAppDetails
       visible: pBootAppInfoVisible && pBootAppDataVisible && iAppwin.height > 360
       font:Qt.font({
                        "family": "Rubik",
                        "pixelSize": plrBackend.getOrientation() === 0 ? 16 : 14,
                        "capitalization": Font.AllUppercase,
                        "letterSpacing": 0.1
                    })
        color: UiTheme.colors.primary10
        anchors.verticalCenterOffset: 40
        anchors.verticalCenter: parent.verticalCenter
        anchors.horizontalCenter: parent.horizontalCenter
    }
    Rectangle {
        id: iPromotionInfoRect
        anchors.bottom: iBootProgressContainer.top
        anchors.right: iBootImage.right
        anchors.bottomMargin: 45
        anchors.rightMargin: 48
        height: iPromotionInfoText.height
        color: UiTheme.colors.primary80
        width: iPromotionInfoText.width
        visible: pBootRectVisible && iAppwin.height > 225
        Text {
            id: iPromotionInfoText
            text: qsTranslate("QObject", "Action will resume after boot up")
            color: UiTheme.colors.primary10
            anchors.centerIn: parent
            font : UiTheme.fonts.buttonLarge
            leftPadding: 20
            rightPadding: 20
            topPadding: 12
            bottomPadding: 12
        }
    }

    UiButton{
        id: iBootImageBtn
        anchors.bottom: iBootProgressContainer.top
        anchors.right: iBootImage.right
        anchors.bottomMargin: 45
        anchors.rightMargin: 48
        pSize: UiTheme.buttons.sizes.extraLarge
        pColor: UiTheme.buttons.colors.accent
        text: qsTranslate("QObject", "Click")
        visible: pBootImageButtonVisible && iAppwin.height > 225
        onClicked: fPromotionClick()
    }


    Item {
        id: iBootProgressContainer
        anchors.bottom: iPromotionControl.bottom
        height: uiBackend.oem === "msi5" ? 110 : 100
        width: iPromotionControl.width

        UiDropShadowEffect {
            visible: uiBackend.oem === "msi5" ? true : false
            anchors.fill: iBootProgressRect
            glowRadius: 5
            cornerRadius: 5
            color: UiTheme.colors.primary80
        }

        UiColumnLayout {
            id: iBootProgressRect
            color: UiTheme.colors.overlayPrimary
            anchors.fill: parent
            spacing: 12
            anchors.topMargin: uiBackend.oem === "msi5" ? 10 : 0
            Text {
                text: qsTranslate("QObject", "Starting %1, please wait.").arg(uiBackend.productName)
                font: UiTheme.fonts.titleSmall
                color: UiTheme.colors.primary10
                Layout.topMargin: 15
                Layout.leftMargin: 20
                Layout.alignment: Qt.AlignBottom
                horizontalAlignment: Text.AlignLeft
            }

            UiProgressBar {
                id:iProgressBar
                from:0
                to:99
                height: 8
                Layout.preferredWidth: pProgressBarWidth
                visible: true
                Layout.alignment: Qt.AlignBottom
                Layout.leftMargin: 20
                Layout.rightMargin: 20
                value: 1
            }

            Timer {
                id: iTimer
                interval: 40
                repeat: true
                running: true
                onTriggered: {
                    iProgressBar.value = 100 * (new Date().getTime() - pBootStartTime)/ (pBootDuration * 1.1)
                    if(iProgressBar.value >= 95) { iProgressBar.value += 0.025 }
                    if(iProgressBar.value >= 99) { iProgressBar.value = 99 }

                }
            }

            Text {
                id: iBootTips
                text: pBootTipsList[0]
                Layout.preferredWidth: pProgressBarWidth
                elide: Text.ElideRight
                font: UiTheme.fonts.bodyLarge
                color: uiBackend.oem === "msi5" ? UiTheme.colors.overLayTint : UiTheme.colors.primary10
                horizontalAlignment: Text.AlignLeft
                Layout.bottomMargin: 15
                Layout.leftMargin: 20
            }

            Timer {
                id: iBootTipstimer
                interval: 3000
                repeat: true
                running: true
                onTriggered: {
                    pCounter++
                    if(pCounter > pBootTipsList.length - 1) { pCounter = 0 }
                    iBootTips.text = pBootTipsList[pCounter]
                }
            }
        }
    }

    function fPromotionClick() {
        if(iPromotionInfoText.text){
            pBootRectVisible = true
            pBootImageButtonVisible = false
        }
        plrBackend.bootPromotionButtonClicked()
    }

    function fBootComplete() {
        iPromotionControl.visible = false
        iTimer.stop()
        iBootTipstimer.stop()
        uiBackend.confSetInstanceI32("boot_duration",(new Date().getTime() - pBootStartTime))
        uiBackend.confCommit()
    }

    function fSetBootPromotion(imagePath, buttonText, buttonClickMessage){
        if(imagePath || buttonText){
            iBootLoadingText.visible = false
            pBootAppInfoVisible = false
        }

        if(buttonText){
            iBootImageBtn.text = qsTranslate("QObject", buttonText)
            pBootImageButtonVisible = true
        }
        else{
            pBootImageButtonVisible = false
        }

        if(imagePath){
            iBootImage.visible = true
            iBootImage.source =  "file:///" + imagePath;
        }
        else{
            iBootImage.source = "qrcAssets/bootBackgroundImage" + (plrBackend.getOrientation() === 0 ?  "" : "Potrait") + ".jpg"
            iBootLoadingText.visible = true
        }

        iPromotionInfoText.text = qsTranslate("QObject", buttonClickMessage)
    }

    function fSetDefaultAppSpecificBootBanner(fileName, title, appDetails)
    {
        if(iBootLoadingText.visible)
        {
            iBootLoadingText.visible = false
            iBootAppImage.source = "file:///" + fileName
            iBootAppTitle.text = title
            iBootAppDetails.text = appDetails
            pBootAppInfoVisible = true
        }
    }
}
