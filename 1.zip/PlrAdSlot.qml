/*
 * Copyright (C) 2020-2021 BlueStack Systems, Inc.
 * All Rights Reserved
 *
 * THIS IS UNPUBLISHED PROPRIETARY SOURCE CODE OF BLUESTACK SYSTEMS, INC.
 * The copyright notice above does not evidence any actual or intended
 * publication of such source code.
 */

import QtQuick 2.15
import QtQuick.Controls 2.15
import QtQuick.Layouts 1.15
import QtQuick.Window 2.15
import QtGraphicalEffects 1.15
import QtWebEngine 1.10
import QtWebChannel 1.0
import QtQuick.Shapes 1.12

import PlrGmApi 1.0
import UiToolTipControl 1.0

Rectangle {
    color: UiTheme.colors.primary60
    border.color: UiTheme.colors.primary100
    border.width: 4

    property alias pWebEngineView: iWebEngineView
    property string pAdSlotBrowserPreference: "default"

    signal adSlotClicked(var clickUrl)

    WebEngineView {
        id: iWebEngineView
        focus: true
        anchors.fill: parent
        anchors.centerIn: parent
        anchors.margins: 4

        settings.javascriptEnabled: true
        settings.showScrollBars: false

        onNewViewRequested: function(request) {
            console.info("WebView :: onNewViewRequested clicked url = " + request.requestedUrl)
            if (pAdSlotBrowserPreference === "bst") {
                if (iAppwin.pBrowserWindow == null) {
                    var comp = Qt.createComponent("UiBrowserWindow.qml")
                    if (comp.status === Component.Ready) {
                        iAppwin.pBrowserWindow = comp.createObject(null, {
                                                                       "x": 300,
                                                                       "y": 50,
                                                                       "width": 1000,
                                                                       "height": 800
                                                                   })
                        request.openIn(iAppwin.pBrowserWindow.pCurrentWebView)
                    }
                }
                else {
                    iAppwin.pBrowserWindow.createNewTab(request)
                }

                if (iAppwin.pBrowserWindow.visibility === Window.Maximized ||
                        (iAppwin.pBrowserWindow.visibility === Window.Minimized &&
                         iAppwin.pBrowserWindow.pWindowStateBeforeMinimized === Window.Maximized))
                    iAppwin.pBrowserWindow.showMaximized()
                else
                    iAppwin.pBrowserWindow.showNormal()

                iAppwin.pBrowserWindow.raise()
                iAppwin.pBrowserWindow.requestActivate()
            }
            adSlotClicked(request.requestedUrl)
        }

        onNavigationRequested: function(request) {
            if (request.navigationType === WebEngineNavigationRequest.LinkClickedNavigation) {
                console.info("WebView :: onNavigationRequested clicked url = " + request.url.toString())
                if (pAdSlotBrowserPreference === "bst") {
                    if (iAppwin.pBrowserWindow == null) {
                        var comp = Qt.createComponent("UiBrowserWindow.qml")
                        if (comp.status === Component.Ready) {
                            iAppwin.pBrowserWindow = comp.createObject(null, {
                                                                           "x": 300,
                                                                           "y": 50,
                                                                           "width": 1000,
                                                                           "height": 800
                                                                       })
                            request.openIn(iAppwin.pBrowserWindow.pCurrentWebView)
                        }
                    }
                    else {
                        iAppwin.pBrowserWindow.createNewTab(request)
                    }

                    if (iAppwin.pBrowserWindow.visibility == Window.Maximized)
                        iAppwin.pBrowserWindow.showMaximized()
                    else
                        iAppwin.pBrowserWindow.showNormal()

                    iAppwin.pBrowserWindow.raise()
                    iAppwin.pBrowserWindow.requestActivate()
                }
                adSlotClicked(request.url.toString())
                request.action = WebEngineNavigationRequest.IgnoreRequest
            }
        }

        onJavaScriptConsoleMessage: {
            console.debug("JS: message: " + message)
        }

        function runJavaScriptMethod(method) {
            iWebEngineView.runJavaScript(method)
        }
    }
}
