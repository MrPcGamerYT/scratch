/*
 * Copyright (C) 2020-2021 BlueStack Systems, Inc.
 * All Rights Reserved
 *
 * THIS IS UNPUBLISHED PROPRIETARY SOURCE CODE OF BLUESTACK SYSTEMS, INC.
 * The copyright notice above does not evidence any actual or intended
 * publication of such source code.
 */

import QtQuick 2.15
import QtQuick.Controls 1.4
import QtQuick.Layouts 1.15
import QtQuick.Controls.Styles 1.4

Calendar {
    frameVisible: false
    selectedDate: new Date()

    property date hoveredDate

    onHovered: {
        hoveredDate = date
    }

    style: CalendarStyle {
        background: Rectangle {
            color: UiTheme.colors.primary100
        }
        gridVisible: false

        navigationBar: UiRowLayout {
            color: UiTheme.colors.primary100
            topPadding: 10
            bottomPadding: 10
            leftPadding: 30
            rightPadding: 30
            spacing: 18
            Text {
                Layout.fillWidth: true
                text: styleData.title
                font : UiTheme.fonts.titleSmallest
                color: UiTheme.colors.primary10
            }
            UiImageButton {
                asset: "RightArrow"
                pImageWidth: 16
                pImageHeight: 16
                rotation: 90
                onClicked: control.showNextMonth()
            }
            UiImageButton {
                asset: "RightArrow"
                pImageWidth: 16
                pImageHeight: 16
                rotation: 270
                onClicked: control.showPreviousMonth()
            }
        }

        dayOfWeekDelegate: Text {
            text: control.locale.dayName(styleData.dayOfWeek, control.dayOfWeekFormat)
            topPadding: 6
            bottomPadding: 6
            horizontalAlignment: Text.AlignHCenter
            font : UiTheme.fonts.bodyMedium
            color: UiTheme.colors.primary10
        }

        dayDelegate: Rectangle {
            anchors.fill: parent
            border.color: Qt.formatDate(control.hoveredDate, "MM/dd/yyyy") === Qt.formatDate(styleData.date, "MM/dd/yyyy")
                          ? UiTheme.colors.accentNormal
                          : UiTheme.colors.primary80
            border.width: 1
            color: "transparent"

            Rectangle {
                anchors.fill: parent
                anchors.margins: 1
                opacity: styleData.visibleMonth ? 1 : 0.4
                color: styleData.date !== undefined && styleData.selected ? UiTheme.colors.accentNormal : UiTheme.colors.primary100
                Text {
                    anchors.centerIn: parent
                    text: styleData.date.getDate()
                    font : UiTheme.fonts.bodyMedium
                    color: styleData.date !== undefined && styleData.selected ? UiTheme.colors.primary10 : UiTheme.colors.primary20
                }
            }
        }
    }
}
