﻿import QtQuick 2.15
import QtQuick.Controls 2.15
import QtQuick.Layouts 1.15
import QtQuick.Window 2.15
import DialogButtonModel 1.0
import DialogButtonModelList 1.0
import UiDialogWindow 1.0
import SettingElementModel 1.0
import SettingElementModelList 1.0
import UiLaunchAppWindow 1.0
import UiOverlayControl 1.0
import BannerAdUiModel 1.0
import BannerAdUi 1.0
import UiQuickWindow 1.0

ApplicationWindow {
    id: iAppwin
    x: 10
    y: 10
    width: 960
    height: 540
    flags: Qt.Window | Qt.FramelessWindowHint | Qt.WindowMinMaxButtonsHint
    color: uiBackend.oem === "msi5" ? UiTheme.colors.overLayTint : UiTheme.colors.primary60

    property bool pCompLoaded: false
    property int pBorderWidth: 1
    property int pSidebarWidth: 32
    property bool pIsEcoModeEnabled: false
    property bool pSidebarVisibleBeforeFullscreen: true
    property bool pIsMacroRunning: false
    property bool pIsMacroPause: false
    property bool pIsRawMode: false
    property bool pIsBootComplete: false
    property string pArticleKey: ""
    property bool pIsTroubleSigningInBtnShown: false
    property bool pIsQuestNotificationOpen: false

    property UiSettingsWindow pSettingsWindow: null
    property UiLoadingScreen pLoadingScreenControl: null
    property PlrFullScreenPopup pFullScreenPopupControl: null
    property Window pMacroManagerWindow: null
    property Window pSyncOperationsWindow: null
    property UiLaunchAppWindow pFlePopupWindow: null
    property Window pNotificationBarWindow: null
    property Window pScreenTranslateWindow: null
    property Window pLaunchBsxWindow: null
    property UiQuickWindow pMediaGalleryWindow: null
    property UiMessageDialog pGamepadDetectedDialog: null
    property UiMessageDialog pGameControlsUpdatedDialog: null
    property UiMessageDialog pMultipleCamerasDetectedDialog: null
    property UiMessageDialog pChargerWarningPopupWindow: null
    property UiMessageDialog pSigninSuccessfulPopupWindow: null
    property UiMessageDialog pDisableMomentsPopupWindow: null
    property UiMessageDialog pDisableRecordingPopupWindow: null
    property UiMessageDialog pCheckBrowserPopupWindow: null
    property UiMessageDialog pLowDiskSpacePopupWindow: null
    property UiMessageDialog pSignOutPopupWindow: null
    property UiMessageDialog pSignOutConfirmationPopupWindow: null
    property UiWindowedPopup pTroubleSigningInBtn: null
    property Window pBrowserWindow: null
    property Window pBlueStacksStoreWindow: null
    property PlrExitFullScreenPopup pExitFullScreenControl: null
    property Window pSigninRequiredWindow: null
    property Window pLinkNowggAccountWindow: null

    // Enabling pinToTop on maximize breaks the restore functionality
    // Saving app geometry for restoring
    property int pX: 0
    property int pY: 0
    property int pWidth: 0
    property int pHeight: 0

    property bool pIsShowMaximizedCalled: false
    property int pPreviousWindowState: 2
    property int pWindowStateBeforeMinimized: -1

    onVisibilityChanged: {
        if (visibility == ApplicationWindow.Hidden)
            return

        plrBackend.setWindowMinimizedState(visibility == ApplicationWindow.Minimized)

        //setting variables required to set the correct windowState when restored from minimized windowState
        if (visibility == ApplicationWindow.Minimized)
            pWindowStateBeforeMinimized = pPreviousWindowState
        else
            pPreviousWindowState = visibility

        //handling for window automatically going to fullscreen on maximizing when window geometry is equal to screen geometry
        if (visibility == ApplicationWindow.FullScreen && pIsShowMaximizedCalled) {
            iAppwin.visibility = ApplicationWindow.Maximized
            pIsShowMaximizedCalled = false
        }

        //handling to set the correct windowState when restored from minimized state
        if (pWindowStateBeforeMinimized == ApplicationWindow.Maximized
                && (visibility == ApplicationWindow.Windowed || visibility == ApplicationWindow.FullScreen)) {
            pWindowStateBeforeMinimized = -1
            pIsShowMaximizedCalled = false
            if (pFullScreenPopupControl != null)
                pFullScreenPopupControl.fClosePopup()
            if (pExitFullScreenControl != null)
                pExitFullScreenControl.fClosePopup()
            iAppwin.showMaximized()
            pIsShowMaximizedCalled = true

            //setting geometry when window goes automatically goes to fullscreen on maximizing
            //-- 1px height adjust for taskbar autohide case
            //-- taskbar height/width adjust for secondary monitor case
            if (Screen.height === iAppwin.height && Screen.width === iAppwin.width)
                plrBackend.setMainWindowGeometryOnMaximized(iAppwin.x, iAppwin.y, iAppwin.width, iAppwin.height)
        }
    }

    onClosing: {
        console.info("plr onClosing signal called")
        if(uiBackend.isOsShuttingDown())
        {
            plrBackend.onCloseCalled("OS_shutting_down");
        }
        else
        {
            close.accepted = false
            iTopbar.fShowClosePlrMsg()
        }
    }

    Component.onCompleted: {
        if (!pCompLoaded)
            fSetUiParams(iSidebar.visible)

        iBootLoader.sourceComponent = iBootProgressComponent
        pCompLoaded = true
    }

    Connections {
        target: pSettingsWindow

        function onShowRestartLoader() {
            pLoadingScreenControl = iLoadingScreen.createObject(iAppwin)
            pLoadingScreenControl.show()
        }

        function onGamepadDetectionEnabled() {
            fGamepadDetectionMessage()
        }
    }

    Connections {
        target: pSyncOperationsWindow

        function onClosing() {
            pSyncOperationsWindow.destroy()
        }
    }

    Connections {
        target: pScreenTranslateWindow

        function onClosing() {
            pScreenTranslateWindow.destroy()
            uiBackend.pIsShortcutsEnabled = true
        }
    }

    Component {
        id: iLoadingScreen
        UiLoadingScreen {
            width: iAppwin.width
            height: iAppwin.height
        }
    }

    Component {
        id: iToastComponent
        UiToastPopup { }
    }

    Component {
        id:iFullScreenPopupControlComponent
        PlrFullScreenPopup { }
    }

    Component {
        id:iExitFullScreenPopupControlComponent
        PlrExitFullScreenPopup { }
    }

    Component {
        id: iBootProgressComponent
        PlrBootProgressBar {}
    }

    Component {
        id: iFeedbackPillComponent

        UiWindowedPopup {
            id: iFeedbackPillWindow
            x: iAppwin.x + plrBackend.inputWinOffsets[0] + 32
            y: iAppwin.y + plrBackend.inputWinOffsets[1] + plrBackend.inputWinOffsets[3] - contentHeight - 32

            visible: iAppwin.height > 260
            contentWidth: iTroubleSigningInBtn.implicitWidth
            contentHeight: iTroubleSigningInBtn.implicitHeight
            closeOnPressOutside: false
            shadowVisibility: false
            UiRowLayout {
                id: iTroubleSigningInBtn
                spacing: 8
                topPadding: 12
                bottomPadding: 12
                leftPadding: 16
                rightPadding: 16
                radius: 24
                color: pMouseArea.containsMouse ? UiTheme.colors.dangerHover : UiTheme.colors.dangerNormal

                pMouseArea {
                    anchors.fill: iTroubleSigningInBtn
                    enabled: true
                    hoverEnabled: true
                    cursorShape: iTroubleSigningInBtn.pMouseArea.containsMouse ? Qt.PointingHandCursor : Qt.ArrowCursor
                    onClicked:{
                        uiBackend.openHelpArticle("trouble_google_play_sign_in")
                        plrBackend.sendTroubleSigningInBtnStats("trouble_signing_in_clicked")
                    }
                }
                UiImage {
                    asset: "HelpGoogleSignIn"
                    pImageWidth: 24
                    pImageHeight: 24
                }
                Text {
                    text: qsTranslate("QObject", "Trouble signing in?")
                    font: UiTheme.fonts.titleSmall
                    color: UiTheme.colors.primary10
                    visible: iAppwin.width > 360 && iAppwin.height > 360
                }
            }
        }

    }


    Component {
        id: iGlContainerComponent
        Rectangle {
            color: "#000000"
        }
    }

    Component {
        id: iSettingsItems
        SettingElementModelList {
            SettingElementModel {
                pButtonText: qsTranslate("QObject", "Performance");     pQmlSource: "UiPerformanceSetting.qml"
                pComponentArgs: { "pVmName": plrBackend.getVmName(), "pParentWindow": "plr"}
            }
            SettingElementModel {
                pButtonText: qsTranslate("QObject", "Display");         pQmlSource:"UiDisplaySetting.qml"
                pComponentArgs:{ "pParentWindow": "plr"}
            }
            SettingElementModel {
                pButtonText: qsTranslate("QObject", "Graphics");        pQmlSource:"UiGraphicsSetting.qml"
                pComponentArgs:{ "pVmName": plrBackend.getVmName(), "pParentWindow": "plr"}
            }
            SettingElementModel {
                pButtonId: "gameSettings";                             pButtonText: qsTranslate("QObject", "Game settings");
                pQmlSource:"PlrGameSetting.qml";                       pComponentArgs:{ "pParentWindow": "plr"}
            }
            SettingElementModel {
                pButtonText: qsTranslate("QObject", "Devices");           pQmlSource: "PlrAudioSetting.qml"
                pComponentArgs:{ "pParentWindow": "plr"}
            }
            SettingElementModel {
                pButtonText: qsTranslate("QObject", "Gamepad");         pQmlSource: "PlrGamepadSetting.qml"
                pComponentArgs:{ "pParentWindow": "plr"}
            }
            SettingElementModel {
                pButtonText: qsTranslate("QObject", "Preferences");     pQmlSource:"PlrPreferencesSetting.qml"
                pComponentArgs:{ "pParentWindow": "plr"}
            }
            SettingElementModel {
                pButtonText: qsTranslate("QObject", "Phone"); pQmlSource: "PlrDeviceSetting.qml"
                pComponentArgs:{ "pParentWindow": "plr"}
            }
            SettingElementModel {
                pButtonId: "shortcuts";                                 pButtonText: qsTranslate("QObject", "Shortcuts");
                pQmlSource:"PlrShortcutsSetting.qml";                   pComponentArgs:{ "pParentWindow": "plr"}
            }
            SettingElementModel {
                pButtonText: qsTranslate("QObject", "User data");
                pQmlSource:"PlrUserDataSetting.qml";                    pComponentArgs:{ "pParentWindow": "plr"}
                pShowRedDot: plrBackend.pDiskOptimizationOnboarding
            }
            SettingElementModel {
                pButtonText: qsTranslate("QObject", "Advanced");        pQmlSource:"PlrAdvancedSetting.qml"
                pComponentArgs:{ "pParentWindow": "plr"}
                pIsVisible : uiBackend.oem !== "wmx"
            }
            SettingElementModel {
                pButtonText: qsTranslate("QObject", "About");           pQmlSource:"PlrAboutSetting.qml"
                pComponentArgs:{ "pParentWindow": "plr"}
            }
        }
    }

    Component {
        id: iRedDotComponent
        Rectangle {
            width: 6
            height: 6
            radius: 3
            color: UiTheme.colors.dangerNormal
        }
    }

    Component {
        id: iApkInstallFailurePrompt
        UiMessageDialog {
            title: qsTranslate("QObject", "Installation error")
            pDescription: qsTranslate(
                              "QObject",
                              "Unfortunately, this app could not be installed. Please verify the installation file before trying again.")
            pDialogType: UiDialogWindow.Simple
            pButtonsList: DialogButtonModelList {
                pButtons: [
                    DialogButtonModel {
                        pColor: UiTheme.buttons.colors.accent
                        pText: qsTranslate("QObject", "Ok")
                        onClicked: {
                            close()
                        }
                    }
                ]
            }
        }
    }

    Component {
        id: iGamepadDetectionMessageComponent
        UiMessageDialog {
            id: iGamepadMessage
            pDialogType: UiDialogWindow.Tall
            title: qsTranslate("QObject", "Gamepad detected")
            pDescription: qsTranslate("QObject", "You can play your favorite games using gamepad on %1.").arg(uiBackend.productName)
            pHyperlink: qsTranslate("QObject", "Learn more")
            onHyperlinkClicked: uiBackend.openHelpArticle("gamepad_detection")
            pDialogImageSource: "GamepadLarge"
            pButtonsList: DialogButtonModelList {
                pButtons: [
                    DialogButtonModel {
                        pColor: UiTheme.buttons.colors.accent
                        pText: qsTranslate("QObject", "Okay")
                        onClicked: {
                            iGamepadMessage.close()
                        }
                    }
                ]
            }
            pCheckBoxText: qsTranslate("QObject", "Do not show again")
            onCheckBoxClicked: {
                uiBackend.confSetBool("bst.show_gamepad_detection_message", !checked)
                uiBackend.confCommit()
            }
        }
    }

    Component {
        id: iGameControlsUpdatedPrompt
        UiMessageDialog {
            title: qsTranslate("QObject", "Game controls updated")
            pDescription: qsTranslate(
                              "QObject",
                              "The default game controls have been updated. If you have created your own controls, they won't be affected.")
            pDialogType: UiDialogWindow.Descriptive
            pDialogImageSource: "Info"
            pButtonsList: DialogButtonModelList {
                pButtons: [
                    DialogButtonModel {
                        pColor: UiTheme.buttons.colors.accent
                        pText: pArticleKey === "" ? qsTranslate("QObject", "Okay") : qsTranslate("QObject", "Know more")
                        onClicked: {
                            if(pArticleKey !== "")
                                Qt.openUrlExternally(pArticleKey)
                            close()
                        }
                    }
                ]
            }
        }
    }

    Component {
        id: iMultipleCamerasConnectedPrompt
        UiMessageDialog {
            title: qsTranslate("QObject", "Multiple cameras detected")
            pDescription: qsTranslate(
                              "QObject",
                              "You can change your default camera from Settings > Devices > Camera")
            pDialogType: UiDialogWindow.Simple
            pCloseBtnVisible: false
            pButtonsList: DialogButtonModelList {
                pButtons: [
                    DialogButtonModel {
                        pColor: UiTheme.buttons.colors.accent
                        pText: qsTranslate("QObject", "Okay")
                        onClicked: close()
                    }
                ]
            }
            pCheckBoxText: qsTranslate("QObject", "Do not show this again")
            onCheckBoxClicked: {
                uiBackend.confSetBool("bst.show_camera_detection_message", !checked)
                uiBackend.confCommit()
            }
        }
    }

    Component {
        id: iChargerWarningComponent
        UiMessageDialog {
            id: iChargerWarningPopup
            pDialogType: UiDialogWindow.Graphic
            title: qsTranslate("QObject", "Connect your charger")
            pDescription: qsTranslate("QObject", "If you want to get the most out of your gaming sessions, make sure your laptop is plugged in. You'll have a smoother, more enjoyable experience.")
            pDialogImageSource: "Charger"
            pCloseBtnVisible: false
            pButtonsList: DialogButtonModelList {
                pButtons: [
                    DialogButtonModel {
                        pColor: UiTheme.buttons.colors.accent
                        pText: qsTranslate("QObject", "Okay, got it")
                        onClicked: {
                            if (iChargerWarningPopup.pCheckBoxState) {
                                uiBackend.confSetBool("bst.show_charger_warning", false)
                                uiBackend.confCommit()
                            }
                            iChargerWarningPopup.close()
                        }
                    }
                ]
            }
            pCheckBoxText: qsTranslate("QObject", "Do not show this again")
            onClosed: {
                pChargerWarningPopupWindow = null
                plrBackend.releaseDisplayChargerWarningLock()
            }
        }
    }

    Component {
        id: iAdsInfoPrompt
        UiMessageDialog {
            id: iAdsInfo
            UiOverlay.overlayRect: Qt.rect(iAppwin.x + pBorderWidth + iMainContentLayout.x,
                                           iAppwin.y + pBorderWidth + iMainContentLayout.y,
                                           iMainContentLayout.width,
                                           iMainContentLayout.height)
            pDialogType: UiDialogWindow.Graphic
            title: qsTranslate("QObject", "Ads on %1").arg(uiBackend.productName)
            pDescription: uiBackend.confGetBool("bst.feature.show_programmatic_ads_preference")
                          ? qsTranslate("QObject", "%1 stays free because of ads. Support us by keeping Ads enabled. You can choose to hide them at any time from Settings.").arg(uiBackend.productName)
                          : qsTranslate("QObject", "%1 stays free because of ads. Please support us.").arg(uiBackend.productName)
            pDialogImageSource: "AdsPopupInfoImage"
            pButtonsList: DialogButtonModelList {
                pButtons: [
                    DialogButtonModel {
                        pColor: UiTheme.buttons.colors.accent
                        pText: qsTranslate("QObject", "Okay")
                        onClicked: {
                            iAdsInfo.close()
                        }
                    }
                ]
            }
        }
    }

    Component {
        id: iAdsEnableOnBootPrompt
        UiMessageDialog {
            id: iAdsEnableOnBoot
            UiOverlay.overlayRect: Qt.rect(iAppwin.x + pBorderWidth + iMainContentLayout.x,
                                           iAppwin.y + pBorderWidth + iMainContentLayout.y,
                                           iMainContentLayout.width,
                                           iMainContentLayout.height)
            pDialogType: UiDialogWindow.Graphic
            title: qsTranslate("QObject", "Help Keep %1 Free and Awesome").arg(uiBackend.productName)
            pDescription: qsTranslate("QObject", "Show us some love and keep ads enabled. We depend on ad revenue to keep %1 free for you.").arg(uiBackend.productName)
            pDialogImageSource: "AdsPopupInfoImage"
            pButtonsList: DialogButtonModelList {
                pButtons: [
                    DialogButtonModel {
                        pColor: UiTheme.buttons.colors.accent
                        pText: qsTranslate("QObject", "Enable Ads")
                        onClicked: {
                            uiBackend.confSetBool("bst.enable_programmatic_ads", true)
                            uiBackend.confCommit()
                            plrBackend.sendDisplayAdsStats("reset_setting_popup_click", "enable")
                            iAdsEnableOnBoot.close()
                        }
                    },
                    DialogButtonModel {
                        pColor: UiTheme.buttons.colors.tertiary
                        pText: qsTranslate("QObject", "No, Thanks")
                        onClicked: {
                            plrBackend.sendDisplayAdsStats("reset_setting_popup_click", "disable")
                            iAdsEnableOnBoot.close()
                        }
                    }
                ]
            }
            onCloseClicked: {
                plrBackend.sendDisplayAdsStats("reset_setting_popup_click", "close")
            }
        }
    }

    Component {
        id: iSignInRequiredPrompt
        Window {
            color: "transparent"
            flags: Qt.Window | Qt.FramelessWindowHint
            modality: Qt.ApplicationModal
            width: 360 + 2 * iShadow.shadowThickness
            height: 400 + 2 * iShadow.shadowThickness
            screen: transientParent.screen

            onClosing: pSigninRequiredWindow.destroy()

            UiShadowContainer {
                id: iShadow
                UiColumnLayout {
                    anchors.fill: parent
                    leftPadding: 20
                    rightPadding: 20
                    topPadding: 20
                    bottomPadding: 40
                    color: UiTheme.colors.primary70
                    border {
                        color: UiTheme.colors.primary60
                        width: 1
                    }

                    UiImageButton {
                        asset: "CloseIcon"
                        pImageWidth: 16
                        pImageHeight: 16
                        Layout.alignment: Qt.AlignRight
                        onClicked: {
                            if (pSigninRequiredWindow != null) {
                                pSigninRequiredWindow.close()
                                plrBackend.sendMomentsStats("moments_signin_popup_closed")
                            }
                        }
                    }

                    UiColumnLayout {
                        Layout.fillWidth: true
                        Layout.fillHeight: true

                        UiImage {
                            asset: "MomentsIcon"
                            extn: ".png"
                            pImageWidth: 72
                            pImageHeight: 72
                            Layout.alignment: Qt.AlignHCenter
                        }
                        Text {
                            text: qsTranslate("QObject", "MOMENTS")
                            font: UiTheme.fonts.bodySmall
                            color: UiTheme.colors.primary10
                            wrapMode: Text.NoWrap
                            Layout.fillWidth: true
                            horizontalAlignment: Text.AlignHCenter
                        }
                        Text {
                            text: qsTranslate("QObject", "Sign in required")
                            font: UiTheme.fonts.titleMedium
                            color: UiTheme.colors.primary10
                            wrapMode: Text.NoWrap
                            Layout.fillWidth: true
                            horizontalAlignment: Text.AlignHCenter
                            Layout.topMargin: 20
                        }
                        Text {
                            text: qsTranslate("QObject", "Moments mode is powered by now.gg cloud. Please log in to continue.")
                            font: UiTheme.fonts.bodyLarge
                            color: UiTheme.colors.primary20
                            wrapMode: Text.Wrap
                            Layout.fillWidth: true
                            Layout.leftMargin: 20
                            Layout.rightMargin: 20
                            horizontalAlignment: Text.AlignHCenter
                            Layout.topMargin: 8
                        }
                        UiColumnLayout {
                            Layout.fillWidth: true
                            Layout.fillHeight: true
                            Layout.topMargin: 20
                            spacing: 16
                            UiButton {
                                asset: "NowggIcon"
                                extn: ".png"
                                text: qsTranslate("QObject", "Sign in with Now.gg")
                                pSize: UiTheme.buttons.sizes.large
                                pColor: UiTheme.buttons.colors.accent
                                Layout.fillWidth: true
                                Layout.alignment: Qt.AlignHCenter
                                onClicked: {
                                    if (pSigninRequiredWindow != null) {
                                        pSigninRequiredWindow.close()
                                        plrBackend.signinToNowGG()
                                    }
                                }
                            }
                            UiRowLayout {
                                spacing: 20
                                Layout.fillWidth: true
                                Layout.alignment: Qt.AlignHCenter
                                Rectangle {
                                    height: 1
                                    Layout.fillWidth: true
                                    color: UiTheme.colors.primary50
                                }
                                Text {
                                    text: qsTranslate("QObject", "Or")
                                    font: UiTheme.fonts.bodyRegular
                                    color: UiTheme.colors.white
                                }
                                Rectangle {
                                    height: 1
                                    Layout.fillWidth: true
                                    color: UiTheme.colors.primary50
                                }
                            }

                            UiButton {
                                text: qsTranslate("QObject", "Continue as guest")
                                pSize: UiTheme.buttons.sizes.large
                                pColor: UiTheme.buttons.colors.alternate
                                Layout.fillWidth: true
                                Layout.alignment: Qt.AlignHCenter
                                onClicked: {
                                    if (pSigninRequiredWindow != null) {
                                        pSigninRequiredWindow.close()
                                        plrBackend.handleGuestLogin()
                                        plrBackend.sendMomentsStats("moments_signin_popup_signin_clicked", "guest_button")
                                    }
                                }
                            }
                        }
                    }
                }
            }
        }
    }

    Component {
        id: iSignInSuccessfulPrompt
        UiMessageDialog {
            id: iSigninSuccessfulDialog
            property bool pShowEnableMoments: true
            title: qsTranslate("QObject", "Sign in successful")
            pDescription: qsTranslate("QObject", "You are now ready to use moments mode and record your epic gameplay")
            pDialogType: UiDialogWindow.Tall
            pDialogImageSource: "MomentsIcon"
            pDialogImageExtn: ".png"
            pButtonsList: DialogButtonModelList {
                pButtons: [
                    DialogButtonModel {
                        pColor: UiTheme.buttons.colors.accent
                        pText: iSigninSuccessfulDialog.pShowEnableMoments ? qsTranslate("QObject", "Turn Moments Mode on") : qsTranslate("QObject", "Okay")
                        onClicked: {
                            if (iSigninSuccessfulDialog.pShowEnableMoments) {
                                plrBackend.handleMomentsToggled(true)
                                plrBackend.sendNowggSignInStats("moments_signin_enabled")
                            }
                            close()
                        }
                    }
                ]
            }
        }
    }

    Component {
        id: iDisableMomentPrompt
        UiMessageDialog {
            title: qsTranslate("QObject", "Record Gameplay")
            pDescription: qsTranslate("QObject", "To start recording, you need to disable Moments first.")
            pDialogType: UiDialogWindow.DescriptiveNarrow
            pDialogHeaderImageSource: "ScreenRecordOutline"
            pDialogImageSource: "ErrorLarge"
            pButtonsList: DialogButtonModelList {
                pButtons: [
                    DialogButtonModel {
                        pColor: UiTheme.buttons.colors.accent
                        pText: qsTranslate("QObject", "Okay")
                        onClicked: {
                            close()
                        }
                    }
                ]
            }
        }
    }

    Component {
        id: iDisableRecordingPrompt
        UiMessageDialog {
            title: qsTranslate("QObject", "Record Moments")
            pDescription: qsTranslate("QObject", "To start moments, you need to stop recording first.")
            pDialogType: UiDialogWindow.DescriptiveNarrow
            pDialogHeaderImageSource: "ScreenRecordOutline"
            pDialogImageSource: "ErrorLarge"
            pButtonsList: DialogButtonModelList {
                pButtons: [
                    DialogButtonModel {
                        pColor: UiTheme.buttons.colors.accent
                        pText: qsTranslate("QObject", "Okay")
                        onClicked: {
                            close()
                        }
                    }
                ]
            }
        }
    }

    Component {
        id: iCheckBrowserPrompt
        UiMessageDialog {
            title: qsTranslate("QObject", "Check your browser")
            pDescription: qsTranslate("QObject", "Finish logging in from your web browser")
            pDialogType: UiDialogWindow.Tall
            pDialogImageSource: "Browser"
            pNotice: qsTranslate("QObject", "Not seeing the browser tab? Try again")
            pButtonsList: DialogButtonModelList {
                pButtons: [
                    DialogButtonModel {
                        pColor: UiTheme.buttons.colors.accent
                        pText: qsTranslate("QObject", "Try Again")
                        onClicked: {
                            close()
                            plrBackend.signinToNowGG()
                        }
                    }
                ]
            }
        }
    }

    Component {
        id: iLowDiskSpacePrompt
        UiMessageDialog {
            id: iRoot
            title: qsTranslate("QObject", "Warning!")
            pDescription: qsTranslate("QObject", "Your system is running low on disk space. Please free up some space to avoid any issues.")
            pDialogType: UiDialogWindow.DescriptiveNarrow
            pDialogImageSource: "WarningLarge"

            property bool isMoment: true

            pButtonsList: DialogButtonModelList {
                pButtons: [
                    DialogButtonModel {
                        pColor: UiTheme.buttons.colors.accent
                        pText: qsTranslate("QObject", "Okay")
                        onClicked: {
                            if (iRoot.isMoment)
                                plrBackend.startMomentMode()
                            else
                                plrBackend.recordScreen()

                            close()
                        }
                    }
                ]
            }
        }
    }

    Component {
        id: iSignOutPrompt
        UiMessageDialog {
            property string userName: "Johnny Vicks"
            property string userEmail: "john@vicks.com"
            title: userName
            pDescription: userEmail
            pDialogType: UiDialogWindow.TallAlert
            pDialogImageSource: "ProfileLogo"
            pButtonsList: DialogButtonModelList {
                pButtons: [
                    DialogButtonModel {
                        pColor: UiTheme.buttons.colors.accent
                        pText: qsTranslate("QObject", "Sign Out")
                        onClicked: {
                            close()
                            fShowSignOutConfirmationDialog()
                        }
                    }
                ]
            }
        }
    }

    Component {
        id: iSignOutConfirmationPrompt
        UiMessageDialog {
            title: qsTranslate("QObject", "Confirm sign out")
            pDescription: qsTranslate("QObject", "You will not be able to access your saved moments from the cloud. Are you sure you want to sign out?")
            pDialogType: UiDialogWindow.GraphicSimple
            pDialogImageSource: "WarningLarge"
            pButtonsList: DialogButtonModelList {
                pButtons: [
                    DialogButtonModel {
                        pSize: UiTheme.buttons.sizes.large
                        pColor: UiTheme.buttons.colors.danger
                        pText: qsTranslate("QObject", "Sign Out")
                        onClicked: {
                            close()
                            if (pSignOutPopupWindow != null)
                                pSignOutPopupWindow.close()
                            mediaBackend.signOutNowggAccount()
                        }
                    },
                    DialogButtonModel {
                        pSize: UiTheme.buttons.sizes.large
                        pColor: UiTheme.buttons.colors.secondary
                        pText: qsTranslate("QObject", "Cancel")
                        onClicked: {
                            close()
                        }
                    }
                ]
            }
        }
    }

    Component {
        id: iLinkNowggAccountPrompt
        Window {
            id: iMainWin
            color: "transparent"
            flags: Qt.Window | Qt.FramelessWindowHint
            modality: Qt.ApplicationModal
            width: 360 + 2 * iShadow.shadowThickness
            height: 380 + 2 * iShadow.shadowThickness
            screen: transientParent.screen

            property string videoId: ""
            property bool pShowDoNotShowAgain: true

            onClosing: pLinkNowggAccountWindow.destroy()

            UiShadowContainer {
                id: iShadow
                UiColumnLayout {
                    anchors.fill: parent
                    leftPadding: 20
                    rightPadding: 20
                    topPadding: 20
                    bottomPadding: 40
                    color: UiTheme.colors.primary70
                    border {
                        color: UiTheme.colors.primary60
                        width: 1
                    }

                    UiImageButton {
                        asset: "CloseIcon"
                        pImageWidth: 16
                        pImageHeight: 16
                        Layout.alignment: Qt.AlignRight
                        onClicked: {
                            if (pLinkNowggAccountWindow != null) {
                                pLinkNowggAccountWindow.close()
                                plrBackend.sendMomentsStats("moments_link_account_popup_closed", mediaBackend.pLinkAccountSource)
                            }
                        }
                    }

                    UiColumnLayout {
                        Layout.fillWidth: true
                        Layout.fillHeight: true

                        UiImage {
                            asset: "ScreenRecordingActive"
                            pImageWidth: 72
                            pImageHeight: 72
                            Layout.alignment: Qt.AlignHCenter
                        }
                        Text {
                            text: qsTranslate("QObject", "Link your account")
                            font: UiTheme.fonts.titleMedium
                            color: UiTheme.colors.primary10
                            wrapMode: Text.NoWrap
                            Layout.fillWidth: true
                            horizontalAlignment: Text.AlignHCenter
                            Layout.topMargin: 20
                        }
                        Text {
                            text: qsTranslate("QObject", "Sign in to link your moments to your account")
                            font: UiTheme.fonts.bodyLarge
                            color: UiTheme.colors.primary20
                            wrapMode: Text.Wrap
                            Layout.fillWidth: true
                            Layout.leftMargin: 20
                            Layout.rightMargin: 20
                            horizontalAlignment: Text.AlignHCenter
                            Layout.topMargin: 8
                        }
                        UiColumnLayout {
                            Layout.fillWidth: true
                            Layout.fillHeight: true
                            Layout.topMargin: 20
                            spacing: 16
                            UiButton {
                                asset: "NowggIcon"
                                extn: ".png"
                                text: qsTranslate("QObject", "Sign in with Now.gg")
                                pSize: UiTheme.buttons.sizes.large
                                pColor: UiTheme.buttons.colors.accent
                                Layout.fillWidth: true
                                Layout.alignment: Qt.AlignHCenter
                                onClicked: {
                                    if (pLinkNowggAccountWindow != null) {
                                        plrBackend.sendMomentsStats("moments_link_account_signin_clicked", mediaBackend.pLinkAccountSource)
                                        pLinkNowggAccountWindow.close()
                                        plrBackend.signinToNowGG(false)
                                        if (iDoNotShowAgainChkbox.checked) {
                                            uiBackend.confSetBool("bst.do_not_show_link_account_popup", true)
                                            uiBackend.confCommit()
                                            plrBackend.reloadConfInAllInstances()
                                        }
                                    }
                                }
                            }
                            UiButton {
                                text: qsTranslate("QObject", "No, continue as guest")
                                pSize: UiTheme.buttons.sizes.large
                                pColor: UiTheme.buttons.colors.alternate
                                Layout.fillWidth: true
                                Layout.alignment: Qt.AlignHCenter
                                onClicked: {
                                    if (pLinkNowggAccountWindow != null) {
                                        plrBackend.sendMomentsStats("moments_link_account_continue_as_guest_click", mediaBackend.pLinkAccountSource)
                                        if (iDoNotShowAgainChkbox.visible && iDoNotShowAgainChkbox.checked) {
                                            plrBackend.sendMomentsStats("moments_link_account_do_not_show_again_selected", mediaBackend.pLinkAccountSource)
                                            uiBackend.confSetBool("bst.do_not_show_link_account_popup", true)
                                            uiBackend.confCommit()
                                            plrBackend.reloadConfInAllInstances()
                                        }
                                        pLinkNowggAccountWindow.close()
                                        if (iMainWin.videoId !== "")
                                            mediaBackend.playMoments(iMainWin.videoId, false)
                                    }
                                }
                            }
                            UiCheckBox {
                                id: iDoNotShowAgainChkbox
                                visible: iMainWin.pShowDoNotShowAgain
                                pSize: UiTheme.checkBoxes.sizes.small
                                text: qsTranslate("QObject", "Do not show this again")
                                checked: false
                                Layout.alignment: Qt.AlignHCenter
                            }
                        }
                    }
                }
            }
        }
    }

    Rectangle {
        id: iMainContentLayout
        anchors.fill: parent
        anchors.margins: iAppwin.visibility == ApplicationWindow.FullScreen ? 0 : pBorderWidth
        color: "#000000"

        Loader {
            id: iBootLoader
            anchors.left: parent.left
            anchors.right: iSidebar.left
            anchors.top: iTopbar.bottom
            anchors.bottom: parent.bottom
        }
        UiRowLayout {
            anchors.left: parent.left
            anchors.top: parent.top
            anchors.bottom: parent.bottom
            Repeater {
                id: iAdRepeater
                model: adsBackend.pLeftAds
                delegate: PlrAdSlot {
                    id: iLeftAdSlot
                    Layout.fillHeight: true
                    Layout.preferredWidth: ((iAppwin.height - dataObject.pAdVerticalOffset) * dataObject.pAdRatio) + dataObject.pAdVerticalOffset
                    Layout.maximumWidth: dataObject.pAdMaxWidth
                    opacity: dataObject.pAdVisible ? 1 : 0
                    pWebEngineView.zoomFactor: Math.min(((iLeftAdSlot.width - dataObject.pAdHorizontalOffset) * 1.0) / dataObject.pAdWidth, ((iLeftAdSlot.height - dataObject.pAdVerticalOffset) * 1.0) / dataObject.pAdHeight)
                    pWebEngineView.url: dataObject.pWebEngineViewUrl
                    pAdSlotBrowserPreference: dataObject.pAdClickBrowserPreference
                    pWebEngineView.webChannel: dataObject.pWebChannel
                    pWebEngineView.profile.httpUserAgent: dataObject.pWebEngineUserAgent

                    Component.onCompleted: {
                        dataObject.pExtendedBannerAdWidth = Qt.binding(function(){ return (dataObject.pAdVisible ? iLeftAdSlot.width : 0) })
                    }

                    Connections {
                        target: dataObject
                        function onRunJsFuncInWebEngineView(script) {
                            console.info("fRunJsFunctionInWebView - script: " + script)
                            iLeftAdSlot.pWebEngineView.runJavaScript(script)
                        }
                    }


                    Connections {
                        target: dataObject
                        function onAdCloseClicked() {
                            if (iLeftAdSlot.pWebEngineView != null)
                                iLeftAdSlot.pWebEngineView.destroy()
                        }
                        function onExtendedBannerAdWidthChanged() {
                            if (index === 0)
                                adsBackend.pExtendedBannerAdWidth = dataObject.pExtendedBannerAdWidth
                        }
                    }

                    Connections {
                        target: iLeftAdSlot
                        function onAdSlotClicked(clickUrl) {
                            dataObject.adClicked(clickUrl)
                        }
                    }

                    Connections {
                        target: adsBackend
                        function onEditorWindowVisibleChanged() {
                            if (index === 0) {
                                if (adsBackend.currentBannerAdVisibile) {
                                    if (adsBackend.editorWindowVisible) {
                                        dataObject.adHide()
                                    }
                                    else {
                                        dataObject.adUnhide()
                                    }
                                }
                            }
                        }
                    }

                    Connections {
                        target: iAppwin
                        function onHeightChanged() {
                            if (index === 0) {
                                if (dataObject.pAdVisible) {
                                    dataObject.adResize()
                                }
                            }
                        }

                        function onVisibilityChanged(visibility) {
                            if (index === 0) {
                                if (adsBackend.currentBannerAdVisibile) {
                                    if (visibility === ApplicationWindow.Maximized || visibility === ApplicationWindow.Windowed) {
                                        if (dataObject.pAdVisible) {
                                            dataObject.adResize()
                                        }
                                        else {
                                            dataObject.adUnhide()
                                        }
                                    }
                                    else if (visibility === ApplicationWindow.FullScreen) {
                                        dataObject.adHide()
                                    }
                                }
                            }
                        }
                    }
                }
            }
        }

        Rectangle {
            color: UiTheme.colors.primary60
            width: adsBackend.pExtendedBannerAdWidth > 0 ? 1 : 0
            anchors.left: parent.left
            anchors.top: parent.top
            anchors.bottom: parent.bottom
            anchors.leftMargin: adsBackend.pExtendedBannerAdWidth
        }

        PlrTopbar {
            id: iTopbar
            anchors.left: parent.left
            anchors.right: parent.right
            anchors.top: parent.top
            anchors.leftMargin: adsBackend.pExtendedBannerAdWidth > 0  ? adsBackend.pExtendedBannerAdWidth + pBorderWidth : adsBackend.pExtendedBannerAdWidth
            height: 32
            color: uiBackend.oem === "msi5" ? UiTheme.colors.primary70 : UiTheme.colors.primary80
            visible: iAppwin.visibility == ApplicationWindow.FullScreen ? false : true
            onSidebarBtnClicked: {
                iSidebar.visible = true
                fSetUiParams(true)
                if (iAppwin.visibility != ApplicationWindow.Maximized)
                    iAppwin.width += iAppwin.pSidebarWidth
                uiBackend.confSetInstanceBool("show_sidebar", true)
                plrBackend.onSidebarVisibilityChanged()
                iTopbar.fReloadTopbarElements()
            }

            onSidebarHideClicked: {
                iSidebar.visible = false
                fSetUiParams(false)
                if (iAppwin.visibility != ApplicationWindow.Maximized) {
                    iAppwin.width -= iAppwin.pSidebarWidth
                }

                uiBackend.confSetInstanceBool("show_sidebar", false)
                plrBackend.onSidebarVisibilityChanged()
                iTopbar.fReloadTopbarElements()
            }

            onHamburgerSettingClicked: fOpenSettingsWindow()
        }
        PlrSidebar {
            id: iSidebar
            anchors.bottom: parent.bottom
            anchors.right: parent.right
            anchors.top: iTopbar.bottom
            color: uiBackend.oem === "msi5" ? UiTheme.colors.primary70 : UiTheme.colors.primary80
            width: pSidebarWidth
            visible: uiBackend.confGetInstanceBool("show_sidebar")
            onSidebarSettingClicked: fOpenSettingsWindow()
        }
    }

    function fCloseAllChildWindows() {
        if (pSettingsWindow != null)
            pSettingsWindow.destroy()

        fDestroyMacroManagerWindow()

        fCloseFlePopup()

        if (pSyncOperationsWindow != null)
            pSyncOperationsWindow.destroy()

        if (pScreenTranslateWindow != null)
            pScreenTranslateWindow.destroy()

        if (pLoadingScreenControl != null)
            pLoadingScreenControl.destroy()

        if (pFullScreenPopupControl != null)
            pFullScreenPopupControl.fClosePopup()

        if (pNotificationBarWindow != null)
            pNotificationBarWindow.close()

        if (pChargerWarningPopupWindow != null)
            pChargerWarningPopupWindow.destroy()

        if(pTroubleSigningInBtn != null)
            pTroubleSigningInBtn.destroy()

        if (pExitFullScreenControl != null)
            pExitFullScreenControl.fClosePopup()

        if(pMediaGalleryWindow != null)
            pMediaGalleryWindow.destroy()

        iSidebar.fCloseFullScreenBlurb()

        adsBackend.closeBannerAds()

        if (pBrowserWindow != null)
            pBrowserWindow.close()
    }

    function fSetUiParams(sidebarVisible) {
        plrBackend.setBackendUiParams(
                    pBorderWidth + adsBackend.pExtendedBannerAdWidth + (adsBackend.pExtendedBannerAdWidth > 0 ? pBorderWidth : 0),
                    iTopbar.height + pBorderWidth,
                    pBorderWidth + (sidebarVisible ? iAppwin.pSidebarWidth : 0),
                    pBorderWidth,
                    7 * iTopbar.height + 50 + pBorderWidth * 2)
    }

    function fUiShowNormal() {
        pIsShowMaximizedCalled = false
        if (iAppwin.visibility == ApplicationWindow.FullScreen) {
            iSidebar.visible = pSidebarVisibleBeforeFullscreen
        }
        fSetUiParams(iSidebar.visible)
        if (pFullScreenPopupControl != null)
            pFullScreenPopupControl.fClosePopup()

        if (pExitFullScreenControl != null)
            pExitFullScreenControl.fClosePopup()
        iAppwin.showNormal()
        iAppwin.x = pX
        iAppwin.y =pY
        iAppwin.width = pWidth
        iAppwin.height = pHeight

        plrBackend.onRestoreOrientation()
    }

    function fUiShowMaximized() {
        fUISaveSize()
        pIsShowMaximizedCalled = false
        if (iAppwin.visibility == ApplicationWindow.FullScreen) {
            iSidebar.visible = pSidebarVisibleBeforeFullscreen
        }
        fSetUiParams(iSidebar.visible)
        if (pFullScreenPopupControl != null)
            pFullScreenPopupControl.fClosePopup()
        if (pExitFullScreenControl != null)
            pExitFullScreenControl.fClosePopup()
        iAppwin.showMaximized()

        pIsShowMaximizedCalled = true

        //setting geometry when window goes automatically goes to fullscreen on maximizing
        //-- 1px height adjust for taskbar autohide case
        //-- taskbar height/width adjust for secondary monitor case
        if (Screen.height === iAppwin.height && Screen.width === iAppwin.width)
            plrBackend.setMainWindowGeometryOnMaximized(iAppwin.x, iAppwin.y, iAppwin.width, iAppwin.height)
    }

    function fUISaveSize()
    {
        if (iAppwin.visibility === ApplicationWindow.Windowed)
        {
            pX = iAppwin.x
            pY = iAppwin.y
            pWidth = iAppwin.width
            pHeight = iAppwin.height
        }
    }

    function fUiShowFullscreen(showPopup) {
        fUISaveSize()
        pIsShowMaximizedCalled = false
        plrBackend.setBackendUiParams(0, 0, 0, 0, 6 * iTopbar.height + pBorderWidth * 2)
        iSidebar.fCloseFullScreenBlurb()
        pSidebarVisibleBeforeFullscreen = iSidebar.visible
        iSidebar.visible = false
        iAppwin.showFullScreen()
        if(showPopup)
        {
            if (pFullScreenPopupControl != null) {
                pFullScreenPopupControl.fClosePopup()
            }
            pFullScreenPopupControl = iFullScreenPopupControlComponent.createObject(iAppwin, {"pMessage": qsTranslate("QObject", "Press {%1} to exit fullscreen").arg(
                                                                                                              plrBackend.getDisplayComboFromNameCombo(uiBackend.confGetString("bst.shortcut.toggle_fullscreen")))})
            pFullScreenPopupControl.fShowMessage(true, plrBackend.showFullScreenSetting())
        }
    }

    function fUiHideBootProgressBar(showAdInfoPopup) {
        iBootLoader.item.fBootComplete()
        iBootLoader.sourceComponent = iGlContainerComponent
        pIsBootComplete = true
        if(showAdInfoPopup)
            fShowAdsInfoPrompt(true)
        fGamepadDetectionMessage()
    }

    function fUpdateForRawMode() {
        pIsRawMode = true;
        iTopbar.fReloadTopbarElements()
    }

    function fChangeBootPromotion(imagePath, buttonText, buttonClickMessage) {
        iBootLoader.item.fSetBootPromotion(imagePath, buttonText, buttonClickMessage)
    }

    function fSetLoadingBootPromo() {
        iBootLoader.item.fSetLoadingBootPromo()
    }

    function fSetDefaultAppSpecificBootBanner(fileName, title, appDetails)
    {
        iBootLoader.item.fSetDefaultAppSpecificBootBanner(fileName, title, appDetails);
    }

    function fUiEnableMouseCursorLock(enabled) {
        if (enabled) {
            if (pFullScreenPopupControl != null) {
                pFullScreenPopupControl.fClosePopup()
            }
            var keyText = uiBackend.confGetBool("bst.enable_esc_mousecursor") ?
                        plrBackend.getDisplayComboFromNameCombo("Esc") :
                        plrBackend.getDisplayComboFromNameCombo(uiBackend.confGetString("bst.shortcut.toggle_mouse_cursor_lock"))
            pFullScreenPopupControl = iFullScreenPopupControlComponent.createObject(iAppwin, {"pMessage" : qsTranslate("QObject", "Press {%1} to unlock mouse cursor").arg(keyText)})
            pFullScreenPopupControl.fShowMessage(true)
        }
        else {
            if (pFullScreenPopupControl != null)
                pFullScreenPopupControl.fClosePopup()
        }

        iSidebar.fUpdateMouseCursorImage(enabled)
    }

    function fOpenSettingsWindow() {
        if (pSettingsWindow != null)
            return

        var component = Qt.createComponent("UiSettingsWindow.qml")
        if (component.status === Component.Ready) {
            pSettingsWindow = component.createObject(iAppwin, { "pParentWindow": "plr", "pSettingsItems": iSettingsItems.createObject() })
            if (pSettingsWindow != null) {
                var shadowWidthDiff = 2 * pSettingsWindow.pShadowThickness
                var settingsWidth = Math.max(iAppwin.width + shadowWidthDiff,
                                             (840 + shadowWidthDiff))
                var settingsHeight = Math.max(iAppwin.height + shadowWidthDiff,
                                              (475 + shadowWidthDiff))
                var settingsX = iAppwin.x - ((settingsWidth - iAppwin.width) / 2)
                var settingsY = iAppwin.y - ((settingsHeight - iAppwin.height) / 2)

                if (settingsX < pSettingsWindow.screen.virtualX) {
                    if (iAppwin.x < pSettingsWindow.screen.virtualX)
                        settingsX = pSettingsWindow.screen.virtualX
                    else
                        settingsX = iAppwin.x - (shadowWidthDiff / 2)
                }
                if (settingsY < pSettingsWindow.screen.virtualY) {
                    if (iAppwin.y < pSettingsWindow.screen.virtualY)
                        settingsY = pSettingsWindow.screen.virtualY
                    else
                        settingsY = iAppwin.y - (shadowWidthDiff / 2)
                }

                if (iAppwin.visibility != ApplicationWindow.Maximized
                        && ((settingsX + settingsWidth) > pSettingsWindow.screen.virtualX
                            + pSettingsWindow.screen.width)) {
                    settingsX = pSettingsWindow.screen.virtualX
                            + pSettingsWindow.screen.width - settingsWidth
                }
                if (iAppwin.visibility != ApplicationWindow.Maximized
                        && ((settingsY + settingsHeight) > pSettingsWindow.screen.virtualY
                            + pSettingsWindow.screen.height)) {
                    settingsY = pSettingsWindow.screen.virtualY
                            + pSettingsWindow.screen.height - settingsHeight
                }

                pSettingsWindow.width = settingsWidth
                pSettingsWindow.height = settingsHeight
                pSettingsWindow.x = settingsX
                pSettingsWindow.y = settingsY

                pSettingsWindow.show()

                plrBackend.pSettingWindowInitializing = false
            }
        }
    }

    function fOpenMacroManagerWindow() {
        if (pMacroManagerWindow !== null || !iSidebar.pIsMacroEnabled)
            return

        if (mnsBackend.onOpenMacroManagerWindow()) {
            var component = Qt.createComponent("MnsMacroManagerWindow.qml")
            if (component.status === Component.Ready) {
                var macroX = uiBackend.confGetInstanceI32("macro_win_x")
                var macroY = uiBackend.confGetInstanceI32("macro_win_y")
                if(macroX === -1 || macroY === -1){
                    pMacroManagerWindow = component.createObject(iAppwin, { "pRunningMacroName": iTopbar.pCurrentRunningMacroName })
                }
                else{
                    var macroScreen = iAppwin.screen
                    var screens = Qt.application.screens;
                    for (var i = 0; i < screens.length; ++i){
                        if (screens[i].name === uiBackend.confGetInstanceString("macro_win_screen")){
                            macroScreen = screens[i]
                        }
                    }
                    macroX += macroScreen.virtualX
                    macroY += macroScreen.virtualY
                    var macroHeight = uiBackend.confGetInstanceI32("macro_win_height") < 360 ? 360 : uiBackend.confGetInstanceI32("macro_win_height")

                    pMacroManagerWindow = component.createObject(iAppwin, { "pRunningMacroName": iTopbar.pCurrentRunningMacroName,
                                                                     "x": macroX,
                                                                     "y": macroY,
                                                                     "height": macroHeight,
                                                                     "screen": macroScreen})
                }

                pMacroManagerWindow.stopMacro.connect(fStopMacro);
                pMacroManagerWindow.pauseMacro.connect(fToggleMacroPause);
                pMacroManagerWindow.show()
                pMacroManagerWindow.fAdjustLocation()
            }
        }
        else
        {
            if (pFullScreenPopupControl == null)
            {
                pFullScreenPopupControl = iFullScreenPopupControlComponent.createObject(iAppwin, {"pMessage" : qsTranslate("QObject", "Please stop the recording first")})
                pFullScreenPopupControl.fShowMessage(true)
            }
        }
    }



    function fShowInstallApkFailureMsg() {
        iApkInstallFailurePrompt.createObject(iAppwin).show()
    }

    function fStopMacro() {
        iTopbar.fStopMacro()
    }

    function fToggleMacroPause() {
        iTopbar.fToggleMacroPause()
    }

    function fPauseResumeSync() {
        iTopbar.fPauseResumeSync()
    }

    function fToggleEcoMode(enable) {
        pIsEcoModeEnabled = enable
    }

    function fTopbarMacroControlVisibility(visible, isMacroRecording, enableTimer) {
        pIsMacroRunning = visible
        iTopbar.pMacroRecordingInProcess = isMacroRecording
        iTopbar.pMacroTimerRunning = enableTimer
        iTopbar.pEnableTimer = enableTimer
        iTopbar.fReloadTopbarElements()
    }

    function fTopbarMacroControlNameUpdate(macroName, dependentName) {
        iTopbar.pCurrentRunningMacroName = macroName
        iTopbar.pCurrentRunningDependentMacroName = dependentName

        if (pMacroManagerWindow !== null)
            pMacroManagerWindow.pRunningMacroName = macroName
    }

    function fTopbarMacroControlIterationUpdate(count) {
        iTopbar.pMacroIterationText = qsTranslate("QObject", "%1 time").arg(count)
    }

    function fShowMacroMessageToast(code) {
        if(pMacroManagerWindow !== null)
            pMacroManagerWindow.fShowMacroMessageToast(code)
    }

    function fShowMacroImportSuccessToast(code, count) {
        if(pMacroManagerWindow !== null)
            pMacroManagerWindow.fShowMacroImportSuccessToast(code, count)
    }

    function fShowMemoryTrimmedToast(mbMemory) {
        var toast = iToastComponent.createObject(iAppwin, { pToastMessage: qsTranslate("QObject", "%1 MB memory freed up").arg(mbMemory) } )
        toast.fShowMessage()
        iSidebar.fHideTrimMemoryLoader()
    }

    function fShowFileNotSupported(fileName) {
        var toast = iToastComponent.createObject(iAppwin, { pToastMessage: qsTranslate("QObject", "%1 file not supported").arg(fileName) } )
        toast.fShowMessage()
    }

    function fShowRawModeWarning(editConf) {
        plrBackend.showRawModeWarningPopup()
        if (editConf) {
            uiBackend.confSetBool("bst.show_raw_mode_warning", false)
            uiBackend.confCommit()
        }
    }

    function fImportMacros() {
        if(pMacroManagerWindow !== null)
            pMacroManagerWindow.fImportMacros()
    }

    function fSetImageName(imageName) {
        iTopbar.fSetImageName(imageName)
    }

    function fUpdateSyncUiState(visible, source) {
        // visible to IsSyncing, source to isSource
        visible = visible === true
        iTopbar.pSyncSource = source === true
        if(!iTopbar.pSyncSource)
            iSidebar.pIsSyncEnable = !visible
        else
            iSidebar.pIsSyncColorAsset = visible

        if(!visible)
            iSidebar.pIsSyncColorAsset = false
        iTopbar.fUpdateSyncState(visible)
        iTopbar.fReloadTopbarElements()

        if(pSyncOperationsWindow !== null)
            pSyncOperationsWindow.fSetSyncState(visible)
    }

    function fOpenSyncOperationsWindow() {
        if(pSyncOperationsWindow !== null || !iSidebar.pIsSyncEnable)
            return
        var component = Qt.createComponent("MnsSyncOperationWindow.qml")
        if (component.status === Component.Ready) {
            pSyncOperationsWindow = component.createObject(iAppwin, {"pIsSyncActive" : iSidebar.pIsSyncColorAsset})
            pSyncOperationsWindow.show()
        }
    }

    function fOpenLaunchBsxWindow() {
        if(pLaunchBsxWindow != null)
            return

        var component = Qt.createComponent("PlrLaunchBsxWindow.qml")
        if (component.status === Component.Ready) {
            pLaunchBsxWindow = component.createObject(iAppwin)
            pLaunchBsxWindow.show()
        }
    }

    function fCloseSyncWindow() {
        if(pSyncOperationsWindow != null)
            pSyncOperationsWindow.close()
    }

    function fStopSyncOperations() {
        if(pSyncOperationsWindow != null)
            pSyncOperationsWindow.fSyncStopped()
        else
            mnsBackend.onSyncStopped()
    }

    function fShowSettingToast(message) {
        pSettingsWindow.fShowToast(qsTranslate("QObject", message))
    }

    function fCloseMacroManagerWindow() {
        if(pMacroManagerWindow != null)
            pMacroManagerWindow.close()
    }

    function fDestroyMacroManagerWindow() {
        if(pMacroManagerWindow != null) {
            pMacroManagerWindow.fOnCloseOperation()
            pMacroManagerWindow.fSaveMacroWindowGeometry()
            pMacroManagerWindow.destroy()
            pMacroManagerWindow = null
        }
    }

    function fShowImportSuccessPopup() {
        var toast = iToastComponent.createObject(iAppwin, { pToastMessage: qsTranslate("QObject", "File(s) imported to Media Manager") } )
        toast.fShowMessage()
    }

    function fShowAllImportFailedPopup() {
        var toast = iToastComponent.createObject(iAppwin, { pToastMessage: qsTranslate("QObject", "Error importing files to Media Manager") } )
        toast.fShowMessage()
    }

    function fShowPartialImportFailedPopup() {
        var toast = iToastComponent.createObject(iAppwin, { pToastMessage: qsTranslate("QObject", "Error importing some files. Check Media Manager to review") } )
        toast.fShowMessage()
    }

    function fShowImportFolderUnsupportedPopup() {
        var toast = iToastComponent.createObject(iAppwin, { pToastMessage: qsTranslate("QObject", "Error: Importing a folder is not supported") } )
        toast.fShowMessage()
    }

    function fOpenScreenTranslateWindow() {
        if(pScreenTranslateWindow !== null)
            return

        var component = Qt.createComponent("PlrScreenTranslateWindow.qml")
        if (component.status === Component.Ready) {
            plrBackend.getTranslatedImage()
            pScreenTranslateWindow = component.createObject(iAppwin)
            pScreenTranslateWindow.show()
        }
    }

    function fTranslatedImageResponse(success) {
        if(pScreenTranslateWindow !== null) {
            success = success === true
            if(success)
                pScreenTranslateWindow.pImageVisible = true === true
            else
                pScreenTranslateWindow.fShowErrorMsg()
        }
    }

    function fReOpenScreenTranslateWindow() {
        pScreenTranslateWindow = null
        fOpenScreenTranslateWindow()
    }

    function fUiShowPanControlTooltip(panKey) {
        pFullScreenPopupControl = iFullScreenPopupControlComponent.createObject(iAppwin, {"pMessage" : qsTranslate("QObject", "Press {%1} to use mouse for look around.").arg(panKey)})
        pFullScreenPopupControl.fShowMessage(true)
    }

    function fGamepadDetectionMessage() {
        if (iAppwin.visibility !== ApplicationWindow.Hidden && pIsBootComplete && kmmBackend.gamepadConnectedState) {
            if (iAppwin.visibility === ApplicationWindow.Minimized)
                iAppwin.visibilityChanged.connect(fShowGamepadDetectionMessage);
            else
                fShowGamepadDetectionMessage()
        }
    }

    function fShowGamepadDetectionMessage() {
        if (pGamepadDetectedDialog != null)
            return

        var gamepadDetectionEnabled = uiBackend.confGetBool("bst.enable_gamepad_detection");
        if (gamepadDetectionEnabled) {
            var showGamepadDetectionMessage = uiBackend.confGetBool("bst.show_gamepad_detection_message")
            var isDefaultInstance = plrBackend.getVmName().indexOf("_") === -1
            if(isDefaultInstance && showGamepadDetectionMessage) {
                pGamepadDetectedDialog = iGamepadDetectionMessageComponent.createObject(iAppwin)
                pGamepadDetectedDialog.show()
            }
            else {
                var toast = iToastComponent.createObject(iAppwin, { pToastMessage: qsTranslate("QObject", "Gamepad connected") })
                toast.fShowMessage()
            }
        }
        iAppwin.visibilityChanged.disconnect(fShowGamepadDetectionMessage)
    }

    function fShowCheckEffectUpgrade() {
        var toast = iToastComponent.createObject(iAppwin, { pToastMessage: qsTranslate("QObject", "Checking Effect Update...") } )
        toast.fShowMessage()
    }

    function fShowEffectUpgradeFinished() {
        var toast = iToastComponent.createObject(iAppwin, { pToastMessage: qsTranslate("QObject", "Effects have been updated") } )
        toast.fShowMessage()
    }

    function fShowGameControlsUpdatedInfo(articleKey) {
        if (pGameControlsUpdatedDialog != null || (!iSidebar.pIsSyncEnable && !iTopbar.pSyncSource))
            return

        pArticleKey = articleKey
        pGameControlsUpdatedDialog = iGameControlsUpdatedPrompt.createObject(iAppwin)
        pGameControlsUpdatedDialog.show()
    }

    function fShowMultipleCameraDetectedPrompt() {
        if(pMultipleCamerasDetectedDialog != null || pSettingsWindow != null)
            return

        pMultipleCamerasDetectedDialog = iMultipleCamerasConnectedPrompt.createObject(iAppwin)
        pMultipleCamerasDetectedDialog.show()
    }

    function fCreateFlePopup(packageName, instance) {
        if(pFlePopupWindow != null)
            return

        var component = Qt.createComponent("PlrLaunchAppWindow.qml")
        if (component.status === Component.Ready) {
            pFlePopupWindow = component.createObject(iAppwin, {
                                                         "UiOverlay.overlayRect": Qt.rect(iAppwin.x + plrBackend.plrWinOffsets[0] - (adsBackend.pExtendedBannerAdWidth > 0 ? iAdRepeater.itemAt(0).width : 0),
                                                                                          iAppwin.y + plrBackend.plrWinOffsets[2],
                                                                                          iAppwin.width - plrBackend.plrWinOffsets[0] - plrBackend.plrWinOffsets[1] + (adsBackend.pExtendedBannerAdWidth > 0 ? iAdRepeater.itemAt(0).width : 0),
                                                                                          iAppwin.height - plrBackend.plrWinOffsets[2] - plrBackend.plrWinOffsets[3]),
                                                         "x": Qt.binding(function() { return iAppwin.x + plrBackend.plrWinOffsets[0] - (adsBackend.pExtendedBannerAdWidth > 0 ? iAdRepeater.itemAt(0).width : 0) + (iAppwin.width - plrBackend.plrWinOffsets[0] + (adsBackend.pExtendedBannerAdWidth > 0 ? iAdRepeater.itemAt(0).width : 0) - plrBackend.plrWinOffsets[1] - this.width) / 2 }),
                                                         "y": Qt.binding(function() { return iAppwin.y + plrBackend.plrWinOffsets[2] + (iAppwin.height - plrBackend.plrWinOffsets[2] - plrBackend.plrWinOffsets[3] - this.height) / 2 })
                                                     })
            pFlePopupWindow.loadWindow(packageName, instance)
        }
    }

    function fCloseFlePopup() {
        if(pFlePopupWindow != null)
            pFlePopupWindow.destroy()
    }

    function fShowFlePopup(store, packageName, extraData, source, instance) {
        fCreateFlePopup(packageName, instance)

        pFlePopupWindow.installClicked.connect(function() {
            plrBackend.launchAppStore(store, packageName, extraData, source)
        });

        pFlePopupWindow.show()
    }

    function fShowQuestNotificationWindow(notificationJson, contentTitle, contentText, buttonText, showRewardsCenterRedDot) {
        if(pNotificationBarWindow != null) {
            if(iSidebar.fCheckIfMomentsNotificationIsVisible())
                pNotificationBarWindow.close()
            else
                return
        }

        var component = Qt.createComponent("PlrNotificationBarWindow.qml")
        if (component.status === Component.Ready) {
            pNotificationBarWindow = component.createObject(iAppwin, {
                                                                "x": Qt.binding(function() { return iAppwin.x + plrBackend.plrWinOffsets[0] }),
                                                                "y": Qt.binding(function() { return iAppwin.y + plrBackend.plrWinOffsets[2] }),
                                                                "width": Qt.binding(function() { return iAppwin.width - plrBackend.plrWinOffsets[0] - plrBackend.plrWinOffsets[1] }),
                                                                "pNotificationJson": notificationJson,
                                                                "pContentTitle": contentTitle,
                                                                "pContentText": contentText,
                                                                "pButtonText": buttonText
                                                            })
            pNotificationBarWindow.buttonClicked.connect(fNotificationBarButtonClicked);
            pNotificationBarWindow.show()
            iTopbar.pShowRewardsCenterRedDot = showRewardsCenterRedDot
            pIsQuestNotificationOpen = true
        }
    }

    function fNotificationBarButtonClicked(notificationJson) {
        plrBackend.onNotificationBarButtonClicked(notificationJson)
        plrBackend.sendNotificationBarStats("notification_bar_claimBtn_clicked", notificationJson)
        iTopbar.pShowRewardsCenterRedDot = false
    }

    function fShowChargerWarning() {
        if(pChargerWarningPopupWindow != null)
            return

        if(plrBackend.isChargerWarningRequired()) {
            pChargerWarningPopupWindow = iChargerWarningComponent.createObject(iAppwin)
            pChargerWarningPopupWindow.show()
            plrBackend.sendPopupStats("charger_warning", "impression")
        }
        else {
            plrBackend.releaseDisplayChargerWarningLock()
        }
    }

    function fShowSigninRequiredDialog() {
        if(pSigninRequiredWindow != null)
            return
        pSigninRequiredWindow = iSignInRequiredPrompt.createObject(iAppwin)
        pSigninRequiredWindow.show()
    }

    function fShowLinkNowggAccountDialog(videoId, showDoNotShowAgain) {
        if(pLinkNowggAccountWindow != null)
            return
        pLinkNowggAccountWindow = iLinkNowggAccountPrompt.createObject(iAppwin, {"videoId": videoId, "pShowDoNotShowAgain": showDoNotShowAgain})
        pLinkNowggAccountWindow.show()
        plrBackend.sendMomentsStats("moments_link_account_popup_shown", mediaBackend.pLinkAccountSource)
    }

    function fShowSigninSuccessfulDialog(showEnableMoments) {
        if (pCheckBrowserPopupWindow != null)
            pCheckBrowserPopupWindow.close()

        if(pSigninSuccessfulPopupWindow != null || uiBackend.confGetBool("bst.nowgg_signin_completed"))
            return

        mediaBackend.onSignInCompleted()

        pSigninSuccessfulPopupWindow = iSignInSuccessfulPrompt.createObject(iAppwin, {"pShowEnableMoments": showEnableMoments})
        pSigninSuccessfulPopupWindow.show()
    }

    function fShowDisableMomentsDialog() {
        if(pDisableMomentsPopupWindow != null)
            return

        pDisableMomentsPopupWindow = iDisableMomentPrompt.createObject(iAppwin)
        pDisableMomentsPopupWindow.show()
    }

    function fShowDisableRecordingDialog() {
        if(pDisableRecordingPopupWindow != null)
            return

        pDisableRecordingPopupWindow = iDisableRecordingPrompt.createObject(iAppwin)
        pDisableRecordingPopupWindow.show()
    }

    function fShowCheckBrowserDialog() {
        if(pCheckBrowserPopupWindow != null)
            return

        pCheckBrowserPopupWindow = iCheckBrowserPrompt.createObject(iAppwin)
        pCheckBrowserPopupWindow.show()
    }

    function fShowLowDiskSpaceDialog(isMoment) {
        if(pLowDiskSpacePopupWindow != null)
            return

        pLowDiskSpacePopupWindow = iLowDiskSpacePrompt.createObject(iAppwin, {"isMoment": isMoment})
        pLowDiskSpacePopupWindow.show()
    }

    function fShowSignOutDialog() {
        if(pSignOutPopupWindow != null)
            return

        var userName = uiBackend.confGetString("bst.nowgg_username")
        var email = uiBackend.confGetString("bst.nowgg_email")
        if (userName === "")
            userName = "John Wick"
        if (email === "")
            email = "john@wick.com"
        pSignOutPopupWindow = iSignOutPrompt.createObject(iAppwin, {"userName": userName, "userEmail": email})
        pSignOutPopupWindow.show()
    }

    function fShowSignOutConfirmationDialog() {
        if(pSignOutConfirmationPopupWindow != null)
            return

        pSignOutConfirmationPopupWindow = iSignOutConfirmationPrompt.createObject(iAppwin)
        pSignOutConfirmationPopupWindow.show()
    }

    function fShowAdsInfoPrompt(showBootAdsInfo) {
        if (pSettingsWindow == null && iAppwin.visibility != ApplicationWindow.Minimized) {
            if(showBootAdsInfo)
                iAdsEnableOnBootPrompt.createObject(iAppwin).show()
            else
                iAdsInfoPrompt.createObject(iAppwin).show()
        }
    }

    function fShowAirplaneSettingChangedToast(airplaneModeEnabled) {
        var message = airplaneModeEnabled ? qsTranslate("QObject", "Airplane Mode On") :  qsTranslate("QObject", "Airplane Mode Off")
        var toast = iToastComponent.createObject(iAppwin, { "pToastMessage": message,
                                                     "pBackground.border.color" : UiTheme.colors.primary50,
                                                     "pBackground.color" : UiTheme.colors.overlayPrimary,
                                                     "pBackground.radius" : 0,
                                                     "pBackground.opacity" : 0.85,
                                                     "pBackground.leftPadding": 40,
                                                     "pBackground.rightPadding": 40,
                                                     "pBackground.topPadding": 12,
                                                     "pBackground.bottomPadding": 12})

        toast.fShowMessage({verticalOffsetRatio:0.65})
    }

    function fShowTroubleSigningInBtn(isVisible) {
        if(pTroubleSigningInBtn != null)
            pTroubleSigningInBtn.close()

        if(!isVisible)
            return

        pTroubleSigningInBtn = iFeedbackPillComponent.createObject(iAppwin)
        pTroubleSigningInBtn.show()

        if(!pIsTroubleSigningInBtnShown) {
            pIsTroubleSigningInBtnShown = true
            plrBackend.sendTroubleSigningInBtnStats("trouble_signing_in_shown")
        }
    }

    function fShowExitFullScreenPopup() {
        if(iAppwin.visibility != ApplicationWindow.FullScreen)
            return

        if (pFullScreenPopupControl != null)
            pFullScreenPopupControl.fClosePopup()
        if(pExitFullScreenControl == null) {
            pExitFullScreenControl = iExitFullScreenPopupControlComponent.createObject(iAppwin)
            pExitFullScreenControl.fShowPopup()
        }
    }

    function fOpenMediaGalleryWindow() {
        if (pMediaGalleryWindow != null)
            return

        var component = Qt.createComponent("PlrMediaGalleryWindow.qml")
        if (component.status === Component.Ready) {
            pMediaGalleryWindow = component.createObject(iAppwin)
            pMediaGalleryWindow.show()
        }
    }

    function fShowMomentsNotificationWindow(contentText) {
        if(pNotificationBarWindow != null)
            return

        var component = Qt.createComponent("PlrNotificationBarWindow.qml")
        if (component.status === Component.Ready) {
            pNotificationBarWindow = component.createObject(iAppwin, {
                                                                "x": Qt.binding(function() { return iAppwin.x + plrBackend.plrWinOffsets[0] }),
                                                                "y": Qt.binding(function() { return iAppwin.y + plrBackend.plrWinOffsets[2] }),
                                                                "width": Qt.binding(function() { return iAppwin.width - plrBackend.plrWinOffsets[0] - plrBackend.plrWinOffsets[1] }),
                                                                "pContentText": contentText,
                                                                "pButtonVisible": false,
                                                                "pSendStats": false,
                                                                "pEnableSound": false,
                                                                "pShowProductIcon": false
                                                            })
            pNotificationBarWindow.buttonClicked.connect(fNotificationBarButtonClicked);
            pNotificationBarWindow.show()
        }
    }

    function fCloseMomentsNotificationWindow() {
        if(pNotificationBarWindow != null && !pIsQuestNotificationOpen)
            pNotificationBarWindow.fAnimateAndClose()
    }

    function fCloseMediaGalleryWindow() {
        if (pMediaGalleryWindow != null) {
            pMediaGalleryWindow.close()
            pMediaGalleryWindow = null
        }
    }

    function fOpenBlueStacksStoreWindow(url) {
        if (pBlueStacksStoreWindow == null) {
            var comp = Qt.createComponent("UiBrowserWindow.qml")
            if (comp.status === Component.Ready) {
                pBlueStacksStoreWindow = comp.createObject(null, {
                                                               "x": 300,
                                                               "y": 50,
                                                               "width": 1000,
                                                               "height": 800,
                                                               "pShowTabsOnTopBar": true,
                                                               "pCreateTabBtnVisible": false,
                                                               "visibility": ApplicationWindow.Maximized
                                                           })
            }
        }
        else {
            pBlueStacksStoreWindow.createNewTab()
        }
        pBlueStacksStoreWindow.pCurrentWebView.url = url

        if (pBlueStacksStoreWindow.visibility == Window.Maximized)
            pBlueStacksStoreWindow.showMaximized()
        else
            pBlueStacksStoreWindow.showNormal()

        pBlueStacksStoreWindow.raise()
        pBlueStacksStoreWindow.requestActivate()

        plrBackend.sendWebshopIAPStats(url)
    }
}
