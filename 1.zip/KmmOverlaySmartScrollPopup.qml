/*
 * Copyright (C) 2020-2021 BlueStack Systems, Inc.
 * All Rights Reserved
 *
 * THIS IS UNPUBLISHED PROPRIETARY SOURCE CODE OF BLUESTACK SYSTEMS, INC.
 * The copyright notice above does not evidence any actual or intended
 * publication of such source code.
 */

import QtQuick 2.15
import QtQuick.Controls 2.15
import QtQuick.Layouts 1.15
import QtGraphicalEffects 1.0
import QtQuick.Window 2.15

import "KmmUtils.js" as Utils

Window {
    id: iSmartScrollPopup
    width: root.implicitWidth
    height: iContentLayout.implicitHeight < 70 ? 70 : iContentLayout.implicitHeight
    color: "transparent"
    flags: Qt.Tool | Qt.FramelessWindowHint | Qt.WindowDoesNotAcceptFocus | Qt.WindowTransparentForInput
    screen: transientParent.screen
    property string pSelectedWeaponIndex: ""
    property string pKeyText
    property real controlOpacity: 1.0
    property real pScreenWidth: 1920
    property real pScalingFactor: 1.0
    UiRowLayout {
        id: root
        height: iContentLayout.implicitHeight
        UiColumnLayout {
            id: iContentLayout
            Layout.preferredWidth: 150
            color: UiTheme.colors.overLayBlack
            border.width: 1
            border.color: UiTheme.colors.overLayTint
            Layout.fillWidth: true
            gradient: Gradient{
                GradientStop{ position : 0.0; color: "#33FFFFFF" }
                GradientStop{ position : 0.1; color:  UiTheme.colors.overlayPrimary }
                GradientStop{ position : 0.2; color:  UiTheme.colors.overLayBlack }
                GradientStop{ position : 0.4; color: UiTheme.colors.overLayBlack}
                GradientStop{ position : 0.6; color: UiTheme.colors.overLayBlack}
                GradientStop{ position : 0.8; color:  UiTheme.colors.overLayBlack}
                GradientStop{ position : 0.9; color:  UiTheme.colors.overlayPrimary }
                GradientStop{ position : 1.0; color: "#33FFFFFF"}

            }
            Repeater {
                id: iList
                Layout.fillWidth: true
                model: kmmSmartScrollModel
                delegate:
                    UiRowLayout {
                    Layout.fillWidth: true
                    color: pSelectedWeaponIndex != "" && pSelectedWeaponIndex === model.name ? "#4DFFFFFF" : "transparent"
                    padding: 4
                    spacing: 8
                    UiColumnLayout {
                        id: iIndexLayout
                        border.color: UiTheme.colors.overLayBright
                        border.width: 1
                        Layout.preferredWidth: 22
                        Layout.preferredHeight: 22
                        Layout.leftMargin: 4
                        color: pSelectedWeaponIndex != "" && pSelectedWeaponIndex === model.name ? UiTheme.colors.overLayBright : UiTheme.colors.overlayPrimary
                        padding: 2
                        radius: 3
                        Text {
                            text: model.index
                            Layout.alignment: Text.AlignHCenter
                            color: pSelectedWeaponIndex != "" && pSelectedWeaponIndex === model.name ? UiTheme.colors.primary100 : UiTheme.colors.primary10
                            font: UiTheme.fonts.bodySmall
                        }
                    }
                    UiText {
                        id: iWeaponText
                        Layout.fillWidth: true
                        text: model.name
                        color: pSelectedWeaponIndex != "" && pSelectedWeaponIndex === model.name ? UiTheme.colors.primary10 : UiTheme.colors.overLayBright
                        font: UiTheme.fonts.bodySmall
                    }
                }
            }
        }
        Image {
            id: iSmartScrollImg
            source: "qrcAssets/WeaponScrollOverlay.svg"
            width: 40
            height: 48
        }
    }

    Timer {
        id: iPopupTimer
        repeat: false
        interval: 3000
        running: false
        onTriggered: fClosePopup()
    }

    function fClosePopup() {
        iPopupTimer.stop()
        iSmartScrollPopup.close()
        iSmartScrollPopup.destroy()
        kmmBackend.toggleSmartScrollOverlayVisibility(true)
    }

    function fRefreshSelectedIndex(index) {
        pSelectedWeaponIndex = index
    }

    function fShowScrollOverlay(x, y, screenWidth, scalingFactor, index, count) {
        pScreenWidth = screenWidth
        pScalingFactor = scalingFactor
        var xVal = x - iSmartScrollPopup.width + iSmartScrollImg.width - 4
        iSmartScrollPopup.x = xVal
        var yVal = y - iSmartScrollPopup.height / 3
        if(count > 3)
            yVal -= 8
        iSmartScrollPopup.y = yVal
        fRefreshSelectedIndex(index)
        iSmartScrollPopup.show()
        iPopupTimer.start()
    }

    function fRestartTimer(index) {
        iPopupTimer.restart()
        iList.model = []
        iList.model = kmmSmartScrollModel
        fRefreshSelectedIndex(index)
    }
}
