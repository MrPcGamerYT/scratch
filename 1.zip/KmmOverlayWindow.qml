/*
 * Copyright (C) 2020-2021 BlueStack Systems, Inc.
 * All Rights Reserved
 *
 * THIS IS UNPUBLISHED PROPRIETARY SOURCE CODE OF BLUESTACK SYSTEMS, INC.
 * The copyright notice above does not evidence any actual or intended
 * publication of such source code.
 */

import QtQuick 2.15
import QtQuick.Window 2.15

Window {

    property KmmOverlaySmartScrollPopup pSmartScrollControl: null
    id: kmmOverlayWin
    color: "transparent"
    flags: Qt.Tool | Qt.FramelessWindowHint | Qt.WindowTransparentForInput
    title: uiBackend.productName + " Keymap Overlay"
    screen: transientParent.screen

    Component {
        id: iSmartScrollComponent
        KmmOverlaySmartScrollPopup {}
    }

    function fShowSmartScrollPopup(x, y, screenWidth, scalingFactor, index, count) {
        if(pSmartScrollControl == null) {
            pSmartScrollControl = iSmartScrollComponent.createObject(kmmOverlayWin)
            pSmartScrollControl.fShowScrollOverlay(x, y, screenWidth, scalingFactor, index, count)
        }
        else {
            pSmartScrollControl.fRestartTimer(index)
        }
    }

    function fCloseSmartScrollPopup() {
        if(pSmartScrollControl != null)
            pSmartScrollControl.fClosePopup()
    }

}
